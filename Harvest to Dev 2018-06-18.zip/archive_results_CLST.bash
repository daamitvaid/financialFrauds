##!/bin/bash

#mkdir /tmp/CustomerID

folder="$1" 

echo "archiving ML results to ${folder}"
hdfs dfs -mkdir /aml/data/CLST_${folder}

hdfs dfs -mv /aml/data/FCAI_AnomalyCluster_* /aml/data/CLST_${folder}/



