##!/bin/bash

#mkdir /tmp/CustomerID

folder="$1" 

echo "archiving ML results to ${folder}"
hdfs dfs -mkdir /aml/data/${folder}

hdfs dfs -mv /aml/data/FCAI_SupervisedML_* /aml/data/${folder}/
hdfs dfs -mv /aml/data/cutoff* /aml/data/${folder}/
hdfs dfs -mv /aml/data/train*P.csv /aml/data/${folder}/


