// When running in spark-shell
// :load ${codepath}/Feature_Gen1.scala

// export SPARK_HOME=/usr/iop/4.2.5.0-0000/spark2


import org.apache.spark.sql.SparkSession
val spark = SparkSession.builder().appName("Feature_Gen1").getOrCreate()
import spark.implicits._


val dfAlerts = spark.read.option("header","true").csv("/aml/data/alerts_10pct.csv").cache()
dfAlerts.printSchema()
dfAlerts.createOrReplaceTempView("alerts")

val dfAlertsDisp = dfAlerts.groupBy("DISPOSITION").count().cache()
dfAlertsDisp.show()

//val dfTrx = spark.read.option("header","true").csv("/aml/data/alerts_10pct.csv")

val dfTrx = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Transaction_filtered_by_CXID_fortenpercentsample.csv")
dfTrx.printSchema()
dfTrx.createOrReplaceTempView("transactions")
dfTrx.show()
// Check to see if we have any null customer_ids
spark.sql("select count(*) from transactions where CUSTOMER_ID is null limit 10").show(1)

val cdCodes = spark.sql("select TXN_SOURCE_TYPE_CODE, CREDIT_DEBIT_CODE, COUNT(*) as count, SUM(TXN_AMOUNT_BASE) as AMOUNT, MAX(TXN_AMOUNT_BASE) as AMOUNT_MAX from transactions group by TXN_SOURCE_TYPE_CODE, CREDIT_DEBIT_CODE limit 150").show(150)

val wireStats = spark.sql("select CUSTOMER_ID, COUNT(*) as TxCount, min(TXN_AMOUNT_BASE) as TxAmtMin, max(TXN_AMOUNT_BASE) as TxAmtMax, sum(TXN_AMOUNT_BASE) as TxAmtTot, avg(TXN_AMOUNT_BASE) as TxAmtAvg from transactions where  TXN_SOURCE_TYPE_CODE in ('WIRE-D','WIRE-F') group by CUSTOMER_ID").cache()

val features = spark.read.option("header","true").option("escape","\"").csv("/aml/data/ML_10pct_P5/FCAI_SupervisedML_FPTP_ValidationTP.csv")
features.createOrReplaceTempView("featuresTP")

val mlTP = spark.sql("select CUSTOMER_ID, FP_TP_Tag, sum(alert) as alerts, predictions_TP from featuresTP group by  CUSTOMER_ID, FP_TP_Tag, predictions_TP").cache()
mlTP.createOrReplaceTempView("mlTP")

val mlTP20 = spark.sql("select * from mlTP where FP_TP_tag='TP' order by alerts desc")

mlTP20.write.option("header","true").csv("/aml/data/ML_10pct_P5/Customer_list_TP20.csv").partitionBy("predictions_TP")

//partitionBy can't be used for csv ; can be used for json or parquet
//it basically splits the subfiles by the partition column
//mlTP20.write.option("header","true").partitionBy("predictions_TP").json("/aml/data/ML_10pct_P5/Customer_list_TP20.json")

//Test... Do we get better speed by Partitioning a parquet file
val dfTrx = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Transaction_filtered_by_CXID_fortenpercentsample.csv")
dfTrx.write.option("header","true").partitionBy("CUSTOMER_ID").parquet("/aml/data/ML_10pct_P5/Customer_list_TP20.parquet")

// Read in Transaction File
val dfTrx = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Transaction_filtered_by_CXID_Scenario_sample.csv")
dfTrx.createOrReplaceTempView("transactions")

// Split the file by scenario
val dfAlert = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Scenario_Sample_of_AlertedCust_info.csv")
dfAlert.createOrReplaceTempView("alerts")
val dfAlertScen = spark.sql("select * from alerts where CHECK_NAME like 'DS05%'")
dfAlertScen.write.option("header","true").csv("/aml/data/alerts_DS05.csv")
val dfCustomersScen = spark.sql("select distinct CUSTOMER_ID from alerts where CHECK_NAME like 'DS05%'")
dfCustomersScen.createOrReplaceTempView("customers")
val dfTrxScen = spark.sql("select t.* from transactions t, customers c where t.CUSTOMER_ID=c.CUSTOMER_ID")
dfTrxScen.write.option("header","true").csv("/aml/data/transactions_DS05.csv")

// Stats for Reporting
spark.sql("select Escalated_To_Case_Investigation, count(*) as Count from alerts group by Escalated_To_Case_Investigation").show(5)
spark.sql("select count(*) from customers").show(5)
 
val dfAlertsCHECK = spark.sql("select CHECK_NAME, count(*) as CTR from alerts where CHECK_NAME like 'DS%' group by CHECK_NAME")

dfTrxDS10R.show()
dfTrxDS10R.write.option("header","true").csv("/aml/data/Transaction_filtered_by_CXID_DS10R.csv")

val dfTrxDS10R = spark.read.option("header","true").option("escape","\"").csv("/aml/data/transactions_DS10R.csv")

// Split the all transaction file to just alerted customers
val Scenario=116
val dfAlert = spark.read.option("header","true").option("escape","\"").csv("/aml/data/alerts_175.csv")
val dfFeatures = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Training_ByCustomerID_175_all.csv")
dfAlert.createOrReplaceTempView("alerts")
dfFeatures.createOrReplaceTempView("features")
val dfCustomers = spark.sql("select distinct CUSTOMER_ID from alerts")
dfCustomers.createOrReplaceTempView("customers")
val dfFeaturesSubset = spark.sql("select f.* from features f, customers c where f.CUSTOMER_ID=c.CUSTOMER_ID")

dfFeaturesSubset.write.option("header","true").csv("/aml/data/Training_ByCustomerID_175_alerts.csv")

//

val dfAlert113 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/alertsbyCustomerID_113.csv")
val dfAlert116 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/alertsbyCustomerID_116.csv")
val dfAlert175 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/alertsbyCustomerID_175.csv")

val dfAlerts = dfAlert113.unionAll(dfAlert116)
val dfAlerts3 = dfAlerts.unionAll(dfAlert175)
dfAlerts3.write.option("header","true").csv("/aml/data/alertsbyCustomerID_113116175.csv")


val dfFeatures113 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Training_ByCustomerID_113_alertsZeroFill.csv")
val dfFeatures116 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Training_ByCustomerID_116_alertsZeroFill.csv")
val dfFeatures175 = spark.read.option("header","true").option("escape","\"").csv("/aml/data/Training_ByCustomerID_175_alertsZeroFill.csv")

val dfFeatures = dfFeatures113.unionAll(dfFeatures116)
val dfFeatures3 = dfFeatures.unionAll(dfFeatures175)
dfFeatures3.write.option("header","true").csv("/aml/data/Training_ByCustomerID_113116175_alertsZeroFill.csv")
