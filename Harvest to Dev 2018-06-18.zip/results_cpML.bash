##!/bin/bash

#mkdir /tmp/CustomerID

get_merge() {
	local -r file="$1" ; shift
	echo "getting ${file}"
	hdfs dfs -getmerge /aml/data/${file} /tmp/customerID/${file}
}

suffix=_113116175_alertsZeroFill


get_merge "Training_ByCustomerID${suffix}.csv"
get_merge "alertsbyCustomerID_113116175.csv"
get_merge "ByCustomerID_GII${suffix}.csv"
get_merge "FCAI_SupervisedML_FPTP_ValidationTP.csv"
get_merge "FCAI_SupervisedML_FPTP_ValidationFP.csv"
get_merge "cutoffResults_TP.csv"
get_merge "cutoffResults_FP.csv"
get_merge "trainingTP.csv"
get_merge "trainFP.csv"


#get_merge "FCAI_AnomalyCluster_Anomaly_corMatrix.csv"
#get_merge "FCAI_AnomalyCluster_Anomaly_standardizedData.csv"
#get_merge "FCAI_AnomalyCluster_Anomaly_nonCorrelatedData.csv"
#get_merge "FCAI_AnomalyCluster_Anomaly_train.csv"
#get_merge "FCAI_AnomalyCluster_Anomaly_test.csv"


## cleanup Training Files
head -1 Training_ByCustomerID${suffix}.csv > Training_ByCustomerID${suffix}_hdrfx.csv
grep -v 'CUSTOMER_ID' Training_ByCustomerID${suffix}.csv >> Training_ByCustomerID${suffix}_hdrfx.csv
