import csv
import os
from pyspark.sql.functions import udf, count, avg, lit, collect_list, col
from pyspark.sql.types import StringType, ArrayType, IntegerType, DoubleType, BooleanType
from pyspark.sql import SparkSession
def sp_read(spark,path):
  return(spark.read.csv(path, header=True))

def sp_write(df, path):
  return(df.repartition(1).write.csv(path, header=True))

def rename(df, renaming_dict, dir):
  select_cols = []
  for old_name, new_name in renaming_dict.items():
    df = df.withColumnRenamed(old_name, new_name)
    select_cols.append(new_name)
  if (dir == "i"):
	select_cols.extend(("BENEBK_CUST_ID","BENEBK_STRT_LINE1","BENE_INST_ID","BENE_CTRY"))
  if (dir == "o"):
	select_cols.extend(("ORIG_CTRY","ORIGBK_CUST_ID","ORIGBK_STRT_LINE1","ORIGBK_CTRY","BENE_CUST_ID"))

  select_cols.extend(("PARTY_ID","ACCT_ID","COUNTERPARTY_NAME","COUNTERPARTY_ACCT_NUM","COUNTERPARTY_CNTRY"))
  df = select(df, select_cols)
  return(df)

def select(df, select_cols):
  df = df.select(select_cols)
  return(df)

def spark_filter(input_path,output_path,renaming_dict_in,renaming_dict_out):
  spark = SparkSession \
  .builder \
  .appName("Python Spark Rule Module") \
  .getOrCreate()

  df = sp_read(spark,input_path)
  df_in = df.filter("CREDIT_DEBIT_CODE = 'C'") \
          .withColumn("BENEBK_CUST_ID", lit(None).cast(StringType())) \
	  .withColumn("BENEBK_STRT_LINE1", lit(None).cast(StringType())) \
	  .withColumn("BENE_INST_ID", lit(None).cast(StringType())) \
	  .withColumn("BENE_CTRY", lit(None).cast(StringType())) \
	  .withColumn("PARTY_ID",df.PRIMARY_CUSTOMER_ID) \
	  .withColumn("ACCT_ID",df.ACCOUNT_ID) \
	  .withColumn("COUNTERPARTY_NAME",df.COUNTER_PARTY_NAME) \
 	  .withColumn("COUNTERPARTY_ACCT_NUM",df.COUNTER_PARTY_ACCOUNT_NUM) \
	  .withColumn("COUNTERPARTY_CNTRY",df.COUNTER_PARTY_COUNTRY_CODE) 
  df_out = df.filter("CREDIT_DEBIT_CODE = 'D'") \
	  .withColumn("ORIG_CTRY", lit(None).cast(StringType())) \
	  .withColumn("ORIGBK_CUST_ID", lit(None).cast(StringType())) \
	  .withColumn("ORIGBK_STRT_LINE1", lit(None).cast(StringType())) \
	  .withColumn("ORIGBK_CTRY", lit(None).cast(StringType())) \
	  .withColumn("BENE_CUST_ID", lit(None).cast(StringType())) \
	  .withColumn("PARTY_ID",df.PRIMARY_CUSTOMER_ID) \
	  .withColumn("ACCT_ID",df.ACCOUNT_ID) \
	  .withColumn("COUNTERPARTY_NAME",df.COUNTER_PARTY_NAME) \
 	  .withColumn("COUNTERPARTY_ACCT_NUM",df.COUNTER_PARTY_ACCOUNT_NUM) \
	  .withColumn("COUNTERPARTY_CNTRY",df.COUNTER_PARTY_COUNTRY_CODE) 
 

  df_in = rename(df_in, renaming_dict_in, "i")
  df_out = rename(df_out, renaming_dict_out, "o")
  
  sp_write(df_in.union(df_out), output_path)

def read_csv(file_path):
    temp_dict = {}
    with open(file_path, 'r') as csvfile:
        data_reader = csv.reader(csvfile)
        for index, row in enumerate(data_reader):
            if (index != 0 and len(row[len(row)-1]) != 0):
                temp_dict[row[len(row)-1]] = row[0]
    print(temp_dict)
    return(temp_dict)

def read_dir(dir_path):
    file_paths = []
    directory = os.path.join(dir_path)
    for root,dirs,files in os.walk(directory):
        for file in files:
            if file.endswith(".csv"):
                file_paths.append(dir_path+"/"+file)
    return(file_paths)

def merge_two_dicts(x,y):
    z = x.copy()
    z.update(y)
    return z

renaming_dict_in = {}
renaming_dict_out = {}
#file_paths = read_dir("./mapping")
#for path in file_paths:
    #renaming_dict = merge_two_dicts(renaming_dict,read_csv(path))
renaming_dict_in = read_csv("./mapping/Txn_in.csv")
renaming_dict_out = read_csv("./mapping/Txn_out.csv")
spark_filter("file:///data_mapping/input/transactions-sample.csv","file:///data_mapping/output/zion_transaction_sample.csv",renaming_dict_in,renaming_dict_out)
