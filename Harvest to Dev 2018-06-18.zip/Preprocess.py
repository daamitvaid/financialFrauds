import csv
import os
import argparse
import shutil
from pyspark.sql.functions import udf, count, avg, lit, collect_list
from pyspark.sql.types import StringType, ArrayType, IntegerType, DoubleType, BooleanType
from pyspark.sql import SparkSession
def sp_read(spark,path):
  return(spark.read.csv(path, header=True))

def sp_write(df, path):
  return(df.repartition(1).write.csv(path, header=True))

def rename(df, renaming_dict):
  select_cols = []
  for old_name, new_name in renaming_dict.items():
    df = df.withColumnRenamed(old_name, new_name)
    select_cols.append(new_name)
  df = select(df, select_cols)
  return(df)

def select(df, select_cols):
  df = df.select(select_cols)
  return(df)

def spark_filter(input_path,output_path,renaming_dict):
  spark = SparkSession \
  .builder \
  .appName("Python Spark Rule Module") \
  .getOrCreate()

  df = sp_read(spark,input_path)
  df = rename(df, renaming_dict)
  
  sp_write(df, output_path)

def read_csv(file_path):
    temp_dict = {}
    with open(file_path, 'r') as csvfile:
        data_reader = csv.reader(csvfile)
        for index, row in enumerate(data_reader):
            if (index != 0 and len(row[len(row)-1]) != 0):
                temp_dict[row[len(row)-1]] = row[0]
    print(temp_dict)
    return(temp_dict)

def read_dir(dir_path):
    file_paths = []
    directory = os.path.join(dir_path)
    for root,dirs,files in os.walk(directory):
        for file in files:
            if file.endswith(".csv"):
                file_paths.append(dir_path+"/"+file)
    return(file_paths)

def merge_two_dicts(x,y):
    z = x.copy()
    z.update(y)
    return z

def read_mapping_config(training, reset):
    #Check if config has already been read into Python
    configExists = 'mappingConfig' in locals() or 'mappingConfig' in globals()
    
    if configExists == False
        print("Reading mapping_config.json")
        mappingConfig = spark.read.json("mapping_config.json)
        
#renaming_dict = {}
#file_paths = read_dir("./mapping")
#for path in file_paths:
    #renaming_dict = merge_two_dicts(renaming_dict,read_csv(path))

#Acquire input/output/mapping from command line user
parser = argparse.ArgumentParser()
parser.add_argument("input", help="path and filename of the input file")
parser.add_argument("output", help="path and filename of the output file")
parser.add_argument("mapping", help="path and filename of the mapping file")
args = parser.parse_args()

#Remove 'file://' from the beginning of the output path (for os.path.exists)
outputString = args.output
outputString = outputString.replace("file://", "", 1)

#If the output file already exists, delete it
if(os.path.exists(outputString)):
    print("Output file already exists. Removing...")
    shutil.rmtree(outputString)

#Run the operation
spark_filter(args.input,args.output,read_csv(args.mapping))

#spark_filter("file:///data_mapping/input/accounts.csv","file:///data_mapping/output/zion_accounts.csv",read_csv("./mapping/Acct.csv"))
#spark_filter("file:///data_mapping/input/customers.csv","file:///data_mapping/output/zion_ind_customers.csv",read_csv("./mapping/Individual_Customer.csv"))
#spark_filter("file:///data_mapping/input/customers.csv","file:///data_mapping/output/zion_biz_customers.csv",read_csv("./mapping/Business_Customer.csv"))
#spark_filter("file:///data_mapping/input/customer_account_link.csv","file:///data_mapping/output/zion_cust_acct.csv",read_csv("./mapping/Cust_Acct.csv"))
#spark_filter("file:///data_mapping/input/customers.csv","file:///data_mapping/output/zion_cust_addr.csv",read_csv("./mapping/Cust_Addr.csv"))
#spark_filter("file:///data_mapping/input/customers.csv","file:///data_mapping/output/zion_cust_addr.csv",read_csv("./mapping/Cust_Addr.csv"))
#spark_filter("file:///data_mapping/input/customer_phones.csv","file:///data_mapping/output/zion_phone.csv",read_csv("./mapping/Phone.csv"))
#spark_filter("file:///data_mapping/input/customer_phones.csv","file:///data_mapping/output/zion_cust_phone.csv",read_csv("./mapping/Cust_Phone.csv"))
#spark_filter("file:///data_mapping/input/Alert_Masterfile.csv","file:///data_mapping/output/zion_alert.csv",read_csv("./mapping/Alert.csv"))
#spark_filter("file:///data_mapping/input/ibm_alert_header.csv","file:///data_mapping/output/zion_alert_txn.csv",read_csv("./mapping/Alert_Txn.csv"))
#spark_filter("file:///data_mapping/input/customers.csv","file:///data_mapping/output/zion_address.csv",read_csv("./mapping/Address.csv"))
spark_filter("file:///data_mapping/input/transactions-sample.csv","file:///data_mapping/output/zion_transaction_sample.csv",read_csv("./mapping/Txn.csv"))
