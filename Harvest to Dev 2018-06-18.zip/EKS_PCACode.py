# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#Things that must be set by the user:
#Column names (varnames)
#Number of components (n)
#Threshold to define the PCs
thresh=0.74
#Number of top importance variables to identify
numvars=15
####################################################Prep environment########################################################
#Import the needed packages
#Dataframes
import pandas as pd
#Arrays
import numpy as np
#To standardize our data
from sklearn.preprocessing import StandardScaler
#To conduct PCA
from sklearn.decomposition import PCA as sklearnPCA
#To graph
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits import mplot3d


###################################################Prep data###############################################################
#Import the data
df = pd.read_csv(
    filepath_or_buffer='E:\Workspace\Shared\SupervisedML\pass2\FCAI_AnomalyCluster_Anomaly_train.csv', 
    sep=',')

#You may need to name your dataframe columns
#NOTE: pay attention as to what your target variable is called. It will be used later in graphing
#varnames=['name1', 'name2', 'name3', 'name4', 'name5']
#df.columns=varnames

#Drop the rows with NA values or fill them in with the value 0
#na=df.dropna()
na=df.fillna(0)
#Split the data so the target variable (and any other categorical data) is held separately
X=na.iloc[:,1:-9]
y=na.iloc[:,-9:]
#Remove the old indices for future merging
X=X.reset_index()
y=y.reset_index()
#Removing the old index creates a new index column. Remove it
X=X.iloc[:,1:]
y=y.iloc[:,1:]

#Standardize the data to be used in PCA
#When standardizing this provides the correlation matrix
#If you wanted the covariance matrix you would just center
stdX=StandardScaler().fit_transform(X)

#######################################################Conduct PCA########################################################
#Run PCA with total possible components
pca=sklearnPCA()

#Fit PCA to the standardized data
numdecide=pca.fit_transform(stdX)

#Cumulative amount of variation explained
cumvar=np.cumsum(np.round(pca.explained_variance_ratio_, decimals=4)*100)

#Plot the progression of the variance explained
fig=plt.figure()
plt.plot(range(1,len(cumvar)+1),cumvar,color='orange',marker='o',label='Cumulative Variance Explained')
plt.bar(range(1,len(cumvar)+1),np.round(pca.explained_variance_ratio_, decimals=4)*100,label="Variance per Componenet")
plt.title("Variance Explained by All Principal Components")
plt.ylabel('Eigenvalue')
plt.xlabel('Number of Components')
plt.xlim(0,len(cumvar)+1)
plt.legend()
plt.show()
fig.savefig('fulleigval.png')

#Run PCA with the correct number of components
n=13
pca=sklearnPCA(n_components=n)

#Fit PCA to the standardized data
sol=pca.fit_transform(stdX)


######################################################Evaluate PCA###########################################################
#Eigenvalues of componets 
explainvar=pca.explained_variance_

#Variance explained, as sums to 1
explainvar_ratio=pca.explained_variance_ratio_

#Cumulative amount of variation explained
fin_cumvar=np.cumsum(np.round(pca.explained_variance_ratio_, decimals=4)*100)

#Eigenvectors
compon=pca.components_.T

#CHECK WITH GENE
#Rescaling the components by the eigenvalues
cc=compon*np.sqrt(explainvar)


###################################################Interpret PCA##############################################################
#Prep row and column labels to interpret 
#Pull the names of the original variables
varnames=list(X.columns.values)
#Create a list of all the PCs, numbered
pcs=[]
for pc in range(0,cc.shape[1]):
    name="PC"+str(pc)
    pcs.append(name)
#Cast as dataframe
cc=pd.DataFrame(cc)
#Name columns
cc.columns=pcs
#Name rows
cc.index=varnames


#Create a list that holds the coordinates of every value that is over the threshold
interpret=[]
#Create a dictionary where each PC is a key, and the list of important variables is the value
answer={}
#Iterate through the PCs
for col in range(0,cc.shape[1]):
    #Pull the name of the PC
    p=pcs[col]
    #Reinstate the list to hold all the info for the given PC
    interpret=[]
    #Iterate thorugh the originally defined variables
    for row in range(0,cc.shape[0]):
        #Pull the loading value
        value=cc.iloc[row,col]
        #Check if the loading is greater than the threshold
        if abs(value)>thresh:
            #Pull the name of the variable, the loading, and assign it to a list
            toadd=[varnames[row],value]
            #Append that list to the master list for the current PC
            interpret.append(toadd)
            
    #Create a new key value pair   
    answer[p]=interpret

#Open file to write results
f=open('pcaouput.doc','w')

#Iterate through each key to output the releated information
for i in pcs:
    print()
    print("The variables that best define "+str(i)+" and their related loadings are: ")
    p=("\n The variables that best define "+str(i)+" and their related loadings are: \n")
    f.write(p)
    for j in range(0,len(answer[i])):
        print('VARIABLE: '+str(answer[i][j][0]) +'    LOADING: '+str(answer[i][j][1]))
        p=('VARIABLE: '+str(answer[i][j][0]) +'    LOADING: '+str(answer[i][j][1]) + '\n')
        f.write(p)

#Receive a list of the top most important variables
#Begin with the variables from PC0 and sort them by the loading values
test=pd.DataFrame.from_records(answer['PC0'],columns=("Var","Load"))
test=test.sort_values('Load',ascending=False)
i=1
#If not enough variables were represented in PC0, iterate through the following components until we have >= desired amount
while (test.shape[0]<numvars):
    iterim=pd.DataFrame.from_records(answer[pcs[i]],columns=("Var","Load"))
    iterim=iterim.sort_values("Load",ascending=False)
    #Append the new variables to the ongoing DF
    test=test.append(iterim,ignore_index=True)
    #Drop any variables that were already represented on a previous PC
    test=test.drop_duplicates(subset=["Var"])
    i+=1

#Take only the number of variables the user specified, and print out the list
topvars=test.iloc[0:numvars,:]
print("The top " + str(numvars)+ " variables are:")
print(topvars['Var'])
#Write this message out to a file
f.write('\n')
p=("The top " + str(numvars)+ " variables are: \n")
f.write(p)
p=str(topvars['Var'])
f.write(p)

#Close the file
f.close()
###################################################Visualize PCA################################################################


#############################################################Eigenvalues of chosen solution
#Plot the progression of the variance explained
fig=plt.figure()
plt.plot(range(1,len(fin_cumvar)+1),fin_cumvar,color='orange',marker='o',label='Cumulative Variance Explained')
plt.bar(range(1,len(fin_cumvar)+1),np.round(pca.explained_variance_ratio_, decimals=4)*100,label="Variance per Componenet")
plt.title("Variance Explained by Principal Component Analysis")
plt.ylabel('Eigenvalue')
plt.xlabel('Number of Components')
plt.xlim(0,len(fin_cumvar)+1)
plt.legend(loc=7)
plt.show()
fig.savefig('finaleig.png')


#############################################################Top variables and their loadings
#Plot the progression of the variance explained
fig=plt.figure(figsize=(18,22))
plt.bar(topvars['Var'],topvars['Load'])
plt.title("Loadings for the Most Important Variables")
plt.ylabel('Loading')
plt.xlabel('Variables')
plt.xlim(0,len(fin_cumvar)+1)
plt.ylim(0.75,.81)
plt.yticks(np.arange(0.75,0.81,step=.005))
plt.xticks(rotation='vertical')
plt.show()
fig.savefig('topvars.png')

#############################################################Unrolled original data on PCs
###Basic scatter plot
fig=plt.figure()
plt.scatter(sol[:,0],sol[:,1])
plt.title("Data Plotted on Principal Components")
plt.ylabel('Second Principal Component')
plt.xlabel('First Principal Component')
plt.show()
fig.savefig('basescatter.png')


####Color coded scatter plot
#Combine the PC solution with the class variable
finalDf = pd.concat([pd.DataFrame(sol[:,0:3]), y['cluster']], axis = 1)

#Set the colors and a list of the unique categories
#Color options:
#'black','gray','rosybrown','red','darksalmon','tan','gold','olivedrab','chartreuse','darkgreen','seagreen','mediumspringgreen'
#'lightseagreen','paleturquoise','darkcyan','darkturpuoise','deepskyblue','navy','blue','mediumpurple','darkorchid','plum','m'
#'mediumvioletred,'palevioletred','orange','fuhsia','deeppink'
colors = ['navy', 'turquoise', 'darkorange','red','green','blue','purple','pink','black','gray','gold','indigo','palevioletred','deeppink']
target_names=list(finalDf['cluster'].unique())

#Plot
fig=plt.figure()
for target, color in zip(target_names,colors):
    indicesToKeep = finalDf["cluster"] == target
    plt.scatter(finalDf.loc[indicesToKeep, 0]
               , finalDf.loc[indicesToKeep, 1]
               , c = color
               , s = 50, label=target)
plt.title('Principal Component Analysis',fontsize=20)
plt.ylabel('Second Principal Component',fontsize=14)
plt.xlabel('First Principal Component',fontsize=14)
plt.legend(loc='best', shadow=False, scatterpoints=1)
plt.show()
fig.savefig('2dcolor.png')


#3D Scatter Plot
fig=plt.figure()
ax=plt.axes(projection='3d')

for target, color in zip(target_names,colors):
    indicesToKeep = finalDf["cluster"] == target
    ax.scatter3D(finalDf.loc[indicesToKeep, 0]
               , finalDf.loc[indicesToKeep, 1]
               , finalDf.loc[indicesToKeep, 2]
               , c = color
               , s = 50, label=target)

#ax.legend(loc=5)
ax.set_title("Data on the First Three Principal Components")
ax.set_ylabel("PC 2")
ax.set_xlabel("PC 1")
ax.set_zlabel("PC 3")
fig.savefig('3dcolor.png')

################################################################Heatmap


#Plot
#Other colors: GnBu
fig=plt.figure(figsize=(23,18))
ax=sns.heatmap(abs(cc),annot=False,linewidths=0,linecolor='gray',cmap="BuGn")
ax.set_title("Loadings Between Original Vars and PCs")
ax.set_ylabel("Variables")
ax.set_xlabel("Principal Components")
fig.savefig('heatmap.png')













