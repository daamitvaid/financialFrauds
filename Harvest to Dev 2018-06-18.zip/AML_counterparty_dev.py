import pyspark, time, json, os, sys
from pyspark.sql import SparkSession, SQLContext, functions as fn
from pyspark.sql.window import Window as w

start_time = time.clock()

conf = (pyspark.SparkConf().set("spark.local.dir", "hdfs:///aml/data/test/").set("spark.executor.memory", "22G"))
sc = pyspark.SparkContext(conf=conf).getOrCreate()
sc = pyspark.SparkContext.getOrCreate()
sqlc = SQLContext(sc)

config_file = "/home/spark/code/AMLAnalyticConfiguration.json" 
label = "COUNTER"

Transactions_CounterIDColumn = ""

# Load json config file and build filepath and variable references by label
if os.path.exists(config_file):
	with open(config_file, 'r') as f:
		config = json.load(f)
		output_dir = config['DataDirectory'] + "/"
		for file in config['Files']:
			globals()[file['Type']+"_sourcepath"] = file['StoredAs']['Path'] + "/"
			globals()[file['Type']] = file['StoredAs']['Name']

			for key, value in file.items():
				exec(file['Type'] + "_" + key + "=value")
elif IOError:
	print("ERROR: Unable to open file " + str(config_file))

ID = "COUNTER_PARTY_ID"
TXN_ID = Transactions_IDColumn
TXN_SECONDARY_ID = Transactions_CounterAccountIDColumn
TXN_CUSTOMER = Transactions_CustomerIDColumn
TXN_AMOUNT = Transactions_AmountColumn
ALERT_CUSTOMER = Alerts_CustomerIDColumn
ALERT_ID = Alerts_IDColumn
ALERT_TXN_ID = AlertTxnMappings_TranIDColumn

Transactions = "Transaction_filtered_by_CXID_forUnit113.csv"
#Transactions = "zion_transaction_test.csv"

def read(filenm, filepath):
	return sqlc.read.csv(filepath + filenm, header=True)

def write(input, output, filepath):
	input.write.csv(filepath + output, mode='overwrite', header=True)

txn = read(filenm=Transactions, filepath=Transactions_sourcepath) 
alrt_txn = read(filenm=AlertTxnMappings, filepath=AlertTxnMappings_sourcepath)

# List of columns that matches label
cp_cols = [col for col in txn.columns if col.startswith(label)]

# Percentage of counterparty records that will be excluded
total_cnt = txn.count()
cptxn_null_cnt = txn.where(fn.col(TXN_SECONDARY_ID).isNull()).count()
cptxn_null_pct = (cptxn_null_cnt / total_cnt)*100

if cptxn_null_cnt > 0:
	print("Note: Excluding {}({}%) records with missing {}".format(cptxn_null_cnt, cptxn_null_pct, TXN_SECONDARY_ID))

# If ID field does not exist in source file - Build unique sequential identifier as ID
# Omit records that have null values for secondary identifier field
if (Transactions_CounterIDColumn =="" or Transactions_CounterIDColumn not in cp_cols):
	print("Counterparty ID is not present in transactions file")
	print("Generating unique sequential id as Counterpart ID")
	
	cp_table = txn.select(TXN_SECONDARY_ID) \
			.filter(fn.col(TXN_SECONDARY_ID).isNotNull()) \
			.distinct() \
			.withColumn(ID, fn.row_number().over(w.orderBy(TXN_SECONDARY_ID)).cast("string"))
else:
	cp_table = txn.select(cp_cols)

print("Counterparty table generated, Saving..")
# Save intermediary table
write(input=cp_table, output='counterparty.csv', filepath=output_dir)

# Join to txn file on counterparty secondary id
txn = txn.join(cp_table.select(ID,TXN_SECONDARY_ID), TXN_SECONDARY_ID, 'left_outer')
print("Counterparty ID merged to transactions")

txn_stats = txn \
		.groupBy(TXN_CUSTOMER) \
		.agg(fn.concat_ws(";", fn.collect_set(ID)).alias('cp_list') \
		    ,fn.countDistinct(ID).cast("double").alias('cp_count') \
		    ,fn.count(TXN_ID).cast("double").alias('txn_count') \
		    ,fn.sum(TXN_AMOUNT).cast("double").alias('txn_sum'))

# Alerted transactions
alrt = read(filenm=Alerts, filepath=Alerts_sourcepath) \
	.join(alrt_txn, ALERT_ID, 'inner')

alrt_stats = txn \
	.join(alrt.select('TRAN_ID'), fn.col(TXN_ID) == alrt.TRAN_ID, 'inner') \
	.groupBy(TXN_CUSTOMER) \
	.agg(fn.concat_ws(";", fn.collect_set(ID)).alias('alertedcp_list') \
	    ,fn.countDistinct(ID).alias('alertedcp_count') \
	    ,fn.count(TXN_ID).cast("double").alias('alertedcp_txn_count') \
	    ,fn.sum(TXN_AMOUNT).cast("double").alias('alertedcp_txn_sum'))

# Percentage of alerted transactions and amount
txn_alrt = txn_stats \
		.join(alrt_stats, TXN_CUSTOMER, 'left_outer') \
		.withColumn('alertedcp_txncount_pct', fn.round((alrt_stats.alertedcp_txn_count/txn_stats.txn_count)*100,2).cast("double"))\
		.withColumn('alertedcp_txnamt_pct', fn.round((alrt_stats.alertedcp_txn_sum/txn_stats.txn_sum)*100,2).cast("double")) \
		.repartition(4)

#Save Results
print("Saving Results")
write(input=txn_alrt, output='CounterpartyByCust.csv', filepath=output_dir)

print("Processing time {} seconds".format(time.clock()-start_time))
sc.stop()
