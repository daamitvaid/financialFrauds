import csv
import os
from pyspark.sql.functions import udf, count, avg, lit, collect_list
from pyspark.sql.types import StringType, ArrayType, IntegerType, DoubleType, BooleanType
from pyspark.sql import SparkSession
def sp_read(spark,path):
  return(spark.read.csv(path, header=True))

def sp_write(df, path):
  return(df.repartition(1).write.csv(path, header=True))

def rename(df, renaming_dict):
  select_cols = []
  for old_name, new_name in renaming_dict.items():
    df = df.withColumnRenamed(old_name, new_name)
    select_cols.append(new_name)

  df = select(df, select_cols)
  return(df)

def select(df, select_cols):
  df = df.select(select_cols)
  return(df)

def spark_filter(input_path,renaming_dict_ind,renaming_dict_biz):
  spark = SparkSession \
  .builder \
  .appName("Python Spark Rule Module") \
  .getOrCreate()

  df = sp_read(spark,input_path)
  df_ind = df.filter(df.CUSTOMER_TYPE_CODE.startswith("R")) 
  df_biz = df.filter(df.CUSTOMER_TYPE_CODE.startswith("C")) 

  df_ind = rename(df_ind, renaming_dict_ind)
  df_biz = rename(df_biz, renaming_dict_biz)
  
  sp_write(df_ind, "file:///data_mapping/output/zion_customers_ind.csv")
  sp_write(df_biz, "file:///data_mapping/output/zion_customers_biz.csv")

def read_csv(file_path):
    temp_dict = {}
    with open(file_path, 'r') as csvfile:
        data_reader = csv.reader(csvfile)
        for index, row in enumerate(data_reader):
            if (index != 0 and len(row[len(row)-1]) != 0):
                temp_dict[row[len(row)-1]] = row[0]
    #print(temp_dict)
    return(temp_dict)

def read_dir(dir_path):
    file_paths = []
    directory = os.path.join(dir_path)
    for root,dirs,files in os.walk(directory):
        for file in files:
            if file.endswith(".csv"):
                file_paths.append(dir_path+"/"+file)
    return(file_paths)

def merge_two_dicts(x,y):
    z = x.copy()
    z.update(y)
    return z

renaming_dict_in = {}
renaming_dict_out = {}
#file_paths = read_dir("./mapping")
#for path in file_paths:
    #renaming_dict = merge_two_dicts(renaming_dict,read_csv(path))
renaming_dict_ind = read_csv("./mapping/Business_Customer.csv")
renaming_dict_biz = read_csv("./mapping/Individual_Customer.csv")
spark_filter("file:///data_mapping/input/customers.csv",renaming_dict_ind,renaming_dict_biz)
