import pyspark, time
from pyspark.sql import SparkSession, SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *

start_time = time.time()

#Set filepath and source filenames
local_dir = "hdfs:///aml/data/test/"
filepath = "hdfs:///aml/data/"
txn_file = "Transaction_filtered_by_CXID_forUnit175.csv"
#txn_file = "transaction_test.csv" 
alrt_file = "alerts_175.csv"

conf = (pyspark.SparkConf().set("spark.local.dir",local_dir ).set("spark.executor.memory", "22G"))
sc = pyspark.SparkContext(conf=conf).getOrCreate()
sqlc = SQLContext(sc)


def read(filenm, filepath):
	return sqlc.read.csv(filepath + filenm, header=True)

def write(input, output, filepath):
	input.write.csv(filepath + output, mode='overwrite', header=True)

#Read input data files
txn = read(filepath=filepath, filenm=txn_file)
alrt = read(filepath=filepath, filenm=alrt_file)

# ** Preprocessing Data **

#Alerts to be excluded
alrt_sub = alrt.filter(col('Escalated_To_Case_Investigation').isin(['YES','NO']))

#Using float to avoid interger division in python2
val = (float(alrt_sub.count())/alrt.count())*100
print("NOTE: {0:.2f}% alert records retained".format(val)) 

#Build aggregated alert dataset
alrt_sub = alrt_sub.groupBy('CUSTOMER_ID') \
		.agg(count(col('Escalated_To_Case_Investigation')).alias('alert_count') \
		     ,count(when(alrt['Escalated_To_Case_Investigation']=='YES',True)).alias('escl_alert_count'))
  

# Derive counterparty unique id based on transaction type
#def cp_func(txn_type):
#    if txn_type in ['Wire', 'TRNST-CKDP', 'ONUS-CKDP']:
#        return txn.COUNTER_PARTY_ACCOUNT_NUM
#udf_func=udf(cp_func,StringType())
#txn = txn.withColumn('COUNTER_PARTY_ID', udf_func(txn['TXN_SOURCE_TYPE_CODE']))

txn = txn.select('CUSTOMER_ID','TXN_ID','TXN_SOURCE_TYPE_CODE','TXN_AMOUNT_BASE','COUNTER_PARTY_ACCOUNT_NUM','COUNTER_PARTY_NAME') \
	.withColumn('COUNTER_PARTY_ID', when(txn.TXN_SOURCE_TYPE_CODE.isin(['Wire','TRNST-CKDP','ONUS-CKDP']),txn.COUNTER_PARTY_ACCOUNT_NUM) \
					.when(txn.TXN_SOURCE_TYPE_CODE=='ACH',regexp_extract(txn.COUNTER_PARTY_NAME, '(\d+)',1)))

#Ignore transaction with no available counterparty number
txn_cp = txn.filter(txn['COUNTER_PARTY_ID'].isNotNull())

#val = (float(txn_cp.count())/txn.count())*100
#print("NOTE: {0:.2f}% transactions with counterparties".format(val))

txn = txn_cp \
	.groupBy('CUSTOMER_ID') \
	.agg(concat_ws(";", collect_set('COUNTER_PARTY_ID')).alias('cp_list') \
	    ,countDistinct('COUNTER_PARTY_ID').alias('cp_count') \
	    ,count('TXN_ID').alias('txn_count') \
	    ,sum('TXN_AMOUNT_BASE').alias('txn_sum'))

#Match alerts to transactions
txn.join(alrt_sub, 'CUSTOMER_ID', 'left_outer') \
	.withColumn('escl_txn_pct', when(col('escl_alert_count')>=1,100).otherwise(0)) \
	.repartition(1) \
	.write.csv(filepath  + "EsclAlert_cp.csv", mode='overwrite', header=True)


print("Processing time {} seconds".format(time.time()-start_time))
sc.stop()