#!/bin/bash
echo SPARK_HOME=$SPARK_HOME >> /srv/shiny-server/amlScatterPlot/.Renviron
echo HDFS_URL=$HDFS_URL >> /srv/shiny-server/amlScatterPlot/.Renviron
shiny-server 2>&1
