#!/bin/bash
#
# Licensed Materials - Property of IBM
#
# IBM Financial Crimes Insight with Watson PID 5900-A0H
# IBM Financial Crimes Insight with Watson, Private PID 5737-E41
#
# (C) Copyright IBM Corp. 2017, 2018  All rights reserved.
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#

httpcode=$(curl -s -I -w '\n%{http_code}\n' http://localhost:3838 | tail -n1)
echo "http_code=" $httpcode

if [ $httpcode -ne 200 ];
then
	# not started
	echo "Shiny server not started"
	exit 1
else
	# started
	echo "Shiny server started"
	exit 0
fi