#!/bin/bash
# 
# Licensed Materials - Property of IBM
#
# IBM Financial Crimes Insight with Watson PID 5900-A0H  
# IBM Financial Crimes Insight with Watson, Private PID 5737-E41
# 
# (C) Copyright IBM Corp. 2017, 2018  All rights reserved.
# 
# The source code for this program is not published or otherwise divested  
# of its trade secrets, irrespective of what has been deposited with the  
# U. S. Copyright Office. 
# 
# US Government Users Restricted Rights - Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#

set -x
echo SPARK_HOME=$SPARK_HOME >> /srv/shiny-server/amlScatterPlot/.Renviron
echo HDFS_URL=$HDFS_URL >> /srv/shiny-server/amlScatterPlot/.Renviron

HOST=$(echo $HDFS_URL | grep -Po 'hdfs://\K[^:]+')
sed -i "s/namenode_host/${HOST}/g" /home/shiny/hadoop/hdfs-site.xml

echo "Starting Shiny Server....."
# sudo systemctl start shiny-server
shiny-server 2>&1
set +x
