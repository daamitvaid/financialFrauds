# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

##TODO NOTE: I have not yet found a way to make the dataset global between server and UI, or even within
#server itself (between functions). Currently every reactive or output that requires the dataset has to
#reload it, which is horrendously inefficient and will probably cause problems if the dataset is very large.
#This will need to be fixed eventually, if possible.

#Set the working directory to be where the config code is
setwd("/srv/shiny-server/amlScatterPlot/analytics")

#Load the code for configuration loading
source("AML_utils.R")
source("FCAI_Clustering_common.R")

#get the analytic configuration from the config file
readAnalyticConfig(reset=TRUE)

#Make sure the spark master is local, anything else will break
AMLAnalyticConfig$Sparklyr$master <- "local"
assign("AMLAnalyticConfig", AMLAnalyticConfig, envir = .GlobalEnv)

#open a spark connection
sc <- sparkConnect()
assign("sc", sc, envir = .GlobalEnv)

#save the entire "Analytics" block
allAnalytics <- AMLAnalyticConfig$Analytics

#Acquire columns from the clustering aggregate
customerIDColumn <- getAggregateByColumnNames("Transactions", "ByBeneficiary")

server <- function(input, output, session) {

  #Reset newclusteringConfig to account for a new reasonType (investigate why this has to happen since getScatterData is a reactive)
  newclusteringConfig <- NULL

  getScatterData <- reactive({ #Function that retrieves the clustering data (differentiated by reasonType in the config file)

    #Parse out the URL
    queryReasonType <- parseQueryString(session$clientData$url_search)

    if (length(queryReasonType) > 0)#If the URL contains parameters...
    {
      for (i in 1:length(queryReasonType))#Step through each parameter...
      {
        if (names(queryReasonType)[[i]] == "reasonType")#If a "reasonType" parameter is found...
        {
          #Save the reasonType parameter and exit the loop
          reasonType <- queryReasonType[[i]]
          break
        }
      }

      if(!is.na(reasonType))#If a reasonType parameter was found in the URL...
      {
        for (i in 1:length(allAnalytics)) #step through each analytic block...
        {
          #Look for an analytic block titled AnomalyClustering and containing a ReasonType that matches the reasonType tag from the URL
          if (allAnalytics[[i]]$Type == "AnomalyClustering" && allAnalytics[[i]]$Results$ReasonType == reasonType)#If the AnomalyClustering block is found...
          {
            #Save the AnomalyClustering block and exit the loop
            newclusteringConfig <- allAnalytics[[i]]
            break
          }
        }

        if (length(newclusteringConfig) > 0) #If an analytic block was found...
        {
          #Find the filename of the file that contains the scatter data
          scatterDataFile <- getAnomalyClusterFileName(newclusteringConfig, newclusteringConfig$Plotting$ScatterPlot$ColumnData,"csv")

          #Load the data from the file
          #scatterDataSpark <- readInput(scatterDataFile, path=AMLAnalyticConfig$DataDirectory) #hdfs data directory on the cluster, needs to have hostname
          scatterDataSpark <- readInput(scatterDataFile, path=Sys.getenv(c("HDFS_URL"))) #Acquiring the url from environment variables
          
          #Transform the data into a normal dataframe format
          scatterData <- tbl_df(scatterDataSpark)

          #Return the dataframe
          return(scatterData)
        }
        else #If no analytic block was found that had a ReasonType that matches the reasonType tag from the URL...
        {
          #Stop the program and send an error message (without a reason type, there isn't data, and without data to plot there can't be a plot)
          stop("Matching ReasonType was not found inside the configuration. Please check the reasonType parameter.")
        }
      }
      else #If the query does not contain a reasonType tag...
      {
        #Stop the program and send an error message (without a reason type, there isn't data, and without data to plot there can't be a plot)
        stop("The URL needs to include a 'reasonType' parameter in order to plot the correct dataset")
      }
    }
    else #If the query contains no parameters...
    {
      #Stop the program and send an error message (without a reason type, there isn't data, and without data to plot there can't be a plot)
      stop("The URL needs to include a 'reasonType' parameter in order to plot the correct dataset")
    }
  })

  selectedData <- reactive({ #Function that grabs the data contained in the two columns selected in the dropdown menus

    #Acquire the full data set
    scatterData <- getScatterData()

    #Return data only from the two selected input columns (from the dropdown menus)
    scatterData[, c(input$xcol, input$ycol)]

  })
  
  selectedCustomerID <- reactive({ #Function that returns the ID of the selected customer to highlight
    
    #Acquire the full data set
    scatterData <- getScatterData()
    
    #Parse out the URL
    query <- parseQueryString(session$clientData$url_search)
    
    if (length(query) > 0)#If the URL contains parameters...
    {
      for (i in 1:length(query))#Step through each parameter...
      {
        if (names(query)[[i]] == "partyId")#If a "partyId" parameter is found...
        {
          #Save the partyId parameter and exit the loop
          customerID <- query[[i]]
          break
        }
        else #If the query does not contain a partyId tag...
        {
          #Automatically select the first customer in the data set as the customer to highlight on the plot
          customerID <- scatterData[[customerIDColumn]][[1]]
        }
      }
    }
    else #If the URL does not contain parameters...
    {
      #Automatically select the first customer in the data set as the customer to highlight on the plot
      customerID <- scatterData[[customerIDColumn]][[1]]
    }
    return(customerID)
  })

  selectedCustomerIDData <- reactive({ #Function that grabs the data of the selected customer to highlight

    #Acquire the full data set
    scatterData <- getScatterData()

    #Parse out the URL
    query <- parseQueryString(session$clientData$url_search)

    if (length(query) > 0)#If the URL contains parameters...
    {
      for (i in 1:length(query))#Step through each parameter...
      {
        if (names(query)[[i]] == "partyId")#If a "partyId" parameter is found...
        {
          #Save the partyId parameter and exit the loop
          customerID <- query[[i]]
          break
        }
        else #If the query does not contain a partyId tag...
        {
          #Automatically select the first customer in the data set as the customer to highlight on the plot
          customerID <- scatterData[[customerIDColumn]][[1]]
        }
      }
    }
    else #If the URL does not contain parameters...
    {
      #Automatically select the first customer in the data set as the customer to highlight on the plot
      customerID <- scatterData[[customerIDColumn]][[1]]
    }

    #Return a single row of the selected customer ID containing data from the two menu selected columns
    return(scatterData[scatterData[[customerIDColumn]] == customerID, c(input$xcol, input$ycol)])
  })

  selectedLegendShapesArray <- reactive({ #Function that ensures the correct shapes on the legend regardless of cluster amount

    #Acquire the full data set
    scatterData <- getScatterData()

    #return a list of circles with length matching the number of clusters (21 is code for a filled in circle)
    list(rep(21, length(names(table(scatterData$cluster)))))
  })

  output$plot2 <- renderPlot({ #Define the plot

    #Acquire the full data set
    scatterData <- getScatterData()
    
    #Acquire the cluster names
    clusterNames <- names(table(scatterData$cluster))
    
    #Turn cluster IDs into a vector of strings
    clusterString = paste(names(table(scatterData$cluster)))
    
    #Add text to the beginning of each cluster name
    clusterString <- paste("peer group ",clusterString, sep="")

    #Pre define the available cluster colors (currently allows for 20 different clusters)
    palette(c("red", "cornflowerblue", "green3","cyan", "magenta", "orange", "gray", "chartreuse", "black", "rosybrown1", 
              "mediumblue", "slategray1", "mediumpurple2", "gold", "darkgoldenrod3", "firebrick4", "plum", "yellow4", "purple4", "palegoldenrod"))
    par(xpd = T, mar = par()$mar + c(0,0,0,7))

    #Each customerID will be plotted as a filled in circle, and the fill color will differ between cluster labels
    #Additionally, the 'selected' customer will always be plotted as a yellow triangle to differentiate it from the others. The triangle's border will be the color of the cluster
    #that the selected customer belongs to.
    plot(selectedData(), #Plot the dataset containing just the two selected input columns (but all customers)
         col = 9,
         pch = 21, cex = 2, bg = scatterData$cluster)
    points(selectedCustomerIDData(), #Plot the selected customer data as a yellow triangle with outline colored the color of it's cluster
           col = scatterData$cluster[which(scatterData[[customerIDColumn]] == selectedCustomerID())],
           pch = 24, cex = 2, bg = "yellow", lwd=3)
    legend("right", inset=c(-.14, .1), pt.bg = (c("yellow", names(table(scatterData$cluster)))), #Render the legend
    legend=(c("selected party", clusterString)), pch = (c(24, selectedLegendShapesArray()[[1]])), cex = 1, title = "Parties in...")
    
    par(mar=c(5, 4, 4, 2) + 0.1) 
    })

  output$xColMenu <- renderUI({ #Form the drop down menu that selects the X axis data

    #Acquire the full data set
    scatterData <- getScatterData()
    
    #selScatterData <- subset(scatterData, select=-customerIDColumn)
    selScatterData <- scatterData[ , -which(names(scatterData) %in% customerIDColumn)]

    #Populate the drop down menu with the column names of the dataset
    selectInput('xcol', '1st Feature: X Axis', names(selScatterData))

  })

  output$yColMenu <- renderUI({ #Form the drop down menu that selects the Y axis data

    #Acquire the full data set
    scatterData <- getScatterData()
    
    #selScatterData <- subset(scatterData, select=-customerIDColumn)
    selScatterData <- scatterData[ , -which(names(scatterData) %in% customerIDColumn)]

    #Populate the drop down menu with the column names of the dataset. Initialize the menu
    #to show the second column first, just to differentiate it from the X menu at the outset
    selectInput('ycol', '2nd Feature: Y Axis', names(selScatterData), selected=names(selScatterData)[[2]])

  })
}

ui <- fluidPage(
                 #Scatterplot
                          pageWithSidebar(
                            headerPanel('Scatterplot 2D View: Parties in Peer Groups by Feature'), #Render the title
                            sidebarPanel(
                              uiOutput("xColMenu"), #Render the X axis column selection menu
                              uiOutput("yColMenu")  #Render the Y axis column selection menu
                            ),
                            mainPanel(
                              plotOutput(outputId = 'plot2', width = "100%") #Render the plot
                            )
                          )

)

shinyApp(ui = ui, server = server)
