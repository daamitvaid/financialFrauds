#install.packages("shiny", "ggplot2")
library("shiny")
library("ggplot2")

setwd("/srv/shiny-server/amlShinyApp")
heatmap_data<-read.csv("heatmap_data.csv")
scatter_data<-read.csv("scatter_data.csv")
table_data<-read.csv("table_data.csv")

navbarPage("AML",
           #tab panel1: AML Cluster and Customer View----
           tabPanel("AML Cluster and Customer View",
                    # fluidPage(
                    verticalLayout(
                      titlePanel("AML Clustering Insights"),
                      plotOutput("plot1"),
                      fluidRow(
                        #4= is the width
                        column(2,selectInput("CustomerID",
                                             "CustomerID:",
                                             c("All",unique(table_data$CustomerID)))
                        ),
                        column(2,selectInput("Cluster",
                                             "Cluster:",
                                             c("All",unique(as.character(table_data$Cluster))))
                        )),
                      column(2, selectInput("Risk_Level",
                                            "Risk Level:",
                                            c("All",unique(as.character(table_data$Risk))))
                      )),
                    # Create a new row for the table.
                    fluidRow(DT::dataTableOutput("table")
                             #  )
                    )),
           #tab panel2: Scatterplot----
           tabPanel("Scatterplot",
                    pageWithSidebar(
                      headerPanel('AML Cluster 2D View'),
                      sidebarPanel(
                        selectInput('xcol', 'X Variable', names(scatter_data)),
                        selectInput('ycol', 'Y Variable', names(scatter_data),
                                    selected=names(scatter_data)[[2]]),
                        numericInput('clusters', 'Cluster count', 6,
                                     min = 1, max = 6)
                      ),
                      mainPanel(
                        plotOutput('plot2')
                      )
                    )
                    
           )
)

