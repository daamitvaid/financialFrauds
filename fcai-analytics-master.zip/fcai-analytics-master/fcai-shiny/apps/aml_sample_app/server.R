setwd("/srv/shiny-server/amlShinyApp")
heatmap_data<-read.csv("heatmap_data.csv")
scatter_data<-read.csv("scatter_data.csv")
table_data<-read.csv("table_data.csv")

function(input, output) {
  output$plot1 <- renderPlot({
    #Heatmap----
    ggplot(data = heatmap_data,
           #aes describes the elements which are taking part in the heatmap
           aes(x = as.factor(Cluster), y = variable, fill = rescale,
               label = value, color = "1")) +
      #geom_tile draws rectangulars with missing values removed silently (not in calc)
      geom_tile(na.rm = T) +
      #the color of text inside boxes
      geom_text(color = "black")+
      #color of the gradient
      scale_fill_gradient(low = "red",high = "green") +
      #scale_color_manual=color of the lines between boxes
      scale_color_manual(values = "grey90") +
      #scale_x and scale_y manipulate our axes
      #expand=c(0,0) means No extra space around plot
      scale_x_discrete(expand = c(0, 0)) +
      scale_y_discrete(expand = c(0, 0)) +
      ylab("Cluster Features") + xlab("Clusters") +
      coord_flip() +
      #theme control all non-data components of the plot
      theme(panel.background = element_rect(fill = "grey90"),
            panel.grid = element_blank(),
            panel.border = element_rect(fill = NA,color = "grey80"),
            legend.position = "none") +
      theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))
  })
  #Table ----
  output$table <- DT::renderDataTable(DT::datatable({
    data <- table_data
    if (input$CustomerID != "All") {
      data <- data[data$CustomerID == input$CustomerID,]
    } 
    if(input$Cluster !="All"){
      data<-data[data$Cluster == input$Cluster,]
    }
    if(input$Risk_Level !="All"){
      data<-data[data$Risk == input$Risk_Level,]
    }
    data }))
  #Scatterplot----
  selectedData <- reactive({
    scatter_data[, c(input$xcol, input$ycol)]
  })
  
  selectedData <- reactive({
    scatter_data[, c(input$xcol, input$ycol)]
  })
  
  clusters <- reactive({
    kmeans(selectedData(), input$clusters)
  })

  output$plot2 <- renderPlot({
    palette(c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
              "#FF7F00", "#FFFF33", "#A65628", "#F781BF", "#999999"))
    
    par(mar = c(5.1, 4.1, 0, 1))
    plot(selectedData(),
         col = clusters()$cluster,
         pch = 20, cex = 3)
    points(clusters()$centers, pch = 4, cex = 4, lwd = 4)
  }) 
}
