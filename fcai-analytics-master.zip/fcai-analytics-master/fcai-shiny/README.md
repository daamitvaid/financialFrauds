# fcai-shiny
Docker image for FCAI visualizations hosted in Shiny Server
