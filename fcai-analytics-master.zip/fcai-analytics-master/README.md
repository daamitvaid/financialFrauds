# FCAI Analytics

## Analytics Flow

Here are the high-level flows for the analytics.   

**Note:** The '*' in the flows below should be substituted with the appropriate suffix:
- test: for running in the R client
- spark: for submission to a spark cluster

### Transaction Flow
Multiple Input Files (transactions, customers, scored alerts) -> AML_process_transactions.R -> AML_assessment.R -> Scored transactions -> DB2 scoring bands

### Alert Flow
Alert file (AML_sample_alert.csv) -> AML_ingestAlerts_*.R -> AML_ingestAlerts.R -> DB2 insights

## System Configuration

### R configuration (Development Environments)
The following instructions are for setting up an environment for analytics development. The instructions assume that R has been installed as well as a Java development environment (required by the `rJava` packages). In addition, on Linux after installing the SDK run the following command:

`R CMD javareconf`

The following packages must be installed in R:

- `install.packages("magrittr")`
- `install.packages("zoo")`
- `install.packages("jsonlite")`
- `install.packages("dplyr")`
- `install.packages("data.table")`
- `install.packages("rJava")`
- `install.packages("RJDBC")`
- `install.packages("caret")`
- `install.packages("e1071")`
- `install.packages("mlbench")`
- `install.packages("NbClust")`
- `install.packages("randomForest")`
- `install.packages("sparklyr")`

If the environment does not have Spark installed, sparklyr can be used to install a copy using the following instructions.

At a command prompt, type `R` to open an R terminal then enter the following commands:
- `library(sparklyr)`
- `spark_install(version="2.2.0")`
- `q()`

Finally, the `db2jcc4.jar` (available on the db2 node) must be copied to the current directory and the `AML_db2_connection.json` file updated with the db2 connection information before running any R programs that interact with db2. See following:

#### DB2 configuration: `AML_db2_connection.json`
The default db2 connection file (from github) looks like the following:
~~~
{
	"driverClass" : "com.ibm.db2.jcc.DB2Driver",
	"driverJar" : "db2jcc4.jar",
	"dbUrl": "jdbc:db2://[host]:[port]/[db]:currentSchema=ALERT_REVIEW;sslConnection=true;sslCertLocation=/[dir]/db2.crt",
	"dbUser": "[user]",
	"dbPassword": "[password]"
}
~~~
with the following values needing to be set (the values should already be populated correctly when the environment is setup using the FCAI installer).

- `host` - name of the db2 server host (must be resolvable by the client machine)
- `port` - the db2 server port, will be 30500 (for non-SSL) or 30600 (for SSL) in an installed environment
- `db` - the database name, will be `amldb` in an installed environment
- `dir` - the directory containing the db2 certificate
- `user` - the username for accessing the db
- `password` - the dbUser's password (base64 encoded)

If accessing a non-SSL port on the db, the `dbUrl` can be simplified to:
~~~
jdbc:db2://[host]:[port]/[db]:currentSchema=ALERT_REVIEW
~~~
### Sample data
The `sample_data/*.csv` files need to be copied to the directory containing the R files (if running the analytics through the R client) or to the prescribed directories if running through Spark (see the Spark Client instructions below).

In addition, the AML db needs to be prepped to allow alerts and associated data to be stored. The following sql commands should be executed:

~~~~
INSERT INTO ALERT_REVIEW.ALERT_DISPOSITIONS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Unknown', 'The alert disposition is unknown.', 'unknown');
INSERT INTO ALERT_REVIEW.ALERT_DISPOSITIONS (NAME, DESCRIPTION, TYPEDEF) VALUES ('SAR', 'A SAR was filed for the alert.', 'sar');
INSERT INTO ALERT_REVIEW.ALERT_DISPOSITIONS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Non-SAR', 'No SAR was filed for the alert.', 'non-sar');

INSERT INTO ALERT_REVIEW.ALERT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Unknown', 'The alert status is unknown', 'unknown');
INSERT INTO ALERT_REVIEW.ALERT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Open', 'The alert is open', 'open');
INSERT INTO ALERT_REVIEW.ALERT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Closed', 'The alert is closed', 'closed');

INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Unknown', 'Unknown type', 'unknown');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Checking', 'Checking account', 'chk');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Money Market', 'Money market account', 'mm');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Savings', 'Savings account', 'sav');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Retirement','Retirement Account','retire');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Investment','Investment Account','inv');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Loan','Loan Account','loan');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Health Savings','Health Savings Account','hlth sav');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Insurance Policy','Insurance Policy','ins');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Credit Card','Credit Card','cc');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Stored Value Card','Stored Value Card','svcard');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Term Deposit','Term Deposit','term');
INSERT INTO ALERT_REVIEW.ACCOUNT_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Others','Others','o');

INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Unknown', 'Unknown', 'unknown');
INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Active', 'The account is active', 'a');
INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Closed', 'The account is closed', 'c');
INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Inactive','Inactive','i');
INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Dormant','Extended inactivity','d');
INSERT INTO ALERT_REVIEW.ACCOUNT_STATUS (NAME, DESCRIPTION, TYPEDEF) VALUES ('Purge','Purge','x');

INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Overall', 'Overall score', 'overall');
INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Anomaly', 'Anomaly score', 'anomaly');
INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Geo', 'Location score', 'location');
INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Customer', 'Customer score', 'customer');
INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('Rounding', 'Rounding rule score', 'rounding');
INSERT INTO ALERT_REVIEW.REASON_TYPE (NAME, DESCRIPTION, TYPEDEF) VALUES ('FPTP', 'False positive / True positive score', 'fptp');

INSERT INTO ALERT_REVIEW.TRANSACTION_TYPE (NAME, DESCRIPTION, TYPEDEF,IS_CREDIT,IS_DEBIT) VALUES ('Unknown', 'Unknown', 'unknown','Y','Y');
INSERT INTO ALERT_REVIEW.TRANSACTION_TYPE (NAME, DESCRIPTION, TYPEDEF,IS_CREDIT,IS_DEBIT) VALUES ('ACH', 'Automated Clearing House', 'ach','Y','Y');
INSERT INTO ALERT_REVIEW.TRANSACTION_TYPE (NAME, DESCRIPTION, TYPEDEF,IS_CREDIT,IS_DEBIT) VALUES ('ATM', 'Automated Teller Machine', 'atm','Y','Y');
INSERT INTO ALERT_REVIEW.TRANSACTION_TYPE (NAME, DESCRIPTION, TYPEDEF,IS_CREDIT,IS_DEBIT) VALUES ('Wire', 'Wire Transfer', 'wire','Y','Y');

~~~~
**NOTE:** In an environment created by the FCAI installer (or using the FCAI db2 docker container) the following task has already been performed and does not need to be executed.

Update the path to the `CountryData.csv file` in the following command and then run the import to popuate the COUNTRY table.
~~~~
db2 "IMPORT FROM CountryData.csv OF DEL METHOD P(1,2,3,4,5,9) SKIPCOUNT 1 INSERT_UPDATE INTO \"ALERT_REVIEW\".COUNTRY (COUNTRY_ID,NAME,ISO2,ISO3,ISONUMERIC,TYPEDEF)"
~~~~
## Analytics Configuration
The default configuration files can be used to work with the included sample files.  
- `AMLAnalyticConfiguration.json` is configured to read the files from the hadoop file system (`/aml/data` directory).
- If executing on a non-hadoop environment such as a development system, copy the `AMLAnalyticConfiguration_test.json` to `AMLAnalyticConfiguration.json`.

If using different inputs the `AMLAnalyticConfiguration.json` file can be edited to allow the analytics to be executed on different data sources. The following is a brief description of the configuration options available:
- `Sparklyr` - Spark connection details
- `CountryType` - The country type used in the input files, should be one of `Name`, `ISO2`, `ISO3`, or `ISONumeric`
- `DataDirectory` - Directory for storing analytics artifacts (a hadoop directory by default, a local directory in the test configuration)
- `ModelDirectory` - Directory for storing analytic models, should not be a hadoop directory and must be accessible from each node
- `WriteResultsToDB` - Optionally run the analytics without writing the results to the database
- `Training` - Contains references to the transactions and scored alerts to be used for model training
- `Files` - Contains references to the alerts, countries (country risk data), customers and transactions used in the analytics.
- `Rules` - Defines variables and thresholds for analytic rules
- `AlertProcessing` - Defines parameters to be used when processing alerts
- `Analytics` - Defines the analytics to be executed

Each File object contains the following entries:
- `Type` - Record type that the source contains
- `StoredAs`:
  - `Name` - the csv file or hive table name
  - `Type` - must be `csv` or `hive`
  - `Path` - directory containing the `csv` file (not used for `hive`)
  - `Delimiter` - column separator in the `csv` file (optional, defaults to `;`)
  - `Debug` - for aggregation output, will print the head of the aggregated data to the log
- *`Column Definitions`* - the column names to be used when reading the source.  If the source does not contain an equivalent column, the value should be set to "".

The configuration for the aggregators and analytics are covered in the following sections.

### Aggregators
In addition to the fields detailed previously, a `File` element can contain one or more Aggregators. An aggregator is defined with the following fields:
- `AggregateName` - the reference name of the aggregator
- `AggregateBy` - one or more columns used to group the data, values must be keys referencing columns in the parent file.
- `StoredAs` - the csv file to store the resuting aggregated statistics (currently only csv is supported as output)
- `AggregateFeatures` - one or more operations to perform on the grouped data, the following operations and the associated fields are currently supported:

  - `Operation: summarizeBySum` - for the specified column and timerange(s), sum the value of the column and calculate min, max and mean
    - `Column` - the column to be summed, must be the identifier of one of the columns in the parent file.
    - `BaseLabel` - root for the resulting column names, will be be appended with stat and timerange
    - `TimeRanges` - an array of timeranges

  - `Operation: summarizeByStats` - for the specified column and timerange(s) calculate min, max and mean
    - `Column` - the column, must be the identifier of one of the columns in the parent file.
    - `BaseLabel` - root for the resulting column names, will be be appended with stat and timerange
    - `TimeRanges` - an array of timeranges

  - `Operation: summarizeByCount` - for the timerange(s), count the occurrences and calculate min, max and mean
    - `BaseLabel` - root for the resulting column names, will be be appended with stat and timerange
    - `TimeRanges` - an array of timeranges

  - `Operation: summarizeByCountGrouped` - for the specified columns and timerange(s), count the occurrences and calculate min, max and mean
    - `GroupingColumns` - the secondary columns to be grouped and counted, must be the identifier of one of the columns in the parent file.
    - `BaseLabel` - root for the resulting column names, will be be appended with stat, grouping column and timerange
    - `TimeRanges` - an array of timeranges

  - `Operation: summarizeByFrequency` - derive the time between occurrences and calculate min, max and mean
    - `BaseLabel` - root for the resulting column names, will be be appended with the stat (i.e. `Frequency_Avg`)

- `JoinFeatures` - one or more operations to join additional columns to the aggregated data, the following operations and the associated fields are currently supported:

  - `Operation: copyExternalColumn` - copy a column from another datasource into the aggregate data

    - `Label` - the name to be used for the column in the aggregated data
    - `Source` - one or more data sources for the column, if more than one they will be combined (rowwise) prior to joining to the aggregate data
      - `Type` - reference to a file record type (ex. `Individuals`) defined in the configuration
      - `Column` - the column to be copied from the datasource
      - `JoinColumns` - the keys for the columns in the datasource used to join the data to the aggregate data. Must correspond to the columns defined as the `AggregateBy` columns

- `GII` - If this element is present General Interestingness Index (GII) processing will be performed on the aggregated data.  This element consists of the following fields:
	- `Weights` - The weights to be applied when calculating the GII
		- `FPS1` - weight for the ratio of missing to valid records
		- `FPS3` - weight for the number of outliers
		- `FPS4` - weight for Skewness
		- `FPS5` - weight for Standard Deviation
		- `FPS6` - weight for Kurtosis

		**NOTE:** the weights are automaically standardized to sum to 1.
	- `StoredAs` - the csv file to store the GII results (currently only csv is supported as output)

### Analytics Execution Configuration
The analytics to be executed (in addition to the aggregation) are configured in the `Analytics` array, which can contain one or more analytic configuration objects. The following fields are common across all analytic types, although additional configuration fields will be required for most analytic types.

- `Type` - the type of analytic to be executed, the out-of-the-box analytics are `AnomalyClustering`, `Univariate`, `SupervisedML`, and `CountryRisk`.
- `Source` - the R file to be sourced to run the analytic; this R file should contain the `BandingFunction`, `AssessmentFunction`, and `ArtifactsFunction` (if defined)
- `Results` - details how the analytic results should be handled
	- `Weight` - the weighting of this analytic within the overall analytic score. **NOTE:** the weights of all analytics are automatically standardized to sum to 1.
	- `ReasonType` - the reason type for this analytic. This is the primary identifier for the analytic instance and should be unique across all analytics defined within the configuration. This value must also be defined as a reason type `NAME` in the `"ALERT_REVIEW.REASON_TYPE"` table.
	- `ScoreColumn` - the column within the results containing the score. The analytics will write to this column and the alert processing will read the data in this column for alert scoring.
	- `InsightColumn` - the column within the results containing the insights. The analytics will write the insights to this column (in json format) and the alert processing will pass the data in this column display in the FCAI user interface.
- `BandingFunction` - function to be called to calculate the scores over the full set of input data, provides the banding ranges for this analytic instance.
- `AssessmentFunction` - function to be called to score a set of data, will return the data with the `ScoreColumn` and `InsightColumn` populated.
- `ArtifactsFunction` - function to be called to return any artifacts that should be stored with the model audit artifacts after processing.
- `InputSource` - the data source(s) to be as input for the analytics
	- `SourceType` - one of `Aggregate`, `File`, or `Function`, with each of these types containing additional fields:
		- *Aggregate*
			- `Type` - the file type for the aggregate, defined within a `Files` entry in the configuration
			- `AggregateName` - the aggregate within the file type
			- `Thrd_GII` - GII threshold, should be between 0 and 1 (optional). If specified, the input data will be filtered so that only features with a GII greater than the threshold will be included in the analytic processing.
		- *File*
			- `Type` - the file type, defined within a `Files` entry in the configuration
			- `AddTimes` - calculate and append time ranges to the data (optional)
			- `Columns` - subset of columns from the data to be used in the analytic (optional)
		- *Function*
			- `Source`: the R file to be sourced (contains the function)
			- `FunctionName`: the function to be executed to retrieve the source data

Additional parameters for each of the out-of-the-box analytics are detailed below.

#### AnomalyClustering
- `Thrd_Crlt` - threshold of correlation cutoff
- `Thrd_GII` - GII threshold, should be between 0 and 1. Only features with a GII greater than the threshold will be included in the analytic processing.

#### CountryRisk
No additional parameters

#### SupervisedML
- `FP_Training_only` - do false positive training only rather than training and validation
- `TP_Training_only` - do true positive training only rather than training and validation
- `Debug` - output partial intermediate values to the log
- `InputSource` - the input source for supervised machine learning can be complex, with multiple inputs joined into a single input source. So the `InputSource` for supervisedML can be an array if using multiple input sources (or a simple object similar to the other analytics if only a single source is required). If using multiple sources, the first array entry is the primary source and should contain all of the id columns required to join the additional sources. The input sources require additional parameters to allow the joins to be done:
	- *InputSource[1]*
		- `CountryColumns` - optional, an array of country columns within this source to allow country risk to be included in the supervisedML
		- `IDColumns` - an array of ID columns
	- *InputSource[2-n]*
		- `JoinColumnsX` - an array of the column IDs from InputSource[1] to be used in the join
		- `JoinColumnsY` - an array of the column IDs from this InputSource to be used in the join
- `TagSource` - an additional input source that contains tagged results. The source will usually be a SourceType of File with the corresponding parameters (`Type`,`AddTimes`,`Columns`) and requires the following additional parameters:
	- `TagColumn` - the column containing the tagged results (true positive, etc)
	- `TagTrueValues` - an array of values that represent true positives
	- `JoinColumnsX` - an array of the column IDs from InputSource[1] to be used in the join
	- `JoinColumnsY` - an array of the column IDs from the tag source to be used in the join

#### Univariate
**Note:** The Univariate analysis can only be executed on an InputSource SourceType of `Aggregate`
- `ScoringCurve` - The curve type to be used for scoring the data. Select from `Growth` or `Decline`
- `GroupingSource` - an additional input source that contains a column to allow grouping of the InputSource data. In addition to the normal InputSource parameters, the GroupingSource requires the following additional parameters:
	- `IDColumn` - the column to be used in the join with the InputSource (should correspond to the AggregateBy column specified for the aggregate)
	- `PeerGroupColumn` - the column containing the grouping information

## Analytics Execution

### Installed Environment
These are the steps for running the analytics in an environment created by the FCAI installer. To run the analytics in a development environment see [Analytics Execution - Development Environment](#development-environment)

#### Data ingestion.
To initiate a file ingestion through Flume, you must copy the input file to the `/amldata` directory on the gateway computer. Each file name must be unique. For instance, you can include the time stamp (date +%s) in the file name.

##### Ingest Entity data
In a fully configured system, the organization and individual data will be supplied by the CEDM integration. However, if a CEDM environment is not available and FCAI needs data to work on the following steps can be followed:

###### Copy the organization data.
Copy the organizations data to hdfs:

`hdfs dfs -copyFromLocal  /opt/ibm/aml/sample/AML_sample_organizations.csv /aml/data`

Update the `AMLAnalyticConfiguration.json` Organizations source:
~~~
"StoredAs": {
	"Name": "AML_sample_organizations.csv",
	"Type": "csv",
	"Path": "hdfs:///aml/data"
},
~~~

###### Copy the individuals data.
Copy the individuals data to hdfs:

`hdfs dfs -copyFromLocal  /opt/ibm/aml/sample/AML_sample_individuals.csv /aml/data`

Update the `AMLAnalyticConfiguration.json` Individuals source:
~~~
"StoredAs": {
	"Name": "AML_sample_individuals.csv",
	"Type": "csv",
	"Path": "hdfs:///aml/data"
},
~~~

##### Ingest account data.
The file name pattern that is used to identify an accounts file is `^accounts-.*\.csv$`. An example command is:

`cp /opt/ibm/aml/sample/AML_sample_accounts.csv /amldata/accounts-$(date +%s).csv`

This will result in the csv file being processed by the flume agent and stored in the `aml_account` hive table.

##### Ingest account mapping data.
Account mappings is a file that contains mappings between accounts and parties. The file name pattern that is used to identify an account mappings file is `^accountmappings-.*\.csv$`. An example command is:

`cp /opt/ibm/aml/sample/AML_sample_accountMapping.csv /amldata/accountmappings-$(date +%s).csv`

This will result in the csv file being processed by the flume agent and stored in the `aml_accountmappings` hive table.

##### Ingest alert transaction mapping data.
The file name pattern that is used to identify an alert transaction mappings file is `^alerttxmappings-.*\.csv$`. An example command is:

`cp /opt/ibm/aml/sample/AML_sample_alertTxnMapping.csv /amldata/alerttxmappings-$(date +%s).csv`

This will result in the csv file being processed by the flume agent and stored in the `aml_alerttxmapping` hive table.

##### Ingest transactions data.
The file name pattern that is used to identify a transaction file is `^transactions-.*\.csv$`. An example command is:

`cp /opt/ibm/aml/sample/AML_sample_transactions.csv /amldata/transactions-$(date +%s).csv`

This will result in the csv file being processed by the flume agent and stored in the `aml_transaction` hive table.

##### Ingest alert data
The file name pattern that is used to identify an alerts file is `^alerts-.*\.csv$`. An example command is:

`cp /opt/ibm/aml/sample/AML_sample_alert.csv /amldata/alerts-$(date +%s).csv`

This will result in the csv file being processed by the flume agent, written to the hdfs filesystem (`/aml/<current date>`) and then processed by `preprocessAlert.sh`. This script will split the incoming csv file into files with no more than X number of lines - where X is set as the last argument in the `AML_Alerts.sinks.alerts-sendtoexec-sink.arguments` parameter for the `AML_Alerts` flume agent (the default is 1000). Each split file will be created in the same directory with the original filename plus a three character suffix (`aaa`, etc).

#### Model training
The following commands must be executed on the gateway machine as user `flume` from the `/home/spark/code` directory.

##### Supervised machine learning model
Run the following command to create the supervised machine learning models:

`Rscript AML_supervisedML_FPTP_batch.R`

The transaction file and the scored alerts file to be used will be read from the `AMLAnalyticConfiguration.json` file using the `Transactions` and `Alerts` Training -> Files entries respectively.

##### Customer clustering model
Run the following command to create the customer clustering models:

`Rscript FCAI_AnomalyClustering_batch.R`

The transaction file to be used will be read from the `AMLAnalyticConfiguration.json` file using the `Transactions` Training -> Files entry.

#### Analytic Scoring Bands
To create the analytic score bands on the ingested transactions, a cron job can be configured or the analytics can be initiated manually by running the following command (as flume):

`/opt/ibm/aml/bin/merge_compact_and_rscript.sh -r /home/spark/code/AML_process_transactions.R`

This step needs to be done at least once, but it only needs to be done again to regenerate the scoring bands.

#### Alert processing
**Note:** All ingestions of the input files should be complete before running the alert processing.

To perform the alert processing, run the following command as `flume`:

`/opt/ibm/aml/bin/ingestAlerts.sh > >(tee -a /var/log/flume/AML_IngestAlerts.log) 2>&1`

This program will look for and process all *split* files in yesterday's and today's hdfs data directories (`/aml/<date>`). When the processing for each split file is completed, the file will be deleted. If any of the split files fail when being processed, the file will be renamed with an extension of `.failed`.

### Development Environment

These are the steps for running the analytics in a development environment. To run the analytics in environment created by the FCAI installer see [Analytics Execution - Installed Environment](#installed-environment)

Using the downloaded AML/aml-analytics repo, in the `analytics` directory, backup the `AMLAnalyticConfiguration.json` file then copy the `AMLAnalyticConfiguration_test.json` file to `AMLAnalyticConfiguration.json`. This file is preconfigured to use files contained in the `sample_data` directory as inputs and is configured to **not** require a db for transaction processing.  In addition, since hive is not used, the data ingestion steps are not used in the development environment.

#### Model training
The following commands must be exeucted from the `analytics` directory.

##### Supervised machine learning model
Run the following command to create the supervised machine learning models:

`Rscript AML_supervisedML_FPTP_batch.R`

The transaction file and the scored alerts file to be used will be read from the `AMLAnalyticConfiguration.json` file using the `Transactions` and `Alerts` Training -> Files entries respectively. Optionally, a different Transactions source (and type) can be specified as arguments on the command line.

##### Customer clustering model
Run the following command to create the customer clustering models:

`Rscript FCAI_AnomalyClustering_batch.R`

The transaction file to be used will be read from the `AMLAnalyticConfiguration.json` file using the `Transactions` Training -> Files entry. Optionally, a different Transactions source (and type) can be specified as arguments on the command line.

#### Transaction processing
`Rscript AML_process_transactions.R`

By default the `Transactions` file specified in `AMLAnalyticConfiguration.json` will be used as the transactions source. A different transactions source (and type) can be specified on the command line as follows:

`Rscript AML_process_transactions.R /temp/mytransactions.csv csv`

`Rscript AML_process_transactions.R mytransactions hive`

#### Alert processing
`Rscript AML_ingestAlerts_test.R`

By default the `Alerts` file specified in `AMLAnalyticConfiguration.json` will be used as the alerts source. A different alerts source (and type) can be specified on the command line as follows:

`Rscript AML_ingestAlerts_test.R /temp/myalerts.csv csv`

`Rscript AML_ingestAlerts_test.R myalerts hive`
