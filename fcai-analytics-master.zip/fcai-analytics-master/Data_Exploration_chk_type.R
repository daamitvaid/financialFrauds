###setwd("c:/IBM_CFM/R_work/WestPac/")
#rm(list = ls())
library(magrittr)
library(zoo)
library(plyr)
library(dplyr)

filename <- "AML_sim_data_v4.csv"
master_input <- read.csv(filename, header=T)

###size
dim(master_input)

message(paste("no. of records = ", nrow(master_input)))
message(paste("no. of variables = ", ncol(master_input)))

###find out the structure of the data fields
#str(master_input)

###attribute
#attributes(master_input)

###another summary
#library(Hmisc)
#describe(master_input[,c(1,5)])   # check columns 1 and 5

###get subset of columns that are numeric
nums_col <- sapply(master_input, is.numeric)
master_input_num <- master_input[, nums_col]
###get subset of columns that are not numeric
master_input_cat <- master_input[, !nums_col]

message(paste("no. of numerical variables = ", length(master_input_num)))
message(paste("no. of categorical variables = ", length(master_input_cat)))

message(paste("numerical variables structure before : "))
str(master_input_num)

### manual modify type
#master_input$ALERTKEY <- as.factor(master_input$ALERTKEY)
#master_input$CASEKEY <- as.factor(master_input$CASEKEY)
#master_input$RELATED_WC_UID <- as.factor(master_input$RELATED_WC_UID)
#master_input$DNYOB <- as.factor(master_input$DNYOB)


###get subset of columns that are numeric
nums_col <- sapply(master_input, is.numeric)
master_input_num <- master_input[, nums_col]
###get subset of columns that are not numeric
master_input_cat <- master_input[, !nums_col]


message(paste("numerical variables structure after : "))
message(paste("no. of numerical variables = ", length(master_input_num)))
message(paste("no. of categorical variables = ", length(master_input_cat)))

str(master_input_num)

  
  