###setwd("c:/IBM_CFM/R_work/WestPac/")
rm(list = ls())
library(magrittr)
library(zoo)
library(plyr)
library(dplyr)
library(corrgram)
###determine the right data type for each column first
source("Data_Exploration_chk_type.R")


###can separate input into more refined categories: factor/integer/logical/numeric (through class to fine these)
master_input_type <- split(names(master_input), sapply(master_input, function(x) paste(class(x), collapse="")))
factor_var <- names(master_input) %in% master_input_type$factor
integer_var <- names(master_input) %in% master_input_type$integer
logical_var <- names(master_input) %in% master_input_type$logical
numeric_var <- names(master_input) %in% master_input_type$numeric
master_input_factor <- master_input[factor_var]
master_input_integer <- master_input[integer_var]
master_input_logical <- master_input[logical_var]
master_input_numeric <- master_input[numeric_var]

input_cat_NA_cnt <- NULL
input_num_NA_cnt <- NULL
###finding missing count for each variable/column
if(ncol(master_input_factor) == 0){
    print("no factor variables")
}else{
    master_input_factor[master_input_factor==""] <- NA
    input_factor_NA_cnt <- apply(is.na(master_input_factor),2,sum)
    NZ_input_factor_NA_cnt <- input_factor_NA_cnt[input_factor_NA_cnt>0]
    print("factor variables with NA count:")
    print(NZ_input_factor_NA_cnt)
    input_cat_NA_cnt <- c(input_cat_NA_cnt, NZ_input_factor_NA_cnt)
}
if(ncol(master_input_integer) == 0){
    print("no integer variables")
}else{
    master_input_integer[master_input_integer==""] <- NA
    input_integer_NA_cnt <- apply(is.na(master_input_integer),2,sum)
    NZ_input_integer_NA_cnt <- input_integer_NA_cnt[input_integer_NA_cnt>0]
    print("integer variables with NA count:")
    print(NZ_input_integer_NA_cnt)
    input_num_NA_cnt <- c(input_num_NA_cnt, NZ_input_integer_NA_cnt)
}
if(ncol(master_input_logical) == 0){
    print("no logical variables")
}else{
    master_input_logical[master_input_logical==""] <- NA
    input_logical_NA_cnt <- apply(is.na(master_input_logical),2,sum)
    NZ_input_logical_NA_cnt <- input_logical_NA_cnt[input_logical_NA_cnt>0]
    print("logical variables with NA count:")
    print(NZ_input_logical_NA_cnt)
    input_cat_NA_cnt <-c(input_cat_NA_cnt, input_logical_NA_cnt)
}
if(ncol(master_input_numeric) == 0){
    print("no numeric variables")
}else{
    master_input_numeric[master_input_numeric==""] <- NA
    input_numeric_NA_cnt <- apply(is.na(master_input_numeric),2,sum)
    NZ_input_numeric_NA_cnt <- input_numeric_NA_cnt[input_numeric_NA_cnt>0]
    print("numeric variables with NA count:")
    print(NZ_input_numeric_NA_cnt)
    input_num_NA_cnt <- c(input_num_NA_cnt, NZ_input_numeric_NA_cnt)
}

###consolidate into two category 
###find variables with more than x% missing records
cat_NA_10p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.1]
num_NA_10p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.1]
cat_NA_20p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.2]
num_NA_20p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.2]
cat_NA_30p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.3]
num_NA_30p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.3]
cat_NA_40p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.4]
num_NA_40p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.4]
cat_NA_50p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.5]
num_NA_50p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.5]
cat_NA_60p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.6]
num_NA_60p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.6]
cat_NA_70p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.7]
num_NA_70p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.7]
cat_NA_80p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.8]
num_NA_80p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.8]
cat_NA_90p <- input_cat_NA_cnt[input_cat_NA_cnt >= nrow(master_input)*0.9]
num_NA_90p <- input_num_NA_cnt[input_num_NA_cnt >= nrow(master_input)*0.9]

### plot the bar chart to show the distribution
### 
cat_NA_all <- c(length(cat_NA_10p), length(cat_NA_20p),length(cat_NA_30p),length(cat_NA_40p),length(cat_NA_50p), length(cat_NA_60p),length(cat_NA_70p),length(cat_NA_80p),length(cat_NA_90p))
num_NA_all <- c(length(num_NA_10p), length(num_NA_20p),length(num_NA_30p),length(num_NA_40p),length(num_NA_50p), length(num_NA_60p),length(num_NA_70p),length(num_NA_80p),length(num_NA_90p))

miss_percent <- c(10,20,30,40,50,60,70,80,90)
cat_NA_chart <- c(miss_percent, cat_NA_all) 
num_NA_chart <- c(miss_percent, num_NA_all)
cat_NA_chart <- matrix(cat_NA_chart, nrow = 9, ncol=2)
num_NA_chart <- matrix(num_NA_chart, nrow = 9, ncol=2)
cat_NA_chart <- data.frame(cat_NA_chart)
num_NA_chart <- data.frame(num_NA_chart)
colnames(cat_NA_chart) <- c("pcnt", "yvar") 
colnames(num_NA_chart) <- c("pcnt", "yvar") 


ggplot(cat_NA_chart, aes(pcnt,yvar)) + geom_point()+scale_x_continuous("percentage")+ scale_y_continuous("No. of categorical variables")
ggplot(num_NA_chart, aes(pcnt,yvar)) + geom_point()+scale_x_continuous("percentage")+ scale_y_continuous("No. of numerical variables")

###get min/max/mean/median/1Q/3Q for integer and numeric column
###get top 7 levels and count for each level
###get logical flag (mode: logical) and the count for each logical value 
#input_summary_factor <- summary(master_input_factor)
#input_summary_integer <- summary(master_input_integer)
#input_summary_logical <- summary(master_input_logical)
#input_summary_numeric <- summary(master_input_numeric)

input_summary_num <- summary(master_input_num)
input_summary_cat <- summary(master_input_cat)
#write.csv(input_summary_cat,"cat_variable_summary.csv")
#write.csv(input_summary_num, "num_variable_summary.csv")


##unique count of each categorial variable (column)
input_LevelCount_cat <- apply(master_input_cat, 2, function(x)length(unique(x))) 

### get rid of variable with only one level
master_input_cat_eliminate <- master_input_cat[input_LevelCount_cat <=1]
message(paste("no. of categorial variables with one level = ", ncol(master_input_cat_eliminate)))

message(paste("categorical variables removed due to only 1 level= "))
#print(colnames(master_input_cat_eliminate))
print(unique(master_input_cat[input_LevelCount_cat<=1]))
master_input_cat_rds <- master_input_cat[input_LevelCount_cat >=2]

message(paste("no. of categorial variables after filtering = ", ncol(master_input_cat_rds)))
cat_var_dropped <- names(master_input) %in% c(colnames(master_input_cat_eliminate))
master_input_rds <-master_input[!cat_var_dropped]

### show a bar chart for the number of variables with different levels

###1.Technically Correct Data: known data type and real-world domain
### ***check if all data within the same column follow the desired data type
## throw error if numeric column contain extra characters when enforce with numeric in reading
## e.g. read.csv("filename", header=FALSE, colClasses = c('numeric', 'numeric'))
##work around :
##      df1 <-read.csv("filename", header=FALSE, col.names = c("xxx", "yyy"), stringsAsFactors = False)
##       df1$yyy <- as.numeric(df1$yyy)
##   note: the data with extra characters will still be NA
##  ***Use readLines if records run over/short

##  ***Type Conversion (from number to categorial)
##     example: gender <- c(2,1,1,2,0,1,1)
##    recode <- c(male=1, female=2)
##    gender <- factor(gender, levels = recode, labels = names(recode)))

##  ***Dates conversion 1
##      POSICct=calendar time; POSICt = time;
##      library(lubridate)
##      dates <- c("15/02/2013", "15 Feb 13", "It happened on 15 02 13") 
##      Need to know the sequence and apply one of the following function dmy;myd;ydm;mdy;dym;ymd
##      dmy(dates) will give "2013-02-15 UTC"

##  ***Dates conversion 2
##     Use R's core function : as.POSIXct
##     date <- c("15-9-2009", "16-07-2008", "17 21-2007", "29-02-2011")
##     as.POSIXct(date, format = "%d-%m-%Y")    ** %a=> Mon; %A=>Monday;  %b=>Sep;  %B=> September; %y=> year without century
##     =>"2009-05-15 CEST" "208-07-16 CEST"   NA   NA
##     
##   *** string manipulation 1 
##     use format to create text : 
##     mydate <- dmy("28 Sep 1976")
##    format(mydate, format = "I was born on %B %d, %Y")
##    "I was born on September 28, 1976"
##
##   *** string manipulation 2 : string normalization
##       library(stringr)
##       str_trim("  hello world ") => "hello world"
##       str_trim(" hello world ", side = "left")  => "hello world "
##       str_pad(112, with = 6, side = "left", pad = 0)  => "000112"

##   *** string manipulation 3 : string matching
##       gender <- c("M", "male", "Female", "fem.")
##       grep1("m", gender) => FALSE TRUE TURE TURE
##       grep("m", gender) => 2 3 4
##       grep1("m", gender, ignore.case = TRUE)   => TRUE TRUE TRUE TRUE
##       grep1("m", tolower(gender))   => TRUE TRUE TRUE TRUE
##       ***search string begin with "m"
##       grep1("^m", gender, ignore.case =TRUE)  => TRUE TRUE FALSE FALSE
##                              

###2.Consistent Data:  data fit for statistical analysis
### *** Detection of an inconsistency 
## checking missing data count for each record
record_chk_miss_num <- complete.cases(master_input_num)
record_chk_miss_cat <- complete.cases(master_input_cat_rds)
record_chk_miss <- complete.cases(master_input_rds)
no_complete_record_num <- length(record_chk_miss_num[record_chk_miss_num==TRUE])
no_complete_record_cat <- length(record_chk_miss_cat[record_chk_miss_cat==TRUE])
no_complete_record <- length(record_chk_miss[record_chk_miss==TRUE])

message(paste("no. of complete numerical records = ", no_complete_record_num))
message(paste("no. of complete categorical records = ", no_complete_record_cat))
message(paste("no. of complete records = ", no_complete_record))

## checking every numerical column if there is special value (Inf, NaN, NA)
is.special <- function(x){
  if (is.numeric(x)) !is.finite(x) else is.na(x)
}
record_chk_special_num <- sapply(master_input_num, is.special)

## checking outlier using Tukey's method : 
#boxplot.stats(master_input_num, coef=1.5)$out 
                               
## checking outlier using Hiridoglou :   (suggest r >1.5)
hboutlier <- function(x,r) {
  x <- x[is.finite(x)]
   stopifnot(
   length(x) > 0, all(x>0)
   )
   xref <- median(x)
   if (xref <= sqrt(.Machine$double.eps))
   warning ("Reference value close to zero : results may be inaccurate")
   pmax(x/xref, xref/x) > r
}



run_age_cal <- 0

if (run_age_cal ==1){
###get dates information for calculatin age 
getdate <- as.Date(master_input$DOB, "%Y-%m-%d")
getday <- substr(master_input$DOB,1,2)
getmonth <- substr(master_input$DOB,4,5)
getyr <- substr(master_input$DOB,7,10)

age_calc <- function(dob, enddate=Sys.Date(), units='months'){
  if (!inherits(dob, "Date") | !inherits(enddate, "Date"))
    stop("Both dob and enddate must be Date class objects")
  start <- as.POSIXlt(dob)
  end <- as.POSIXlt(enddate)

  years <- end$year - start$year
  if(units=='years'){
    result <- ifelse((end$mon < start$mon) | 
                      ((end$mon == start$mon) & (end$mday < start$mday)),
                      years - 1, years)    
  }else if(units=='months'){
    months <- (years-1) * 12
    result <- months + start$mon
  }else if(units=='days'){
    result <- difftime(end, start, units='days')
  }else{
    stop("Unrecognized units. Please choose years, months, or days.")
  }
  return(result)
}

Age <- age_calc(getdate, units="years") 
}

run_edit_rule <- 0
if (run_edit_rule ==1){
## checking for obvious inconsistencies using rules : TRUE means violate the rule(s)
library(editrules)
Edit_rule <- editfile("Edit_rule_test.txt")
check_rules_out <- violatedEdits(Edit_rule, master_input)
summary(check_rules_out)
#plot(check_rules_out)
plot(Edit_rule)
}
    
### localize errs 
### principle of Fellegi and Holt = errors occur relatively few times and when they do, they occur randomly across variables
#le <- localizeErrors(Edit_rule, master_input, method="mip")
### minimal set of variables to be altered  (for each record, show what variables need to be altered)
#le$adapt

###Fixing inconsistent by Data filtering 
### using deducorrect (to organize log of actions performed in a text file)

run_plot <- 0
if (run_plot ==1){
library(ggplot2)          
#// 1.scatter plot
ggplot(master_input_num, aes(LOCATION_MATCH, TOTAL_SCORE)) + geom_point() + scale_x_continuous("Location Match")+ scale_y_continuous("Total Score")+ theme_bw()
#ggplot(input_type_numeric, aes(LOCATION_MATCH, TOTAL_SCORE)) + geom_point() + scale_x_continuous("Location Match", breaks = seq(0,0.35,0.05))+# scale_y_continuous("Total Score", breaks = seq(0,270,by = 30))+ theme_bw()
#// 2.Histogram
ggplot(master_input_num, aes(TOTAL_SCORE)) + geom_histogram(binwidth = 2)+
  scale_x_continuous("Total Score")+
  scale_y_continuous("Count")+
  labs(title = "Histogram")
#//3.Bar chart
ggplot(master_input_num, aes(TOTAL_SCORE)) + geom_bar(fill = "red")+theme_bw()+
  scale_x_continuous("Total Score") +
  scale_y_continuous("Count") +
  coord_flip()+ labs(title = "Bar Chart") + theme_gray()  
#//4.Box Plot  
ggplot(master_input_rds, aes(ADDRESS_TYPE, TOTAL_SCORE)) + geom_boxplot(fill = "red")+
scale_y_continuous("Total Score")+
labs(title = "Box Plot", x = "Outlet Identifier")
#//5. Area Map
ggplot(master_input_rds, aes(TOTAL_SCORE)) + geom_area(stat = "bin", bins = 30, fill = "steelblue") + scale_x_continuous(breaks = seq(0,5,5))+ labs(title = "Area Chart", x = "Total Score", y = "Count")
#//6.Heat Map
ggplot(master_input_rds, aes(ADDRESS_TYPE, NAME_MATCH))+
  geom_raster(aes(fill = TOTAL_SCORE))+
  labs(title ="Heat Map", x = "ADDRESS_TYPE", y = "NAME_MATCH")+
  scale_fill_continuous(name = "TOTAL_SCORE")
#//7. Correlogram
#install.packages("corrgram")
#library(corrgram)
corrgram(master_input_rds, order=NULL, panel=panel.shade, text.panel=panel.txt,
           main="Correlogram")  
}
