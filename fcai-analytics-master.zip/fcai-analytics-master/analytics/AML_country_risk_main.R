# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

##Add Country risk score to each transaction based on both customer country and counter Country

#rm(list = ls())
#library(magrittr)
#library(zoo)
#library(jsonlite)
#library(dplyr)

txCustomerCountryCol <- getColumnName("Transactions", "CustomerCountryColumn")
txCounterCountryCol <- getColumnName("Transactions", "CounterCountryColumn")

#external source for country risk
df <- tbl_df(loadData("Countries"))
countryMatchName <- ifelse(AMLAnalyticConfig$CountryType != "Name", AMLAnalyticConfig$CountryType, "Country")
testdata <- data.frame(df[c(countryMatchName,"RiskScore","RiskRank","RiskRating")])

names(testdata) <- c("KeyID", "score", "rank", "rating")
testdata$peer <- 1

#Purpose : normalized the score to between 0 - 1000 (newscore) by selected peer group
source("AML_country_risk.R")
#output : testdata (add new column, newscore)
#names(testdata)
##"KeyID"    "score"    "rank"     "rating"   "peer"     "newscore"

dtData <- loadData("Transactions",addTimes=TRUE)

#names(dtData)
## [1] "RecordID"        "CustomerID"      "TransID"         "TransDate"       "CounterCountry"
## [6] "Amount"          "TenderType"      "CustomerCountry" "OriginatorID"    "BeneficiaryID"
##[11] "Timestamp"       "Day"             "Year"            "Month"           "Week"
##[16] "Quarter"

#add country risk based on customerCountry
testdata <- select(testdata, -rank, -peer)
countryData <- copy_to(sc, testdata, "countryrisk", overwrite=TRUE)
countryData %<>% rename_(.dots = setNames("KeyID",txCustomerCountryCol))
countryData %<>% rename("CustomerScore" = "score")
countryData %<>% rename("CustomerRating" = "rating")
countryData %<>% rename("CustomerNewScore" = "newscore")
dtData %<>% left_join(countryData, by = txCustomerCountryCol)

#add country risk based on counterCountry
counterData <- copy_to(sc, testdata, "counterrisk", overwrite=TRUE)
counterData %<>% rename_(.dots = setNames("KeyID",txCounterCountryCol))
counterData %<>% rename("CounterScore" = "score")
counterData %<>% rename("CounterRating" = "rating")
counterData %<>% rename("CounterNewScore" = "newscore")
dtData %<>% left_join(counterData, by = txCounterCountryCol)

#for each TXN define country risk score based on average of CustomerScore and CounterScore
#can also based on max
dtData <- mutate(dtData, GeoScore = 1/2 * (CustomerScore+CounterScore))
dtData <- mutate(dtData, GeoNewScore = 1/2 * (CustomerNewScore+CounterNewScore))

dtData <- mutate(dtData, CountryINSG = paste('{"CustCntryScore":',
  round(CustomerNewScore,2),',"CntCntryScore":',
  round(CounterNewScore,2),'}',sep=""))
