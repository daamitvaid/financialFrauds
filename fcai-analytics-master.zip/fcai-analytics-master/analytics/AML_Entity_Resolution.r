# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

#################################### SPSS G2 ENTITY RESOLUTION STREAM TRANSLATION ########################################################
##                                                                                                                                      ##
## The script below translates first 4 super nodes (1 to 4) of G2 SPSS stream CASE_FOCUS_SIT.v12 into R scripts ##########################
## There are two parameters EQUIV_DISP_CODE and TRAN_INSIGHT_CODE that have different values for rules 1 to 4 of G2 SPSS streams #########
## A dataframe of values of the aforesaid two parameters for each rule 1 to 4 is created##################################################
## NOTE : For production deployment, it may be good to put this list in a file instead of hard-coding below ##############################
## The R script runs the transformations on each set of values and aggregates the results for each supernode in the SPSS stream ##########
## The script is implemented as a function which takes the rule values as arguments and transforms the input dataset as required #########
## The function is implemented using R library sqldf using SQLite scripts. If required a DB2 SQL script can replace the R script below ###
##                                                                                                                                      ##
##                                                                                                                                      ##
##                                                                                                                                      ##
## DEVELOPED BY : ANISH DIXIT                                                                                        DATE : 20-SEP-2017 ##
##########################################################################################################################################





######################################################## SCRIPT INPUTS ###################################################################

######################################################
## CHANGE THIS TO CORRECT INPUT FILE                ##
######################################################
filename <-
  "C:/Users/IBM_ADMIN/Downloads/CASE_FOCUS_RESUME.V1.2.csv"



######################################################
## THIS CAN BE CHANGED TO READ FROM A CONFIG FILE   ##
######################################################
# Define the parameters
param_list <-
  t(
    data.frame(
      "INSIGHT_ID_1" = c(1,		"'ESCALATED'"					,				"'FOCUS-PREV-ESC'"),
      "INSIGHT_ID_2" = c(2,		"'SUBJ2INQ'"				,				"'FOCUS-PREV-SUBJ2INQ'"),
      "INSIGHT_ID_3" = c(3,		"'ESCALATED'"					,				"'FOCUS-PREV-ESC-CLOSE'"),
      "INSIGHT_ID_4" = c(4,		"'SUBJ2INQ'"					,				"'FOCUS-PREV-SUBJ2INQ-CLOSE'"),
      stringsAsFactors = FALSE
    )
  )




##################################################### START OF SCRIPT ####################################################################

## Import the required R packages
library(readr)
library(plyr)
library(sqldf)

## Read the input file
inputdataset <- read_csv(filename)

## Define the function for the transformations
rules_function <- function(param0, param1, param2) {
  dataset1 <- sqldf(
    "	SELECT
    SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    JURISDICTION,
    LINE_OF_BUSINESS,
    COUNTRY_CODE,
    PRIVACY_GROUP,
    EA_ID,
    EA_DEGREE,
    EA_SOURCE,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    SUBSTR(CASE_DT,1,10) AS CASE_DT,
    CASE_STATUS,
    EQUIV_DISP_CODE,
    ANY_TRAN_ESCALATED,
    SUBSTR(CASE_DISP_DT,1,10) AS CASE_DISP_DT,
    FOCUS_TYPE,
    ACCT_TYPE,
    FOCUS_PARTY,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    FOCUS_PREV_ESC_RESOLVED_CPARTY_RECENCY AS RESOLVED_CPARTY_RECENCY,
    FOCUS_PREV_ESC_RESOLVED_FOCUS_RECENCY AS RESOLVED_FOCUS_RECENCY,
    FOCUS_PREV_ESC_ENABLE AS ENABLE
    FROM inputdataset"
  )
  
  dataset3 <- sqldf("SELECT *
                    FROM dataset1
                    WHERE ENABLE='YES'")
  
  dataset5 <- sqldf(
    "	SELECT *
    FROM dataset3
    WHERE
    EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'"
  )
  
  sql <- sprintf(
    "SELECT *
    FROM dataset3
    WHERE
    (EA_SOURCE ='CASE_CPARTY'
    OR EA_SOURCE ='CASE_FOCUS')
    AND CASE_STATUS = 'C'
    AND EQUIV_DISP_CODE = %s
    AND EA_DEGREE=0",
    param1
  )
  dataset6 <- sqldf(sql)
  
  dataset8 <- sqldf(
    "	SELECT
    dataset6.EA_ID,
    dataset6.SOURCE_CODE,
    dataset6.JURISDICTION,
    dataset6.LINE_OF_BUSINESS,
    dataset6.COUNTRY_CODE,
    dataset6.EA_SOURCE,
    dataset6.CASE_NUM,
    dataset6.EQUIV_DISP_CODE,
    dataset6.ANY_TRAN_ESCALATED,
    dataset6.CASE_DISP_DT,
    dataset6.ACCT_TYPE,
    dataset6.RESOLVED_CPARTY_RECENCY,
    dataset6.RESOLVED_FOCUS_RECENCY,
    dataset5.SOURCE_KEY,
    dataset5.DB_INSTANCE,
    dataset5.PRIVACY_GROUP,
    dataset5.CUST_ID,
    dataset5.CASE_DT AS [INPUT.CASE_DT],
    dataset5.FOCUS_PARTY,
    dataset5.OPS_CENTER,
    dataset5.CASE_FOCUS_ID,
    dataset5.CASE_CPARTY_ID,
    (julianday(dataset6.CASE_DISP_DT) - julianday(dataset5.CASE_DT)) AS RECENCY
    FROM
    dataset5
    INNER JOIN
    dataset6
    USING (EA_ID)
    WHERE
    julianday(dataset6.CASE_DISP_DT) - julianday(dataset5.CASE_DT)>=0"
  )
  
  dataset9 <- sqldf(
    "	SELECT
    dataset5.SOURCE_CODE,
    dataset5.SOURCE_KEY,
    dataset5.DB_INSTANCE,
    dataset5.JURISDICTION,
    dataset5.LINE_OF_BUSINESS,
    dataset5.COUNTRY_CODE,
    dataset5.PRIVACY_GROUP,
    dataset5.EA_SOURCE_KEY,
    dataset5.CUST_ID,
    dataset5.ACCT_NUM,
    dataset5.CASE_NUM,
    dataset5.CASE_STATUS,
    dataset5.FOCUS_PARTY,
    dataset5.OPS_CENTER,
    dataset5.CASE_FOCUS_ID,
    dataset5.CASE_CPARTY_ID,
    dataset5.CASE_ALERT_ID,
    dataset5.RESOLVED_CPARTY_RECENCY,
    dataset5.RESOLVED_FOCUS_RECENCY,
    dataset8.EA_SOURCE,
    dataset8.CASE_NUM AS [HIST.CASE_NUM],
    dataset8.EQUIV_DISP_CODE,
    dataset8.ANY_TRAN_ESCALATED,
    dataset8.CASE_DISP_DT,
    dataset8.DB_INSTANCE AS [HIST.DB_INSTANCE],
    dataset8.[INPUT.CASE_DT],
    dataset8.OPS_CENTER AS [HIST.OPS_CENTER],
    dataset8.RECENCY
    FROM
    dataset8
    LEFT JOIN
    dataset5
    USING(EA_ID)
    UNION ALL
    SELECT
    dataset5.SOURCE_CODE,
    dataset5.SOURCE_KEY,
    dataset5.DB_INSTANCE,
    dataset5.JURISDICTION,
    dataset5.LINE_OF_BUSINESS,
    dataset5.COUNTRY_CODE,
    dataset5.PRIVACY_GROUP,
    dataset5.EA_SOURCE_KEY,
    dataset5.CUST_ID,
    dataset5.ACCT_NUM,
    dataset5.CASE_NUM,
    dataset5.CASE_STATUS,
    dataset5.FOCUS_PARTY,
    dataset5.OPS_CENTER,
    dataset5.CASE_FOCUS_ID,
    dataset5.CASE_CPARTY_ID,
    dataset5.CASE_ALERT_ID,
    dataset5.RESOLVED_CPARTY_RECENCY,
    dataset5.RESOLVED_FOCUS_RECENCY,
    dataset8.EA_SOURCE,
    dataset8.CASE_NUM AS [HIST.CASE_NUM],
    dataset8.EQUIV_DISP_CODE,
    dataset8.ANY_TRAN_ESCALATED,
    dataset8.CASE_DISP_DT,
    dataset8.DB_INSTANCE AS [HIST.DB_INSTANCE],
    dataset8.[INPUT.CASE_DT],
    dataset8.OPS_CENTER AS [HIST.OPS_CENTER],
    dataset8.RECENCY
    FROM
    dataset5
    LEFT JOIN
    dataset8
    USING(EA_ID)"
  )
  
  dataset11 <- sqldf(
    "SELECT
    *,
    CASE
    WHEN (Recency >= 0 AND RESOLVED_FOCUS_RECENCY = 999) THEN 'YES'
    WHEN (RESOLVED_FOCUS_RECENCY >= Recency AND Recency >= 0) THEN 'YES'
    ELSE 'NO'
    END AS [Recency_Condition(FOCUS)]
    FROM dataset9"
  )
  
  sql <- sprintf(
    "SELECT
    *,
    CASE
    WHEN date([INPUT.CASE_DT]) > date('now') THEN 'CASE_DT_ERROR'
    WHEN EA_SOURCE ='CASE_FOCUS' and [Recency_Condition(FOCUS)]='YES' THEN %s
    ELSE 'NONE'
    END AS TRAN_INSIGHT_CODE
    FROM dataset11",
    param2
  )
  dataset12 <- sqldf(sql)
  
  
  ###################################################
  #################SUPER NODE 1######################
  
  sql <- sprintf(
    "SELECT
    *,
    CASE
    WHEN TRAN_INSIGHT_CODE = 'CASE_DT_ERROR' THEN 'CASE-DATE-INVALID'
    WHEN TRAN_INSIGHT_CODE = %s THEN 'PREV ROLE: FOCUS'
    ELSE NULL
    END AS PREV_ROLE
    FROM dataset12
    WHERE TRAN_INSIGHT_CODE <> 'NONE'",
    param2
  )
  dataset14 <- sqldf(sql)
  
  dataset15 <- sqldf(
    "SELECT *
    FROM dataset14
    GROUP BY
    [HIST.CASE_NUM],
    [HIST.DB_INSTANCE],
    [HIST.OPS_CENTER]
    HAVING MIN(ROWID)
    ORDER BY ROWID"
  )
  
  dataset17 <- sqldf(
    "SELECT
    *,
    'CASE_NUM: ' || [HIST.CASE_NUM] ||'; DB_INSTANCE: '|| [HIST.DB_INSTANCE] || '; OPS_CENTER: ' || [HIST.OPS_CENTER] ||' ' AS [RESUME.CASE_NUM],
    ROWID AS ROWNUM
    FROM dataset15
    ORDER BY date(CASE_DISP_DT)"
  )
  
  dataset18 <- sqldf(
    "SELECT
    *,
    CASE
    WHEN ROWNUM = 1
    THEN [RESUME.CASE_NUM]
    ELSE
    (SELECT [RESUME.CASE_NUM]
    FROM dataset17
    LIMIT -1
    OFFSET 1)
    || ', ' || [RESUME.CASE_NUM]
    END AS TEMP_VAR
    FROM dataset17"
  )
  
  ##################REDUNDANT BLOCK OF CODE###########
  #dataset19 <- sqldf("	UPDATE dataset18
  #						SET TEMP_VAR = CASE
  #						WHEN ROWNUM = 1
  #						THEN [RESUME.CASE_NUM]
  #						ELSE
  #							(SELECT [RESUME.CASE_NUM]
  #							FROM dataset17
  #							LIMIT -1
  #							OFFSET 1 )
  #							|| ', ' || [RESUME.CASE_NUM]
  #						END")
  ####################################################
  
  sql <- sprintf(
    "SELECT
    *,
    CASE TRAN_INSIGHT_CODE
    WHEN 'CASE_DT_ERROR' THEN 'CASE-DATE-INVALID'
    WHEN %s THEN PREV_ROLE || '; Previous Cases ' || TEMP_VAR
    ELSE NULL
    END AS TRAN_INSIGHT_MEMO
    FROM dataset18",
    param2
  )
  dataset20 <- sqldf(sql)
  
  dataset21 <- sqldf(
    "SELECT *
    FROM dataset20
    GROUP BY CASE_NUM
    HAVING MIN(ROWID)
    ORDER BY ROWID;
    
    SELECT *
    FROM dataset21
    ORDER BY TRAN_INSIGHT_MEMO DESC"
  )
  
  ##############END OF SUPER NODE 1##################
  ###################################################
  
  dataset22 <- sqldf(
    "SELECT
    SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    JURISDICTION,
    LINE_OF_BUSINESS,
    COUNTRY_CODE,
    PRIVACY_GROUP,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    CASE_STATUS,
    FOCUS_PARTY,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    EA_SOURCE,
    [HIST.CASE_NUM],
    EQUIV_DISP_CODE,
    CASE_DISP_DT,
    [HIST.DB_INSTANCE],
    [INPUT.CASE_DT],
    [HIST.OPS_CENTER],
    TRAN_INSIGHT_CODE,
    PREV_ROLE,
    [RESUME.CASE_NUM],
    ROWNUM,
    TEMP_VAR,
    TRAN_INSIGHT_MEMO
    FROM dataset21"
  )
  
  dataset23 <- sqldf(
    "SELECT
    *,
    CASE
    WHEN (Recency >= 0 AND RESOLVED_CPARTY_RECENCY = 999) THEN 'YES'
    WHEN (RESOLVED_CPARTY_RECENCY >= Recency AND Recency >= 0) THEN 'YES'
    ELSE 'NO'
    END AS [Recency_Condition(CPARTY)]
    FROM dataset9"
  )
  
  sql <- sprintf(
    "SELECT
    *,
    CASE
    WHEN date([INPUT.CASE_DT]) > date('now') THEN 'CASE_DT_ERROR'
    WHEN EA_SOURCE ='CASE_CPARTY' AND [Recency_Condition(CPARTY)]='YES' AND ANY_TRAN_ESCALATED ='YES' THEN %s
    ELSE 'NONE'
    END AS TRAN_INSIGHT_CODE
    FROM dataset23",
    param2
  )
  dataset24 <- sqldf(sql)
  
  ###################################################
  #################SUPER NODE 2######################
  
  sql <- sprintf(
    "SELECT
    *,
    CASE
    WHEN TRAN_INSIGHT_CODE = 'CASE_DT_ERROR' THEN 'CASE-DATE-INVALID'
    WHEN TRAN_INSIGHT_CODE = %s THEN 'PREV ROLE: CPARTY'
    ELSE NULL
    END AS PREV_ROLE
    FROM dataset24
    WHERE TRAN_INSIGHT_CODE <> 'NONE' ",
    param2
  )
  dataset26 <- sqldf(sql)
  
  dataset27 <- sqldf(
    "SELECT *
    FROM dataset26
    GROUP BY
    [HIST.CASE_NUM],
    [HIST.DB_INSTANCE],
    [HIST.OPS_CENTER]
    HAVING MIN(ROWID)
    ORDER BY ROWID"
  )
  
  dataset29 <- sqldf(
    "SELECT
    *,
    'CASE_NUM: ' || [HIST.CASE_NUM] ||'; DB_INSTANCE: '|| [HIST.DB_INSTANCE] || '; OPS_CENTER: ' || [HIST.OPS_CENTER] ||' ' AS [RESUME.CASE_NUM],
    ROWID AS ROWNUM
    FROM dataset27
    ORDER BY date(CASE_DISP_DT)	"
  )
  
  dataset30 <- sqldf(
    "SELECT
    *,
    CASE
    WHEN ROWNUM = 1 THEN [RESUME.CASE_NUM]
    ELSE
    (SELECT [RESUME.CASE_NUM]
    FROM dataset29
    LIMIT -1
    OFFSET 1)
    || ', ' || [RESUME.CASE_NUM]
    END AS TEMP_VAR
    FROM dataset29"
  )
  
  ##################REDUNDANT BLOCK OF CODE##########
  #dataset30 <- sqldf("	UPDATE dataset30
  #						SET TEMP_VAR = CASE
  #						WHEN ROWNUM = 1
  #						THEN [RESUME.CASE_NUM]
  #						ELSE
  #							(SELECT [RESUME.CASE_NUM]
  #							FROM dataset17
  #							LIMIT -1
  #							OFFSET 1 )
  #							|| ', ' || [RESUME.CASE_NUM]
  #						END")
  ###################################################
  
  sql <- sprintf(
    "SELECT
    *,
    CASE TRAN_INSIGHT_CODE
    WHEN 'CASE_DT_ERROR' THEN 'CASE-DATE-INVALID'
    WHEN %s THEN PREV_ROLE || '; Previous Cases ' || TEMP_VAR
    ELSE NULL
    END AS TRAN_INSIGHT_MEMO
    FROM dataset30",
    param2
  )
  dataset32 <- sqldf(sql)
  
  dataset33 <- sqldf(
    "SELECT *
    FROM dataset32
    GROUP BY CASE_NUM
    HAVING MIN(ROWID)
    ORDER BY ROWID;
    
    SELECT *
    FROM dataset33
    ORDER BY TRAN_INSIGHT_MEMO DESC"
  )
  
  ##############END OF SUPER NODE 2##################
  ###################################################
  
  dataset34 <- sqldf(
    "SELECT
    SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    JURISDICTION,
    LINE_OF_BUSINESS,
    COUNTRY_CODE,
    PRIVACY_GROUP,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    CASE_STATUS,
    FOCUS_PARTY,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    EA_SOURCE,
    [HIST.CASE_NUM],
    EQUIV_DISP_CODE,
    CASE_DISP_DT,
    [HIST.DB_INSTANCE],
    [INPUT.CASE_DT],
    [HIST.OPS_CENTER],
    TRAN_INSIGHT_CODE,
    PREV_ROLE,
    [RESUME.CASE_NUM],
    ROWNUM,
    TEMP_VAR,
    TRAN_INSIGHT_MEMO
    FROM dataset33"
  )
  
  dataset35 <- sqldf(
    "SELECT *
    FROM dataset22
    UNION
    SELECT *
    FROM dataset34"
  )
  
  dataset36 <- sqldf(
    "SELECT
    DB_INSTANCE,
    EA_ID,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID
    FROM dataset5"
  )
  
  dataset37 <- sqldf (
    "SELECT
    dataset36.DB_INSTANCE,
    dataset36.OPS_CENTER,
    dataset36.EA_ID,
    dataset36.CUST_ID,
    dataset36.ACCT_NUM,
    dataset36.CASE_NUM,
    dataset36.CASE_FOCUS_ID,
    dataset36.CASE_CPARTY_ID,
    dataset36.CASE_ALERT_ID,
    dataset35.SOURCE_CODE,
    dataset35.SOURCE_KEY,
    dataset35.JURISDICTION,
    dataset35.LINE_OF_BUSINESS,
    dataset35.COUNTRY_CODE,
    dataset35.PRIVACY_GROUP,
    dataset35.EA_SOURCE_KEY,
    dataset35.CASE_STATUS,
    dataset35.FOCUS_PARTY,
    dataset35.EA_SOURCE,
    dataset35.[HIST.CASE_NUM],
    dataset35.EQUIV_DISP_CODE,
    dataset35.CASE_DISP_DT,
    dataset35.[HIST.DB_INSTANCE],
    dataset35.[INPUT.CASE_DT],
    dataset35.[HIST.OPS_CENTER],
    dataset35.TRAN_INSIGHT_CODE,
    dataset35.PREV_ROLE,
    dataset35.[RESUME.CASE_NUM],
    dataset35.ROWNUM,
    dataset35.TEMP_VAR,
    dataset35.TRAN_INSIGHT_MEMO
    FROM
    dataset36
    LEFT JOIN
    dataset35
    USING(DB_INSTANCE,OPS_CENTER)
    UNION ALL
    SELECT
    dataset36.DB_INSTANCE,
    dataset36.OPS_CENTER,
    dataset36.EA_ID,
    dataset36.CUST_ID,
    dataset36.ACCT_NUM,
    dataset36.CASE_NUM,
    dataset36.CASE_FOCUS_ID,
    dataset36.CASE_CPARTY_ID,
    dataset36.CASE_ALERT_ID,
    dataset35.SOURCE_CODE,
    dataset35.SOURCE_KEY,
    dataset35.JURISDICTION,
    dataset35.LINE_OF_BUSINESS,
    dataset35.COUNTRY_CODE,
    dataset35.PRIVACY_GROUP,
    dataset35.EA_SOURCE_KEY,
    dataset35.CASE_STATUS,
    dataset35.FOCUS_PARTY,
    dataset35.EA_SOURCE,
    dataset35.[HIST.CASE_NUM],
    dataset35.EQUIV_DISP_CODE,
    dataset35.CASE_DISP_DT,
    dataset35.[HIST.DB_INSTANCE],
    dataset35.[INPUT.CASE_DT],
    dataset35.[HIST.OPS_CENTER],
    dataset35.TRAN_INSIGHT_CODE,
    dataset35.PREV_ROLE,
    dataset35.[RESUME.CASE_NUM],
    dataset35.ROWNUM,
    dataset35.TEMP_VAR,
    dataset35.TRAN_INSIGHT_MEMO
    FROM
    dataset35
    LEFT JOIN
    dataset36
    USING(DB_INSTANCE,OPS_CENTER)"
  )
  
  sql <- sprintf(
    "SELECT
    DB_INSTANCE,
    OPS_CENTER,
    CUST_ID AS FOCUS_CUST_ID,
    ACCT_NUM AS FOCUS_ACCT_NUM,
    CASE_NUM,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    TRAN_INSIGHT_CODE,
    TRAN_INSIGHT_MEMO,
    %s AS INSIGHT_ID,
    '100' AS INSIGHT_WEIGHT,
    '' AS CPARTY_ACCT_NUM,
    '' AS CPARTY_CUST_ID,
    '' AS TRAN_GROUP_KEY,
    '' AS TRAN_ID
    FROM dataset37",
    param0
  )
  dataset39 <- sqldf(sql)
  
  ###################################################
  #################SUPER NODE 3######################
  
  sql <- sprintf(
    "SELECT
    DB_INSTANCE,
    OPS_CENTER,
    CUST_ID AS FOCUS_CUST_ID,
    ACCT_NUM AS FOCUS_ACCT_NUM,
    CASE_NUM,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    '' AS TRAN_INSIGHT_CODE,
    'INSIGHT DISABLED' AS TRAN_INSIGHT_MEMO,
    %s AS INSIGHT_ID,
    '100' AS INSIGHT_WEIGHT,
    '' AS CPARTY_ACCT_NUM,
    '' AS CPARTY_CUST_ID,
    '' AS TRAN_GROUP_KEY,
    '' AS TRAN_ID
    FROM dataset1
    WHERE
    ENABLE='NO'
    AND EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'",
    param0
  )
  dataset40 <- sqldf(sql)
  
  ##############END OF SUPER NODE 3##################
  ###################################################
  outputdataset <- data.frame(sqldf(
    "SELECT *
    FROM dataset39
    UNION
    SELECT *
    FROM dataset40"
    )
  )
  
  remove(
    dataset1,
    dataset3,
    dataset5,
    dataset6,
    dataset8,
    dataset9,
    dataset11,
    dataset12,
    dataset14,
    dataset15,
    dataset17,
    dataset18,
    dataset20,
    dataset21,
    dataset22,
    dataset23,
    dataset24,
    dataset26,
    dataset27,
    dataset29,
    dataset30,
    dataset32,
    dataset33,
    dataset34,
    dataset35,
    dataset36,
    dataset37,
    dataset39,
    dataset40
  )
  
  return (outputdataset)
}

# Apply function for each set of rules
outputdataset <- mdply(param_list, rules_function)

# Clean up data frame for final output
outputdataset <- outputdataset[4:19]

###################################################### END OF SCRIPT #####################################################################