# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list = ls())
appName <- "FCAI_supervisedML_FPTP_batch"
#start_time <- proc.time()

source("AML_supervisedML_FPTP_common.R")

sc <- sparkConnect()

readAnalyticConfig(training=TRUE, reset=TRUE)
args = commandArgs(trailingOnly=TRUE)

message("**** In training mode, default Transactions file is in the Training element ****")
applyCommandLineFileArg("Transactions", args)
AML_scored_alerts_input <- validateScoredAlerts()

source("AML_aggregate1.R")
processFeatures()

trainSupervisedML <- function(parms) {

  dtData <- processInputSources(parms)

  fpModelFileName <- getSupervisedMLModelFileName(parms,"ModelFP")
  fpValidationFileName <- getSupervisedMLValidationFileName(parms,"ValidationFP")
  tpModelFileName <- getSupervisedMLModelFileName(parms,"ModelTP")
  tpValidationFileName <- getSupervisedMLValidationFileName(parms,"ValidationTP")
  idColumns <- getColumnNames(parms$InputSource[[1]]$Type,
    parms$InputSource[[1]]$InternalProcessingIDColumns)
  tagColumnName <- getColumnName(parms$TagSource$Type, parms$TagSource$TagColumn)
  dtData <- removeRowsWithInvalidIDs(dtData,idColumns)
  # First, remove all columns which are only NA to prevent potentially all rows
  # being removed
  naCols <- which(!colSums(!is.na(dtData)))
  dtData %<>% select(-one_of(names(naCols)))
  # Remove any remaining rows which have NA values
  dtData <- na.omit(dtData)

  #Convert IDs into character so they will not be changed by preprocess
  if (!is.null(idColumns) & length(idColumns) > 0) {
    dtData %<>% mutate_at(idColumns,as.character)
  }

  #preprocess the data
  preprocessParams <- preProcess(dtData, method=c("scale"))
  #preprocessParams <- preProcess(dtData, method=c("center"))
  #preprocessParams <- preProcess(dtData, method=c("center", "scale"))
  #preprocessParams <- preProcess(dtData, method=c("range"))
  #preprocessParams <- preProcess(dtData, method=c("BoxCox"))
  #preprocessParams <- preProcess(dtData, method=c("center", "scale", "pca"))
  dtDataPost <- predict(preprocessParams, dtData)
  dtDataPost <- addCountryRisk(parms, dtDataPost)

  #read in alert history data with FP_TP tags
  TPFP.TXN <- tbl_df(loadAnalyticInput(parms$TagSource))
  if (isDebug(parms)) {
    message(createSourceHeader(parms$TagSource))
    print(head(TPFP.TXN))
  }
  if (tagColumnName != "FP_TP_Tag") {
    message(paste("Renaming tag column from",tagColumnName,"to FP_TP_Tag"))
    colnames(TPFP.TXN)[colnames(TPFP.TXN) == tagColumnName] <- "FP_TP_Tag"
    tagColumnName <- "FP_TP_Tag"
  }
  if (isDebug(parms)) {
    message("========================== Tagged data summary ===========================")
    print(TPFP.TXN %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  TPFP.TXN$alert <- 1
  byX <- getColumnNames(parms$InputSource[[1]]$Type,
    parms$TagSource$JoinColumnsX)
  byY <- getColumnNames(parms$TagSource$Type,
    parms$TagSource$JoinColumnsY)

  matchBy <- byY
  names(matchBy) <- byX
  TPFP.TXN %<>% mutate_at(byY,as.character)
  FP.TXN <- TPFP.TXN

  #getting input for FP training
  FP.TXN[FP.TXN[[tagColumnName]] %in% parms$TagSource$TagTrueValues,tagColumnName] <- "NotFP"
  FP.TXN[is.na(FP.TXN[[tagColumnName]]),tagColumnName] <- "NotFP"
  FP.TXN[FP.TXN[[tagColumnName]]!="NotFP",tagColumnName] <- "FP"

  #two options for creating training data
  #option 1: all transactions
  dtData.FPtag <- dplyr::left_join(x=dtDataPost, y=FP.TXN, by=matchBy, copy=TRUE)
  if (isDebug(parms)) {
    message("========================== FP data summary after merging tags ===========================")
    print(dtData.FPtag %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  rm(FP.TXN)
  #option 2: only those with alert history
  #dtData.FPtag <- merge(x = dtDataPost, y = FP.TXN, by = c(byCustomerIDCol,txIDCol), all.y=TRUE)
  ## may want to create another category for unknown if use optin 1
  dtData.FPtag[c(tagColumnName)][is.na(dtData.FPtag[c(tagColumnName)])] <- "NotFP"
  dtData.FPtag[c("alert")][is.na(dtData.FPtag[c("alert")])] <- 0

  #keep ID order for later use
  dtData.FPtagID <- subset(dtData.FPtag, select = idColumns)
  #dtData.FPtag <- subset(dtData.FPtag, select = !(colnames(dtData.FPtag) %in% c(byCustomerIDCol,txIDCol)))
  #use country risk instead of ISO
  dtData.FPtag <- subset(dtData.FPtag, select = !(colnames(dtData.FPtag) %in% idColumns))
  if (isDebug(parms)) {
    message("========================== FP tagged data ===========================")
    print(head(dtData.FPtag))
    message("========================== FP tagged data - alert summary ===========================")
    print(dtData.FPtag %>% group_by_(tagColumnName, "alert")
      %>% summarize(Total=n()) %>% ungroup())
  }

  ##for testing purpose, just use Score as target
  ##create 80-20/training-validation split

  #score_training_FP <- createDataPartition(dtData.FPtag$FP_TP_Tag, p =0.8, list=FALSE)
  #validation_FP <- dtData.FPtag[-score_training_FP,]
  #newtest_FP <- dtData.FPtag[score_training_FP,]

  ##set training parm
  u_control<- trainControl(method='cv', number = 5)
  #u_metric <- "Accuracy"

  ## Random Forest
  set.seed(7)
  ## check if model exists? If not, refit:
  if (file.exists(paste(AMLAnalyticConfig$ModelDirectory,"/",basename(fpModelFileName),sep=""))) {
  ##    ## load model
    message("Updating existing model: fit_FP.rf")
    readInput(fpModelFileName, type="rda")
    ##use training data only
    #fit_FP.rf <- update(fit_FP.rf, data = newtest_FP)
    ##use all data

    fit_FP.rf <- update(fit_FP.rf, data = dtData.FPtag )

  } else {
  ##    ## determine if use all data for training or need to split for training and validation
    message("Training new model: fit_FP.rf")
    if (!is.null(parms$FP_Training_only) & parms$FP_Training_only) {
        message("Training Only")
     #find names and str to create one instance for any new char level
     #default.instance <- sapply(dtData.FPtag, class)
     #index <- which(default.instance=="numeric")
     #default.instance[default.instance=="numeric"] <- 1
     #default.instance[index] <- lapply(default.instance[index], function(x) as.numeric(as.character(x)))
     #default.instance[default.instance=="character"] <- "XXX"
     #dtData.FPtag <- rbind(dtData.FPtag,default.instance)

      fit_FP.rf <- train(FP_TP_Tag~., data=dtData.FPtag, method="rf", trControl=u_control, importance=TRUE)

    } else {
      message("Training and Validation")
      ##for testing purpose, just use Score as target
      ##create 80-20/training-validation split
      #score_training_FP <- createDataPartition(dtData.FPtag$FP_TP_Tag, p =0.8, list=FALSE)
      score_training_FP <- createDataPartition(dtData.FPtag$FP_TP_Tag, p =0.8, list=FALSE)
      validation_FP <- dtData.FPtag[-score_training_FP,]
      newtest_FP <- dtData.FPtag[score_training_FP,]
      validation_FP_ID <- dtData.FPtagID[-score_training_FP,]
      newtest_FP_ID <- dtData.FPtagID[score_training_FP,]
      #find names and str to create one instance for any new char level
      #default.instance <- sapply(newtest_FP, class)
      #index <- which(default.instance=="numeric")
      #default.instance[default.instance=="numeric"] <- 1
      #default.instance[index] <- lapply(default.instance[index], function(x) as.numeric(as.character(x)))
      #default.instance[default.instance=="character"] <- "XXX"
      #newtest_FP <- rbind(newtest_FP,default.instance)

      fit_FP.rf <- train(FP_TP_Tag~., data=newtest_FP, method="rf", trControl=u_control, importance=TRUE)

      #exclude unseen CounterISO3
      #tmp_FP <- distinct(newtest_FP, CounterISO3)
      #validation_FP <- subset(validation_FP, CounterISO3 %in% tmp_FP$CounterISO3)

      ## predict FP on the validation dataset
      predictions_FP <- predict(fit_FP.rf, validation_FP)
      confusionMatrix(predictions_FP, validation_FP$FP_TP_Tag)
      u_validation_FP<- cbind(validation_FP_ID,validation_FP,predictions_FP)

      if (isDebug(parms)) {
        message("========================== FP Validation ===========================")
        message(paste0("Predicted ",
          format(100*sum((u_validation_FP$FP_TP_Tag == u_validation_FP$predictions_FP),na.rm=TRUE)/nrow(u_validation_FP),digits=3,nsmall=2),
          "% of False Positives\n"))
      }
      storeOutput(copy_to(sc, tbl_df(u_validation_FP)),name=fpValidationFileName,
        path=AMLAnalyticConfig$DataDirectory, type="csv")

      #plot(u_validation$FP_TP_Tag, u_validation$predictions, xlab="expected", ylab="predicted")
    }
    #fit_FP.rf <- train(FP_TP_Tag~., data=newtest_FP, method="rf", trControl=u_control, importance=TRUE)
    #message("Training new model: fit_FP.rf")
    #fit_FP.rf <- train(FP_TP_Tag~., data=dtData.FPtag, method="rf", trControl=u_control, importance=TRUE)
  }

  if (isDebug(parms)) {
    message("========================== fit_FP.rf ===========================")
    print(fit_FP.rf)
    message("=============== fit_FP.rf - Variable Importance ================")
    print(varImp(fit_FP.rf,scale=FALSE))
  }

  assign("fit_FP.rf", fit_FP.rf, envir = .GlobalEnv)
  storeOutput("fit_FP.rf", name=fpModelFileName, type="rda")
  TOPFP.VAR <- varImp(fit_FP.rf, scale=FALSE)

  #getting input for TP training
  TP.TXN <- TPFP.TXN
  TP.TXN[!TP.TXN[[tagColumnName]] %in% parms$TagSource$TagTrueValues,tagColumnName] <- "NotTP"
  TP.TXN[is.na(TP.TXN[[tagColumnName]]),tagColumnName] <- "NotTP"
  TP.TXN[TP.TXN[[tagColumnName]]!="NotTP",tagColumnName] <- "TP"

  #two options for creating training data
  #option 1: all transactions
  dtData.TPtag <- left_join(x=dtDataPost, y=TP.TXN, by=matchBy)
  if (isDebug(parms)) {
    message("========================== TP data summary after merging tags ===========================")
    print(dtData.TPtag %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  rm(TP.TXN)
  #option 2: only those with alert history
  #dtData.TPtag <- merge(x = dtDataPost, y = TP.TXN, by = c(byCustomerIDCol,txIDCol), all.y=TRUE)
  ## may want to create another category for unknown if use optin 1
  dtData.TPtag[c(tagColumnName)][is.na(dtData.TPtag[c(tagColumnName)])] <- "NotTP"
  dtData.TPtag[c("alert")][is.na(dtData.TPtag[c("alert")])] <- 0

  #keep ID order for later use
  dtData.TPtagID <- subset(dtData.TPtag, select = idColumns)
  #dtData.TPtag <- subset(dtData.TPtag, select = !(colnames(dtData.TPtag) %in% c(byCustomerIDCol,txIDCol)))
  #use country risk instead of ISO
  dtData.TPtag <- subset(dtData.TPtag, select = !(colnames(dtData.TPtag) %in% idColumns))

  if (isDebug(parms)) {
    message("========================== TP tagged data ===========================")
    print(head(dtData.TPtag))
    message("========================== TP tagged data - alert summary ===========================")
    print(dtData.TPtag %>% group_by_(tagColumnName, "alert")
      %>% summarize(Total=n()) %>% ungroup())
  }

  ##for testing purpose, just use Score as target

  ##set training parm
  u_control<- trainControl(method='cv', number = 5)
  #u_metric <- "Accuracy"

  ## Random Forest
  set.seed(7)
  ## check if model exists? If not, refit:
  if (file.exists(paste(AMLAnalyticConfig$ModelDirectory,"/",basename(tpModelFileName),sep=""))) {
  ##    ## load model
    message("Updating existing model: fit_TP.rf")
    readInput(tpModelFileName, type="rda")

    fit_TP.rf <- update(fit_TP.rf, data = dtData.TPtag )

  } else {
  ##    ## determine if use all data for training or need to split for training and validation
    message("Training new model: fit_TP.rf")
    if (!is.null(parms$TP_Training_only) & parms$TP_Training_only) {
        message("Training Only")
     #find names and str to create one instance for any new char level
     #default.instance <- sapply(dtData.TPtag, class)
     #index <- which(default.instance=="numeric")
     #default.instance[default.instance=="numeric"] <- 1
     #default.instance[index] <- lapply(default.instance[index], function(x) as.numeric(as.character(x)))
     #default.instance[default.instance=="character"] <- "XXX"
     #dtData.TPtag <- rbind(dtData.TPtag,default.instance)

      fit_TP.rf <- train(FP_TP_Tag~., data=dtData.TPtag, method="rf", trControl=u_control, importance=TRUE)

    } else {
      message("Training and Validation")
      ##for testing purpose, just use Score as target
      ##create 80-20/training-validation split
      #score_training_TP <- createDataPartition(dtData.TPtag$FP_TP_Tag, p =0.8, list=FALSE)
      score_training_TP <- createDataPartition(dtData.TPtag$FP_TP_Tag, p =0.8, list=FALSE)
      validation_TP <- dtData.TPtag[-score_training_TP,]
      newtest_TP <- dtData.TPtag[score_training_TP,]
      validation_TP_ID <- dtData.TPtagID[-score_training_TP,]
      newtest_TP_ID <- dtData.TPtagID[score_training_TP,]
      #find names and str to create one instance for any new char level
      #default.instance <- sapply(newtest_TP, class)
      #index <- which(default.instance=="numeric")
      #default.instance[default.instance=="numeric"] <- 1
      #default.instance[index] <- lapply(default.instance[index], function(x) as.numeric(as.character(x)))
      #default.instance[default.instance=="character"] <- "XXX"
      #newtest_TP <- rbind(newtest_TP,default.instance)

      fit_TP.rf <- train(FP_TP_Tag~., data=newtest_TP, method="rf", trControl=u_control, importance=TRUE)

      #exclude unseen CounterISO3
      #tmp_TP <- distinct(newtest_TP, CounterISO3)
      #validation_TP <- subset(validation_TP, CounterISO3 %in% tmp_FP$CounterISO3)

      ## predict FP on the validation dataset
      predictions_TP <- predict(fit_TP.rf, validation_TP)
      confusionMatrix(predictions_TP, validation_TP$FP_TP_Tag)
      u_validation_TP<- cbind(validation_TP_ID,validation_TP,predictions_TP)

      if (isDebug(parms)) {
        message("========================== TP Validation ===========================")
        message(paste0("Predicted ",
        format(100*sum((u_validation_TP$FP_TP_Tag == u_validation_TP$predictions_TP),na.rm=TRUE)/nrow(u_validation_TP),digits=3,nsmall=2),
          "% of True Positives\n"))
      }
      storeOutput(copy_to(sc, tbl_df(u_validation_TP)),name=tpValidationFileName,
        path=AMLAnalyticConfig$DataDirectory, type="csv")

      #plot(u_validation$FP_TP_Tag, u_validation$predictions, xlab="expected", ylab="predicted")
    }
    #fit_FP.rf <- train(FP_TP_Tag~., data=newtest_FP, method="rf", trControl=u_control, importance=TRUE)
    #message("Training new model: fit_FP.rf")
    #fit_FP.rf <- train(FP_TP_Tag~., data=dtData.FPtag, method="rf", trControl=u_control, importance=TRUE)
  }

  if (isDebug(parms)) {
    message("========================== fit_TP.rf ===========================")
    print(fit_TP.rf)
    message("=============== fit_TP.rf - Variable Importance ================")
    print(varImp(fit_TP.rf,scale=FALSE))
  }
  assign("fit_TP.rf", fit_TP.rf, envir = .GlobalEnv)
  storeOutput("fit_TP.rf", name=tpModelFileName, type="rda")

  TOPTP.VAR <- varImp(fit_TP.rf, scale=FALSE)

}

allAnalytics <- AMLAnalyticConfig$Analytics
for (i in 1:length(allAnalytics)) {
  if (allAnalytics[[i]]$Type == "SupervisedML") {
    message(paste0("******* Found SupervisedML (index ",i,") - ",allAnalytics[[i]]$Results$ReasonType))
    trainSupervisedML(parms=allAnalytics[[i]])
  }
}
