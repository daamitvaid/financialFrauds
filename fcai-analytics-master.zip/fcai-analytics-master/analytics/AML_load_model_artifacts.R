# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list=ls())
source("AML_utils.R")

readAnalyticConfig(reset=TRUE)
args = commandArgs(trailingOnly=TRUE)

if (length(args) == 0) {
  fileName = NA
} else {
  fileName = args[1]
}
loadModelArtifacts(fileName)
