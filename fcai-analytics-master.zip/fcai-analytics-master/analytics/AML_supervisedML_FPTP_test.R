# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list=ls())
appName <- "FCAI_supervisedML_FPTP_test"
source("AML_utils.R")

source("AML_supervisedML_FPTP_batch.R")

# Turn off training mode that was set in the batch processing
readAnalyticConfig(reset=TRUE)

allAnalytics <- AMLAnalyticConfig$Analytics
for (i in 1:length(allAnalytics)) {
  if (allAnalytics[[i]]$Type == "SupervisedML") {
    message(paste0("******* Found SupervisedML (index ",i,") - ",allAnalytics[[i]]$Results$ReasonType))
    parms <- unlist(allAnalytics[[i]])

    source(parms["Source"])

    # execute score banding function
    func <- match.fun(parms["BandingFunction"])
    bands <- func(parms=allAnalytics[[i]])
    print(head(bands), width=Inf)

    # execute assessment function
    func = match.fun(parms["AssessmentFunction"])
    message("\n\n***** Running assessment for full dataset *****\n")
    if (allAnalytics[[i]]$InputSource[[1]]$SourceType=="File") {
      dfData <- loadData(allAnalytics[[i]]$InputSource[[1]]$Type)
      dfDataIDCol <- getColumnName(allAnalytics[[i]]$InputSource[[1]]$Type,"IDColumn")
    } else if (allAnalytics[[i]]$InputSource[[1]]$SourceType=="Aggregate") {
      dfData <- loadData(allAnalytics[[i]]$InputSource[[1]]$Type,
        allAnalytics[[i]]$InputSource[[1]]$AggregateName)
      dfDataIDCol <- colnames(dfData)[[1]]
    }

    dfData <- dfData %>% arrange_(dfDataIDCol)
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(scores, width=Inf)

    message("\n\n***** Running assessment for first 100 elements dataset *****\n")
    ids <- sdf_read_column(dfData, dfDataIDCol)
    ids <- ids[1:100]
    filterCriteria = paste0(dfDataIDCol," %in% ids")
    dfData <- dfData %>% filter_(.dots = filterCriteria)
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(scores, width=Inf)

    message("\n\n***** Running assessment for first element only *****\n")
    ids <- ids[1]
    filterCriteria = paste0(dfDataIDCol," %in% ids")
    dfData <- dfData %>% filter_(.dots = filterCriteria)
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(scores, width=Inf)
  }
}
