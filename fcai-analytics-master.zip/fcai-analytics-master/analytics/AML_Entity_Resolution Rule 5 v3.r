

#################################### SPSS G2 ENTITY RESOLUTION STREAM TRANSLATION ########################################################
##                                                                                                                                      ##
## The script below translates super node 5 of G2 SPSS stream CASE_FOCUS_SIT.v12 into R scripts ##########################################
## This rule has a logic different to the other supernodes and thus has been coded separately ############################################
## The script takes in the CASE_FOCUS_RESUME.V12.csv as an input file and generates and outputdataset similar to the G2 SPSS stream ######
## The function is implemented using R library sqldf using SQLite scripts. If required a DB2 SQL script can replace the R script below ###
##                                                                                                                                      ##
##                                                                                                                                      ##
##                                                                                                                                      ##
## DEVELOPED BY : ANISH DIXIT                                                                                        DATE : 02-OCT-2017 ##
##########################################################################################################################################





######################################################## SCRIPT INPUTS ###################################################################

######################################################
## CHANGE THIS TO CORRECT INPUT FILE                ##
######################################################
#filename <- "C:/Users/IBM_ADMIN/Downloads/CASE_FOCUS_RESUME.V1.2.csv"


##################################################### START OF SCRIPT ####################################################################

## Import the required R packages
#library(readr)
library(plyr)
library(sqldf)

## Read the input file
#inputdataset <- read_csv(filename)

## Transformation scripts
  dataset0 <- sqldf(
    "SELECT
    SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    EA_ID,
    EA_DEGREE,
    EA_SOURCE,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    Date(substr(SUBSTR(CASE_DT,1,10), 7, 4) || '-' || substr(SUBSTR(CASE_DT,1,10), 4, 2) || '-' || substr(SUBSTR(CASE_DT,1,10), 1, 2)) AS CASE_DT,
    CASE_STATUS,
	CUST_BUS_RISK,
	CUST_EFF_RISK,
	CUST_GEO_RISK,
	DATE(CASE
		WHEN substr(LAST_RISK_DT, -5, 1) = '/'	and LAST_RISK_DT LIKE '%/%/%'
		THEN
		substr(LAST_RISK_DT, -4) 
		|| '-' ||
		substr('0' || substr(LAST_RISK_DT, 1, instr(LAST_RISK_DT, '/')-1), -2) 
		|| '-' ||
		substr('0' || substr(LAST_RISK_DT, instr(LAST_RISK_DT, '/')+1, length(LAST_RISK_DT)-5-instr(LAST_RISK_DT, '/')), -2)
		ELSE
		NULL
		END) AS LAST_RISK_DT,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
	CAST(FOCUS_ELEVATED_RISK_RESOLVED_FOCUS_RECENCY AS INTEGER) AS RESOLVED_FOCUS_RECENCY,
	CAST(FOCUS_ELEVATED_RISK_DURATION AS INTEGER) AS DURATION,
	FOCUS_ELEVATED_RISK_ENABLE AS ENABLE
	FROM inputdataset"
  )
  
  dataset1 <- sqldf(
  "SELECT *
  FROM dataset0
  WHERE ENABLE ='YES'")
  
  dataset2 <- sqldf(
    "SELECT *
    FROM dataset1
    WHERE
    EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'"
  )
  
  dataset3 <- sqldf(
    "SELECT *
    FROM dataset1
    WHERE
    EA_DEGREE = 0
	AND (CASE_STATUS IS NOT 'I' OR EA_SOURCE = 'RISK_HIST')"
  )
  
  dataset4 <- sqldf(
	"SELECT
	EA_ID,
	dataset2.DB_INSTANCE,
	dataset2.CASE_NUM AS CASE_NUM_CURRENT,
	dataset2.CASE_DT AS CASE_DT_CURRENT,
	dataset2.CASE_STATUS AS CASE_STATUS_CURRENT,
	dataset2.CUST_BUS_RISK AS CUST_BUS_RISK_CURRENT,
	dataset2.CUST_EFF_RISK AS CUST_EFF_RISK_CURRENT,
	dataset2.CUST_GEO_RISK AS CUST_GEO_RISK_CURRENT,
	dataset2.OPS_CENTER,
	dataset2.CASE_ALERT_ID,
	dataset3.SOURCE_KEY,
	dataset3.EA_DEGREE,
	dataset3.EA_SOURCE,
	dataset3.EA_SOURCE_KEY,
	dataset3.CUST_ID,
	dataset3.ACCT_NUM,
	dataset3.CASE_NUM AS CASE_NUM_HISTORY,
	dataset3.CASE_DT AS CASE_DT_HISTORY,
	dataset3.CASE_STATUS AS CASE_STATUS_HISTORY,
	dataset3.CUST_BUS_RISK AS CUST_BUS_RISK_HISTORY,
	dataset3.CUST_EFF_RISK AS CUST_EFF_RISK_HISTORY,
	dataset3.CUST_GEO_RISK AS CUST_GEO_RISK_HISTORY,
	dataset3.LAST_RISK_DT,
	dataset3.RESOLVED_FOCUS_RECENCY,
	dataset3.DURATION
	FROM 
	dataset2
	INNER JOIN
	dataset3
	USING (EA_ID)"
  )
  
  dataset5 <- sqldf(
  "SELECT *,
	CASE 
	WHEN (julianday(LAST_RISK_DT) - julianday(CASE_DT_CURRENT)) IS NULL
	THEN -1
	ELSE (julianday(LAST_RISK_DT) - julianday(CASE_DT_CURRENT))
	END AS RECENCY
  FROM dataset4"
  )

  dataset6 <- sqldf(
  "SELECT *,
	CASE
		WHEN (RECENCY >= 0 AND DURATION = 999) THEN 'YES' 
		WHEN (RECENCY >= 0 AND RECENCY <= DURATION) THEN 'YES' 
		ELSE 'NO' 
	END AS RECENCY_ELIGIBILITY
  FROM dataset5"
  )
  
  dataset7 <- sqldf(
  "SELECT *
  FROM dataset6
  WHERE RECENCY_ELIGIBILITY = 'YES' 
  AND EA_SOURCE = 'RISK_HIST'"
  )
  
  dataset8 <- sqldf(
  "SELECT *
  FROM 
	dataset7
	INNER JOIN
	(SELECT EA_ID,MAX(LAST_RISK_DT) AS LAST_RISK_DT
	FROM dataset7
	GROUP BY EA_ID)
	USING (EA_ID,LAST_RISK_DT)"
  )
  
  dataset9 <- sqldf(
  "SELECT *
  FROM dataset8
  ORDER BY CASE_NUM_CURRENT, CUST_EFF_RISK_HISTORY"
  )
  dataset9 <- sqldf(
  "SELECT *
  FROM dataset8
  GROUP BY CASE_NUM_CURRENT
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )
  
  dataset10 <- sqldf(
  "SELECT *,
  CASE
  WHEN CUST_EFF_RISK_CURRENT > CUST_EFF_RISK_HISTORY THEN 'YES'
  ELSE 'NO'
  END AS INSIGHT_CODE_ELIGIBILITY_NO_CASE_PRESENT,
  CASE
  WHEN CUST_BUS_RISK_CURRENT > CUST_BUS_RISK_HISTORY THEN 'YES'
  ELSE 'NO'
  END AS BUSINESS_RISK_INCREASED,
  CASE
  WHEN CUST_GEO_RISK_CURRENT > CUST_GEO_RISK_HISTORY THEN 'YES'
  ELSE 'NO'
  END AS GEO_RISK_INCREASED
  FROM dataset9"
  )
  
  dataset11 <- sqldf(
  "SELECT *,
  'No Previous Case; Previous Effective Risk (Min. of last Effective risks in Duration Period): ' || 
  CUST_EFF_RISK_HISTORY || 
  ';  Reason for Change: ' || 
  CASE 
	WHEN (BUSINESS_RISK_INCREASED = 'YES' AND GEO_RISK_INCREASED = 'YES') 
	THEN (
		'Increase in Business Risk & GEO Risk; ' || 
		'Last BUSINESS risk: ' || 
		CAST(CUST_BUS_RISK_HISTORY AS INTEGER) || 
		'; ' || 
		'Last GEO risk: ' || 
		CAST(CUST_GEO_RISK_HISTORY AS INTEGER)) 
	WHEN (BUSINESS_RISK_INCREASED = 'YES' AND GEO_RISK_INCREASED = 'NO') 
	THEN (
		'Increase in Business Risk; ' || 
		'Last BUSINESS risk: ' || 
		CAST(CUST_BUS_RISK_HISTORY AS INTEGER)) 
	WHEN (BUSINESS_RISK_INCREASED = 'NO' AND GEO_RISK_INCREASED = 'YES') 
	THEN (
		'Increase in GEO Risk; ' || 
		'Last GEO risk: ' || 
		CAST(CUST_GEO_RISK_HISTORY AS INTEGER)) 
	ELSE '' 
  END || 
  ';  Last Risk Change Date: ' || 
  LAST_RISK_DT AS INSIGHT_MEMO_NO_CASE_PRESENT
  FROM dataset10"
  )
  
  dataset12 <- sqldf(
  "SELECT *,
  	CASE 
	WHEN (julianday(CASE_DT_HISTORY) - julianday(CASE_DT_CURRENT)) IS NULL
	THEN -1
	ELSE (julianday(CASE_DT_HISTORY) - julianday(CASE_DT_CURRENT))
	END AS RECENCY
  FROM dataset4
  WHERE EA_SOURCE = 'CASE_FOCUS'"
  )
  
  dataset13 <- sqldf(
  "SELECT *,
	CASE
	WHEN (RECENCY >= 0 AND RESOLVED_FOCUS_RECENCY = 999) 
	THEN 'YES'
	WHEN (RECENCY >= 0 AND RECENCY <= RESOLVED_FOCUS_RECENCY) 
	THEN 'YES'
	ELSE 'NO'
  END AS RECENCY_ELIGIBILITY
  FROM dataset12"
  )
  
  dataset14 <- sqldf(
  "SELECT *
  FROM dataset13
  WHERE RECENCY_ELIGIBILITY = 'YES'
  ORDER BY CASE_NUM_CURRENT ASC, CASE_DT_HISTORY DESC, CUST_EFF_RISK_HISTORY ASC"
  )
  dataset14 <- sqldf(
  "SELECT *
  FROM dataset14
  GROUP BY CASE_NUM_CURRENT
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )
  
  dataset15 <- sqldf(
  "SELECT *,
  CASE
  WHEN CUST_EFF_RISK_CURRENT > CUST_EFF_RISK_HISTORY THEN 'YES' 
  ELSE 'NO'
  END AS INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT,
  CASE
  WHEN CUST_BUS_RISK_CURRENT > CUST_BUS_RISK_HISTORY THEN 'YES' 
  ELSE 'NO'
  END AS BUSINESS_RISK_INCREASED,
  CASE
  WHEN CUST_GEO_RISK_CURRENT > CUST_GEO_RISK_HISTORY THEN 'YES'
  ELSE 'NO'
  END AS GEO_RISK_INCREASED
  FROM dataset14"
  )
  
  dataset16 <- sqldf(
  "SELECT *,
  'Last CASE NUM: ' || 
  CASE_NUM_HISTORY || 
  ';  ' || 
  ' Last CASE DATE: ' || 
  CASE_DT_HISTORY || 
  '; Previous Case Effective Risk: ' || 
  CUST_EFF_RISK_HISTORY || 
  ';  Reason for Change: ' || 
  CASE 
	WHEN (BUSINESS_RISK_INCREASED = 'YES' AND GEO_RISK_INCREASED = 'YES') 
	THEN (
		'Increase in Business Risk & GEO Risk; ' || 
		'Last BUSINESS risk: ' || 
		CAST(CUST_BUS_RISK_HISTORY AS INTEGER) || 
		'; ' || 
		'Last GEO risk: ' || 
		CAST(CUST_GEO_RISK_HISTORY AS INTEGER)) 
	WHEN (BUSINESS_RISK_INCREASED = 'YES' AND GEO_RISK_INCREASED = 'NO') 
	THEN (
		'Increase in Business Risk; ' || 
		'Last BUSINESS risk: ' || 
		CAST(CUST_BUS_RISK_HISTORY AS INTEGER)) 
	WHEN (BUSINESS_RISK_INCREASED = 'NO' AND GEO_RISK_INCREASED = 'YES') 
	THEN (
		'Increase in GEO Risk; ' || 
		'Last GEO risk: ' || 
		CAST(CUST_GEO_RISK_HISTORY AS INTEGER)) 
	WHEN (BUSINESS_RISK_INCREASED = 'NO' AND INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT IS NOT 'NO' AND GEO_RISK_INCREASED = 'NO') 
	THEN 'Increase in Customer Effective Risk; Geo Risk and Business Risk have not changed' 
	ELSE '' 
  END AS INSIGHT_MEMO_CASE_PRESENT
  FROM dataset15"
  )
  
  dataset17 <- sqldf(
  "SELECT
	CASE_NUM_CURRENT AS CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	dataset11.INSIGHT_CODE_ELIGIBILITY_NO_CASE_PRESENT,
	dataset11.INSIGHT_MEMO_NO_CASE_PRESENT,
	dataset16.CUST_ID,
	dataset16.ACCT_NUM,
	dataset16.INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT,
	dataset16.INSIGHT_MEMO_CASE_PRESENT
  FROM
	dataset11
	LEFT JOIN
	dataset16
	USING (CASE_NUM_CURRENT,DB_INSTANCE,OPS_CENTER)
	
	UNION
	
	SELECT
	CASE_NUM_CURRENT AS CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	dataset11.INSIGHT_CODE_ELIGIBILITY_NO_CASE_PRESENT,
	dataset11.INSIGHT_MEMO_NO_CASE_PRESENT,
	dataset16.CUST_ID,
	dataset16.ACCT_NUM,
	dataset16.INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT,
	dataset16.INSIGHT_MEMO_CASE_PRESENT
  FROM
	dataset16
	LEFT JOIN
	dataset11
	USING (CASE_NUM_CURRENT,DB_INSTANCE,OPS_CENTER)"
  )
  
  dataset18 <- sqldf(
  "SELECT 
		CASE_NUM,
		DB_INSTANCE,
		OPS_CENTER,
		CASE
			WHEN (INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT = 'YES' OR INSIGHT_CODE_ELIGIBILITY_NO_CASE_PRESENT = 'YES') 
			THEN 'FOCUS-ELEVATED-RISK' 
			ELSE 'NONE' 
		END AS TRAN_INSIGHT_CODE,
		CASE
			WHEN INSIGHT_CODE_ELIGIBILITY_CASE_PRESENT =  'YES' 
			THEN INSIGHT_MEMO_CASE_PRESENT 
			WHEN INSIGHT_CODE_ELIGIBILITY_NO_CASE_PRESENT = 'YES' 
			THEN INSIGHT_MEMO_NO_CASE_PRESENT 
			ELSE NULL 
		END AS TRAN_INSIGHT_MEMO
  FROM dataset17"
  )
  
  dataset19 <- sqldf(
  "SELECT dataset2.*,dataset18.TRAN_INSIGHT_CODE,dataset18.TRAN_INSIGHT_MEMO
  FROM 
	dataset18
	LEFT JOIN
	dataset2
	USING (CASE_NUM,DB_INSTANCE,OPS_CENTER)
	
	UNION
	
	SELECT dataset2.*,dataset18.TRAN_INSIGHT_CODE,dataset18.TRAN_INSIGHT_MEMO
  FROM 
	dataset2
	LEFT JOIN
	dataset18
	USING (CASE_NUM,DB_INSTANCE,OPS_CENTER)"
  )
  
  dataset20 <- sqldf(
  "SELECT 
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	CUST_ID AS FOCUS_CUST_ID,
	ACCT_NUM AS FOCUS_ACCT_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	'5' AS INSIGHT_ID,
	'100' AS INSIGHT_WEIGHT,
	'' AS CPARTY_ACCT_NUM,
	'' AS CPARTY_CUST_ID,
	'' AS TRAN_GROUP_KEY,
	'' AS TRAN_ID
  FROM dataset19"
  )
  
  dataset21 <- sqldf(
  "SELECT
	DB_INSTANCE,
	OPS_CENTER,
    CUST_ID AS FOCUS_CUST_ID,
    ACCT_NUM AS FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	'5' AS INSIGHT_ID,
	'100' AS INSIGHT_WEIGHT,
	'' AS CPARTY_ACCT_NUM,
	'' AS CPARTY_CUST_ID,
	'' AS TRAN_GROUP_KEY,
	'' AS TRAN_ID,
	'INSIGHT DISABLED'AS TRAN_INSIGHT_MEMO,
	'' AS TRAN_INSIGHT_CODE
  FROM dataset0
  WHERE ENABLE = 'NO'
  AND (EA_SOURCE = SOURCE_CODE AND EA_SOURCE_KEY = SOURCE_KEY AND CASE_STATUS = 'I')"
  )
  
  output5 <- sqldf(
  "SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset20
  UNION
  SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset21"
  )
  ###################################################

  ###################################################
  

  remove(
    dataset0,
	dataset1,
    dataset2,
	dataset3,
	dataset4,
    dataset5,
    dataset6,
	dataset7,
    dataset8,
    dataset9,
	dataset10,
    dataset11,
    dataset12,
	dataset13,
	dataset14,
	dataset15,
	dataset16,
	dataset17,
	dataset18,
	dataset19,
	dataset20,
	dataset21
  )
  
###################################################### END OF SCRIPT #####################################################################