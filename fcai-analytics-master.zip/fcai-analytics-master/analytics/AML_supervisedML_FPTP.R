# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

source("AML_supervisedML_FPTP_common.R")

executeModels <- function(parms, dtData=NULL, storeUpdates=FALSE) {
  dtData <- processInputSources(parms, dtData)

  fpModelFileName <- getSupervisedMLModelFileName(parms,"ModelFP")
  tpModelFileName <- getSupervisedMLModelFileName(parms,"ModelTP")
  idColumns <- getColumnNames(parms$InputSource[[1]]$Type,
    parms$InputSource[[1]]$InternalProcessingIDColumns)
  tagColumnName <- getColumnName(parms$TagSource$Type, parms$TagSource$TagColumn)
  dtData <- removeRowsWithInvalidIDs(dtData,idColumns)
  # First, remove all columns which are only NA to prevent potentially all rows
  # being removed
  naCols <- which(!colSums(!is.na(dtData)))
  dtData %<>% select(-one_of(names(naCols)))
  # Remove any remaining rows which have NA values
  dtData <- na.omit(dtData)
  if (as.integer(collect(count(dtData))) == 0) {
    stop("No valid rows to executeModel")
  }

  #Convert IDs into character so they will not be changed by preprocess
  if (!is.null(idColumns) & length(idColumns) > 0) {
    dtData %<>% mutate_at(idColumns,as.character)
  }

  #preprocess the data
  preprocessParams <- preProcess(dtData, method=c("scale"))
  #preprocessParams <- preProcess(dtData, method=c("center"))
  #preprocessParams <- preProcess(dtData, method=c("center", "scale"))
  #preprocessParams <- preProcess(dtData, method=c("range"))
  #preprocessParams <- preProcess(dtData, method=c("BoxCox"))
  #preprocessParams <- preProcess(dtData, method=c("center", "scale", "pca"))
  dtDataPost <- predict(preprocessParams, dtData)
  dtDataPost <- addCountryRisk(parms, dtDataPost)

  #read in alert history data with FP_TP tags
  TPFP.TXN <- tbl_df(loadAnalyticInput(parms$TagSource))
  if (tagColumnName != "FP_TP_Tag") {
    message(paste("Renaming tag column from",tagColumnName,"to FP_TP_Tag"))
    colnames(TPFP.TXN)[colnames(TPFP.TXN) == tagColumnName] <- "FP_TP_Tag"
    tagColumnName <- "FP_TP_Tag"
  }
  if (isDebug(parms)) {
    message("========================== Tagged data summary ===========================")
    print(TPFP.TXN %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  TPFP.TXN$alert <- 1
  byX <- getColumnNames(parms$InputSource[[1]]$Type,
    parms$TagSource$JoinColumnsX)
  byY <- getColumnNames(parms$TagSource$Type,
    parms$TagSource$JoinColumnsY)

  matchBy <- byY
  names(matchBy) <- byX
  TPFP.TXN %<>% mutate_at(byY,as.character)
  FP.TXN <- TPFP.TXN

  #getting input for FP training
  FP.TXN[FP.TXN[[tagColumnName]] %in% parms$TagSource$TagTrueValues,tagColumnName] <- "NotFP"
  FP.TXN[is.na(FP.TXN[[tagColumnName]]),tagColumnName] <- "NotFP"
  FP.TXN[FP.TXN[[tagColumnName]]!="NotFP",tagColumnName] <- "FP"

  #two options for creating training data
  #option 1: all transactions
  dtData.FPtag <- dplyr::left_join(x=dtDataPost, y=FP.TXN, by=matchBy, copy=TRUE)
  if (isDebug(parms)) {
    message("========================== FP data summary after merging tags ===========================")
    print(dtData.FPtag %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  rm(FP.TXN)
  #option 2: only those with alert history
  #dtData.FPtag <- merge(x = dtDataPost, y = FP.TXN, by = c(byCustomerIDCol,txIDCol), all.y=TRUE)
  ## may want to create another category for unknown if use optin 1
  dtData.FPtag[c(tagColumnName)][is.na(dtData.FPtag[c(tagColumnName)])] <- "NotFP"
  dtData.FPtag[c("alert")][is.na(dtData.FPtag[c("alert")])] <- 0

  #keep ID order for later use
  dtData.FPtagID <- subset(dtData.FPtag, select = idColumns)
  #dtData.FPtag <- subset(dtData.FPtag, select = !(colnames(dtData.FPtag) %in% c(byCustomerIDCol,txIDCol)))
  #use country risk instead of ISO
  dtData.FPtag <- subset(dtData.FPtag, select = !(colnames(dtData.FPtag) %in% idColumns))
  if (isDebug(parms)) {
    message("========================== FP tagged data ===========================")
    print(head(dtData.FPtag))
    message("========================== FP tagged data - alert summary ===========================")
    print(dtData.FPtag %>% group_by_(tagColumnName, "alert")
      %>% summarize(Total=n()) %>% ungroup())
  }

  ## Random Forest
  set.seed(7)
  readInput(fpModelFileName, type="rda")
  fit_FP.rf <- update(fit_FP.rf, data = dtData.FPtag )
  if (isDebug(parms)) {
    message("========================== fit_FP.rf ===========================")
    print(fit_FP.rf)
  }
  if (storeUpdates) {
    assign("fit_FP.rf", fit_FP.rf, envir = .GlobalEnv)
    storeOutput("fit_FP.rf", name=fpModelFileName, type="rda")
  }

  TOPFP.VAR <- varImp(fit_FP.rf, scale=FALSE)

  #getting input for TP training
  TP.TXN <- TPFP.TXN
  TP.TXN[!TP.TXN[[tagColumnName]] %in% parms$TagSource$TagTrueValues,tagColumnName] <- "NotTP"
  TP.TXN[is.na(TP.TXN[[tagColumnName]]),tagColumnName] <- "NotTP"
  TP.TXN[TP.TXN[[tagColumnName]]!="NotTP",tagColumnName] <- "TP"

  #two options for creating training data
  #option 1: all transactions
  dtData.TPtag <- left_join(x=dtDataPost, y=TP.TXN, by=matchBy)
  if (isDebug(parms)) {
    message("========================== TP data summary after merging tags ===========================")
    print(dtData.TPtag %>% group_by_(tagColumnName) %>% summarize(Total=n()))
  }
  rm(TP.TXN)
  #option 2: only those with alert history
  #dtData.TPtag <- merge(x = dtDataPost, y = TP.TXN, by = c(byCustomerIDCol,txIDCol), all.y=TRUE)
  ## may want to create another category for unknown if use optin 1
  dtData.TPtag[c(tagColumnName)][is.na(dtData.TPtag[c(tagColumnName)])] <- "NotTP"
  dtData.TPtag[c("alert")][is.na(dtData.TPtag[c("alert")])] <- 0

  #keep ID order for later use
  dtData.TPtagID <- subset(dtData.TPtag, select = idColumns)
  #dtData.TPtag <- subset(dtData.TPtag, select = !(colnames(dtData.TPtag) %in% c(byCustomerIDCol,txIDCol)))
  #use country risk instead of ISO
  dtData.TPtag <- subset(dtData.TPtag, select = !(colnames(dtData.TPtag) %in% idColumns))

  if (isDebug(parms)) {
    message("========================== TP tagged data ===========================")
    print(head(dtData.TPtag))
    message("========================== TP tagged data - alert summary ===========================")
    print(dtData.TPtag %>% group_by_(tagColumnName, "alert")
      %>% summarize(Total=n()) %>% ungroup())
  }

  ## Random Forest
  set.seed(7)
  ## load model
  readInput(tpModelFileName, type="rda")
  fit_TP.rf <- update(fit_TP.rf, data = dtData.TPtag )
  if (isDebug(parms)) {
    message("========================== fit_TP.rf ===========================")
    print(fit_TP.rf)
  }
  if (storeUpdates) {
    assign("fit_TP.rf", fit_TP.rf, envir = .GlobalEnv)
    storeOutput("fit_TP.rf", name=tpModelFileName, type="rda")
  }

  getTree(fit_TP.rf$finalModel)
  TOPTP.VAR <- varImp(fit_TP.rf, scale=FALSE)

  ##assign scoring based on FP and TP prediction
  allCols <- c(all.vars(formula(fit_FP.rf)))
  validCols <- allCols[allCols %in% colnames(dtData.FPtag)]
  validation_FP <- subset(dtData.FPtag, select = validCols)
  missingCols <- allCols[!(allCols %in% colnames(dtData.FPtag))]
  if (length(missingCols)) {
    print(paste("Filling missing columns:", paste(missingCols,collapse=",")))
    for (i in 1:length(missingCols)) {
      validation_FP$extra <- 0
      setnames(validation_FP, "extra", missingCols[i])
    }
  }
  #count(validation_FP, FP_TP_Tag)
  ##exclude unseen CounterISO3
  #tmp_FP <- distinct(dtData.FPtag, CounterISO3)
  #validation_FP <- subset(dtData.FPtag, CounterISO3 %in% tmp_FP$CounterISO3)

  #for new CounterISO assign XXX
  #id <- which(!(validation_FP$CounterISO3 %in% unique(fit_FP.rf$trainingData$CounterISO3)))
  #validation_FP$CounterISO3[id] <- "XXX"

  ## prediction FP
  predictions_FP <- predict(fit_FP.rf, validation_FP)
  rm(validation_FP,dtData.FPtag,fit_FP.rf,TOPFP.VAR,allCols,validCols,missingCols)

  allCols <- c(all.vars(formula(fit_TP.rf)))
  validCols <- allCols[allCols %in% colnames(dtData.TPtag)]
  validation_TP <- subset(dtData.TPtag, select = validCols)
  missingCols <- allCols[!(allCols %in% colnames(dtData.TPtag))]
  if (length(missingCols)) {
    print(paste("Filling missing columns:", paste(missingCols,collapse=",")))
    for (i in 1:length(missingCols)) {
      validation_TP$extra <- 0
      setnames(validation_TP, "extra", missingCols[i])
    }
  }
  #count(validation_TP, FP_TP_Tag)

  #for new CounterISO assign XXX
  #id <- which(!(validation_TP$CounterISO3 %in% unique(fit_TP.rf$trainingData$CounterISO3)))
  #validation_TP$CounterISO3[id] <- "XXX"

  ## estimate skill of LDA on the validation dataset
  predictions_TP <- predict(fit_TP.rf, validation_TP)
  rm(validation_TP,dtData.TPtag,fit_TP.rf,TOPTP.VAR,allCols,validCols,missingCols)

  predictions_FP <- cbind(dtData.FPtagID, predictions_FP)
  predictions_TP <- cbind(dtData.TPtagID, predictions_TP)

  dtData <- merge(x = dtData, y = predictions_FP, by = idColumns, all.x=TRUE)
  dtData <- merge(x = dtData, y = predictions_TP, by = idColumns, all.x=TRUE)

  dtData$predictionScore <- ifelse(dtData$predictions_TP=="TP" ,999,ifelse(dtData$predictions_FP=="FP",25,200))
  dtData <- copy_to(sc, dtData, "fptp", overwrite=TRUE)
  dtData <- dtData %>% mutate(predictionInsights = paste('{"scoreReason":"',ifelse(predictions_TP=="TP" ,"previous SARs",ifelse(predictions_FP=="FP","previous Closed","Not tested")),'"}',sep="")) %>%
    rename_(.dots = setNames("predictionInsights", parms$Results$InsightColumn)) %>%
    rename_(.dots = setNames("predictionScore", parms$Results$ScoreColumn))

  return(select(dtData,c(idColumns,parms$Results$ScoreColumn,parms$Results$InsightColumn)))

}

calculateScoringBands <- function(parms) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scoring bands for reason type \"",flatparms["Results.ReasonType"],"\""))

  scoredData <- executeModels(parms)
  scores <- select(scoredData, c(parms$Results$ScoreColumn)) %>% collect()
  writeBandThresholds(as.matrix(scores), flatparms["Results.ReasonType"])
}

calculateScores <- function(parms, dfData=NULL) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scores for reason type \"",
    flatparms["Results.ReasonType"],"\""))

  scoredData <- executeModels(parms, dtData=dfData) %>% collect()
  if (isDebug(parms)) {
    message("========================== Scored data ===========================")
    print(head(scoredData))
  }
  if (!is.null(dfData)) { # Handle the case where not all entries might be scored,
    # ex: scoring by transaction bene account and some of the alerts were created
    # for the orig account
    if (parms$InputSource[[1]]$SourceType=="Aggregate") {
      idColumns <- getAggregateByColumnNames(parms$InputSource[[1]]$Type,
        parms$InputSource[[1]]$AggregateName)
    } else {
      idColumns <- getColumnNames(parms$InputSource[[1]]$Type,parms$InputSource[[1]]$IDColumns)
    }
    # set selected columns as character to match the conversion done in the scoring
    allIDs <- dfData %>% select(idColumns) %>% mutate_all(as.character)
    scoredData <- left_join(allIDs, scoredData)
  }
  if (isDebug(parms)) {
    message("========================== Scored data ===========================")
    print(head(scoredData))
  }

  return(scoredData)
}

getModelArtifacts <- function(parms) {

  # True positive model
  tpModelFileName <- getSupervisedMLModelFileName(parms,"ModelTP")
  readInput(tpModelFileName, type="rda")
  artifactNameTP <- paste("fit_TP.rf",parms$Results$ReasonType,sep="_")
  artifactLabelTP <- paste0(artifactNameTP," (True Positive Model, ReasonType: ",parms$Results$ReasonType,")")
  assign(artifactNameTP, fit_TP.rf, envir = .GlobalEnv)

  # False positive model
  fpModelFileName <- getSupervisedMLModelFileName(parms,"ModelFP")
  readInput(fpModelFileName, type="rda")
  artifactNameFP <- paste("fit_FP.rf",parms$Results$ReasonType,sep="_")
  artifactLabelFP <- paste0(artifactNameFP," (False Positive Model, ReasonType: ",parms$Results$ReasonType,")")
  assign(artifactNameFP, fit_FP.rf, envir = .GlobalEnv)

  labels <- c(artifactLabelTP,artifactLabelFP)
  names(labels) <- c(artifactNameTP,artifactNameFP)

  return(labels)
}
