# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
library(stringr)
library(tidyr)
source("AML_assessment.R")
source("AML_generateInsights.R")

# SQL statements
insightInsert <- "INSERT INTO INSIGHT (ALERT_ID,INSIGHT_ID,BAND) VALUES(?,?,?)"
insightVarInsert <- "INSERT INTO INSIGHT_VARIABLE (ALERT_ID,INSIGHT_ID,VARIABLE,VARIABLE_VALUE) VALUES(?,?,?,?)"
insightTxRefInsert <- "INSERT INTO INSIGHT_REFERENCE (ALERT_ID,INSIGHT_ID,REFERENCE_TYPE,REFERENCE_VALUE) VALUES(?,?,'RelatedTransaction',(SELECT TRANSACTION_ID FROM TRANSACTION WHERE EXTERNAL_TRANSACTION_ID=?))"
insightAlertRefInsert <- "INSERT INTO INSIGHT_REFERENCE (ALERT_ID,INSIGHT_ID,REFERENCE_TYPE,REFERENCE_VALUE) VALUES(?,?,'RelatedAlert',(SELECT ALERT_ID FROM ALERT WHERE EXTERNAL_ALERT_ID=?))"

# Transaction file columns
txIDCol <- getColumnName("Transactions", "IDColumn")
txAmountCol <- getColumnName("Transactions", "AmountColumn")
txCurrencyCol <- getColumnName("Transactions", "CurrencyColumn")
txCurrencyIDCol <- "FCAI_CURRENCY_ID"
txCreditDebitCol <- getColumnName("Transactions", "CreditDebitColumn")
txCreditValue <- getFileAttribute("Transactions","CreditValue")
txCreditFlagCol <- "FCAI_ISCREDIT"
txTransactionTypeIDCol <- "FCAI_TXTYPE_ID"
txTimestampCol <- getColumnName("Transactions", "TimestampColumn")
txOriginatorCol <- getColumnName("Transactions", "OriginatorColumn")
txOriginatorIDCol <- "FCAI_TX_ORIG_ID"
txOriginatorDisplayNameCol <- getColumnName("Transactions", "OriginatorDisplayNameColumn")
txOriginatorDisplayNameCol <- ifelse(!is.na(txOriginatorDisplayNameCol),txOriginatorDisplayNameCol,"FCAI_TX_ORIG_DISPLAY")
txOriginatorCountryCol <- getColumnName("Transactions", "OriginatorCountryColumn")
txOriginatorAddressIDCol <- "FCAI_TX_ORIG_ADDRESS_ID"
txOriginatorAccountCol <- getColumnName("Transactions", "OriginatorAccountColumn")
txOriginatorAccountIDCol <- "FCAI_TX_ORIG_ACCT_ID"
txOriginatorInstIDCol <- getColumnName("Transactions", "OriginatorInstIDColumn")
txBeneficiaryCol <- getColumnName("Transactions", "BeneficiaryColumn")
txBeneficiaryIDCol <- "FCAI_TX_BENE_ID"
txBeneficiaryDisplayNameCol <- getColumnName("Transactions", "BeneficiaryDisplayNameColumn")
txBeneficiaryDisplayNameCol <- ifelse(!is.na(txBeneficiaryDisplayNameCol),txBeneficiaryDisplayNameCol,"FCAI_TX_BENE_DISPLAY")
txBeneficiaryCountryCol <- getColumnName("Transactions", "BeneficiaryCountryColumn")
txBeneficiaryAddressIDCol <- "FCAI_TX_BENE_ADDRESS_ID"
txBeneficiaryAccountCol <- getColumnName("Transactions", "BeneficiaryAccountColumn")
txBeneficiaryAccountIDCol <- "FCAI_TX_BENE_ACCT_ID"
txBeneficiaryInstIDCol <- getColumnName("Transactions", "BeneficiaryInstIDColumn")
txIntermediaryCol <- getColumnName("Transactions", "IntermediaryColumn")
txIntermediaryIDCol <- "FCAI_TX_INTER_ID"
txIntermediaryDisplayNameCol <- getColumnName("Transactions", "IntermediaryDisplayNameColumn")
txIntermediaryDisplayNameCol <- ifelse(!is.na(txIntermediaryDisplayNameCol),txIntermediaryDisplayNameCol,"FCAI_TX_INTER_DISPLAY")
txIntermediaryCountryCol <- getColumnName("Transactions", "IntermediaryCountryColumn")
txIntermediaryAddressIDCol <- "FCAI_TX_INTER_ADDRESS_ID"
txIntermediaryAccountCol <- getColumnName("Transactions", "IntermediaryAccountColumn")
txIntermediaryAccountIDCol <- "FCAI_TX_INTER_ACCT_ID"
txIntermediaryInstIDCol <- getColumnName("Transactions", "IntermediaryInstIDColumn")
txIntermediary2AccountCol <- getColumnName("Transactions", "Intermediary2AccountColumn")
txIntermediary3AccountCol <- getColumnName("Transactions", "Intermediary3AccountColumn")
txIntermediary4AccountCol <- getColumnName("Transactions", "Intermediary4AccountColumn")
txReferenceIDCol <- getColumnName("Transactions", "ReferenceIDColumn")
txReferenceSourceCol <- getColumnName("Transactions", "ReferenceSourceColumn")
txTransactionTypeCol <- getColumnName("Transactions", "TransactionTypeColumn")
txClobCol <- "FCAI_TX_CLOB"

txDfColumns <- c(txIDCol, txTimestampCol,
  txAmountCol, txCurrencyCol, txTransactionTypeCol, txOriginatorCountryCol,
  txBeneficiaryCountryCol, txOriginatorCol, txOriginatorAccountCol,
  txOriginatorDisplayNameCol, txIntermediaryCol, txIntermediaryAccountCol,
  txIntermediaryDisplayNameCol, txBeneficiaryCol, txBeneficiaryAccountCol,
  txBeneficiaryDisplayNameCol, txCreditDebitCol)

txDfColumnsPost <- c(txIDCol, txTimestampCol,
  txAmountCol, txCurrencyIDCol, txTransactionTypeIDCol, txOriginatorAddressIDCol,
  txBeneficiaryAddressIDCol, txOriginatorIDCol,txOriginatorAccountIDCol,
  txOriginatorDisplayNameCol, txIntermediaryIDCol, txIntermediaryAccountIDCol,
  txIntermediaryDisplayNameCol, txBeneficiaryIDCol, txBeneficiaryAccountIDCol,
  txBeneficiaryDisplayNameCol, txCreditFlagCol, txClobCol)

txDBColumns <- c("EXTERNAL_TRANSACTION_ID","TRANSACTION_TIMESTAMP",
  "TRANSACTION_AMOUNT","CURRENCY_ID","TRANSACTION_TYPE_ID","FROM_ADDRESS",
  "TO_ADDRESS","ORIGINATING_PARTY_ID", "ORIGINATING_ACCOUNT_ID",
  "ORIGINATING_PARTY_NAME", "INTERMEDIARY_PARTY_ID", "INTERMEDIARY_ACCOUNT_ID",
  "INTERMEDIARY_PARTY_NAME", "DESTINATION_PARTY_ID", "DESTINATION_ACCOUNT_ID",
  "DESTINATION_PARTY_NAME", "IS_CREDIT", "FULL_TRANSACTION")

txMask <- !is.na(txDfColumns)
txDfColumns <- txDfColumns[txMask]
txDfColumnsPost <- txDfColumnsPost[txMask]
txDBColumns <- txDBColumns[txMask]

# Alert file columns
alertIDCol <- getColumnName("Alerts", "IDColumn")
alertCustomerCol <- getColumnName("Alerts", "CustomerIDColumn")
alertCustomerIDCol <- "FCAI_ALERT_PARTY_ID"
alertAccountCol <- getColumnName("Alerts", "AccountColumn")
alertSubjectDisplayNameCol <- getColumnName("Alerts","SubjectDisplayNameColumn")
alertTransactionIDCol <- getColumnName("Alerts", "TransactionIDColumn")
alertTitleCol <- getColumnName("Alerts", "TitleColumn")
alertCodeCol <- getColumnName("Alerts", "CodeColumn")
alertTypologyCol <- getColumnName("Alerts", "TypologyColumn")
alertSubTypologyCol <- getColumnName("Alerts", "SubTypologyColumn")
alertTriggeredTransCol <- getColumnName("Alerts", "TriggeredTransColumn")
alertDispositionCol <- getColumnName("Alerts", "DispositionColumn")
alertDispositionIDCol <- "FCAI_DISPOSITION_ID"
alertNarrativeCol <- getColumnName("Alerts", "NarrativeColumn")
alertReviewCommentsCol <- getColumnName("Alerts", "ReviewCommentsColumn")
alertCaseHistoryCol <- getColumnName("Alerts", "CaseHistoryColumn")
alertSARHistoryCol <- getColumnName("Alerts", "SARHistoryColumn")
alertScoreCol <- getColumnName("Alerts", "ScoreColumn")
alertFP_TP_TagCol <- getColumnName("Alerts", "FP_TP_TagColumn")
alertAlertCreateDateCol <- getColumnName("Alerts", "AlertCreateDateColumn")
alertCaseCreateDateCol <- getColumnName("Alerts", "CaseCreateDateColumn")
alertPriorityCol <- getColumnName("Alerts", "PriorityColumn")
alertSrcSysCol <- getColumnName("Alerts", "SourceColumn")

# Alert columns
alertDfColumns <- c(alertSubjectDisplayNameCol,alertCodeCol,
  alertTypologyCol,alertSubTypologyCol,alertTriggeredTransCol,
  alertNarrativeCol,alertReviewCommentsCol,alertCaseHistoryCol,
  alertSARHistoryCol,alertScoreCol,alertFP_TP_TagCol,alertAlertCreateDateCol,
  alertCaseCreateDateCol,alertPriorityCol,alertIDCol)
alertDBColumns <- c("PARTY_DISPLAY_NAME", "ALERT_CODE",
  "ALERT_TYPOLOGY", "ALERT_SUB_TYPOLOGY", "TRIGGERED_TRANSACTIONS",
  "NARRATIVE", "REVIEW_COMMENTS", "CASE_HISTORY",
  "SAR_HISTORY", "ORIGINAL_SCORE", "FP_TP_TAG", "ALERT_CREATE_DATE",
  "CASE_CREATE_DATE", "PRIORITY", "EXTERNAL_ALERT_ID")
alertColumnMask <- !is.na(alertDfColumns)
alertDfColumns <- alertDfColumns[alertColumnMask]
alertDBColumns <- alertDBColumns[alertColumnMask]

# Individual Customer file columns
individualIDCol <- getColumnName("Individuals", "IDColumn")
individualExternalIDCol <- getColumnName("Individuals", "ExternalIDColumn")
individualExternalSystemName <- getColumnName("Individuals", "ExternalSystemColumn")

# Organization customer file columns
organizationIDCol <- getColumnName("Organizations", "IDColumn")
organizationExternalIDCol <- getColumnName("Organizations", "ExternalIDColumn")
organizationExternalSystemName <- getColumnName("Organizations", "ExternalSystemColumn")

# Account file columns
accountFCAIIDCol <-"FCAI_ACCOUNT_ID"
accountIDCol <- getColumnName("Accounts", "IDColumn")
accountAlternateIDCol <- getColumnName("Accounts", "AlternateIDColumn")
accountTaxIDCol <- getColumnName("Accounts", "TaxIDColumn")
accountDisplayCol <- getColumnName("Accounts", "DisplayColumn")
accountTypeCol <- getColumnName("Accounts", "TypeColumn")
accountTypeIDCol <- "FCAI_TYPE_ID"
accountInitialDepositCol <- getColumnName("Accounts", "InitialDepositColumn")
accountBalanceCol <- getColumnName("Accounts", "BalanceColumn")
accountNetWorthPeriodEndCol <- getColumnName("Accounts", "NetWorthPeriodEndColumn")
accountPeerGroupCol <- getColumnName("Accounts", "PeerGroupColumn")
accountCurrencyCol <- getColumnName("Accounts", "CurrencyColumn")
accountBranchIDCol <- getColumnName("Accounts", "BranchIDColumn")
accountRelationshipMgrIDCol <- getColumnName("Accounts", "RelationshipMgrIDColumn")
accountOpenDateCol <- getColumnName("Accounts", "OpenDateColumn")
accountCloseDateCol <- getColumnName("Accounts", "CloseDateColumn")
accountCloseReasonCol <- getColumnName("Accounts", "CloseReasonColumn")
accountStatusCol <- getColumnName("Accounts", "StatusColumn")
accountStatusIDCol <- "FCAI_STATUS_ID"
accountStatusDateCol <- getColumnName("Accounts", "StatusDateColumn")
accountLastUpdatedCol <- getColumnName("Accounts", "LastUpdatedColumn")
accountSegmentCol <- getColumnName("Accounts", "SegmentColumn")
accountDormantStatusFlagCol <- getColumnName("Accounts", "DormantStatusFlagColumn")
accountFrozenStatusFlagCol <- getColumnName("Accounts", "FrozenStatusFlagColumn")
accountEffectiveRiskCol <- getColumnName("Accounts", "EffectiveRiskColumn")
accountBusinessRiskCol <- getColumnName("Accounts", "BusinessRiskColumn")
accountCustomRiskCol <- getColumnName("Accounts", "CustomRiskColumn")
accountPastConfirmedFraudCol <- getColumnName("Accounts", "PastConfirmedFraudColumn")
accountPastSuspectedFraudCol <- getColumnName("Accounts", "PastSuspectedFraudColumn")
accountPriorSARCountCol <- getColumnName("Accounts", "PriorSARCountColumn")
accountCustomized1Col <- getColumnName("Accounts", "Customized1Column")

accountDfColumns <- c(accountIDCol,accountAlternateIDCol,accountTaxIDCol,
  accountDisplayCol,accountStatusDateCol,accountInitialDepositCol,
  accountBalanceCol,accountNetWorthPeriodEndCol,accountOpenDateCol,
  accountCloseDateCol,accountPastConfirmedFraudCol,accountPastSuspectedFraudCol,
  accountPriorSARCountCol)
accountDBColumns <- c("ACCOUNT_NUMBER","ALT_ID","TAX_ID",
  "NAME","ACCOUNT_STATUS_TIMESTAMP","INITIAL_DEPOSIT",
  "CASH_VALUE","CASH_VALUE_TIMESTAMP","START_TIMESTAMP",
  "END_TIMESTAMP","PAST_CONFIRMED_FRAUD","PAST_SUSPECTED_FRAUD",
  "PRIOR_SAR_COUNT")
# "ACCOUNT_TYPE_ID","ACCOUNT_STATUS_ID" will be retrieved and filled in the query
# ignoring ACCOUNT_ID (autogenerated), TIMESTAMP (autogenerated), DESCRIPTION,
# ORIGINATION_TIMESTAMP, CANCELLATION_TIMESTAMP, BANK_ID
accountColumnMask <- !is.na(accountDfColumns)
accountDfColumns <- accountDfColumns[accountColumnMask]
accountDBColumns <- accountDBColumns[accountColumnMask]

# Account mapping file columns
accountmappingAccountCol <- getColumnName("AccountCustomerMapping", "AccountColumn")
accountmappingCustomerIDCol <- getColumnName("AccountCustomerMapping", "CustomerIDColumn")
accountmappingCustomerAccountRoleCol <- getColumnName("AccountCustomerMapping", "CustomerAccountRoleColumn")
accountmappingPartyIDCol <- "FCAI_ACCOUNT_PARTY_ID"

doAccountmapping <- TRUE
if (is.na(accountmappingAccountCol) || is.na(accountmappingCustomerIDCol)) {
  doAccountmapping <- FALSE
}

initializeCountryAddresses <- function(conn) {
  rs = dbSendQuery(conn, paste("select COUNTRY_ID,",AMLAnalyticConfig$CountryType,"as NAME, ISO3 from COUNTRY"))
  countriesdf = fetch(rs, -1)
  dbClearResult(rs)
  if (nrow(countriesdf[countriesdf$COUNTRY_ID==0,]) == 0) {
    message("Adding 'Unknown' country")
    dbSendUpdate(conn, "INSERT INTO COUNTRY (COUNTRY_ID,NAME,TYPEDEF,ISO2,ISO3,ISONUMERIC) VALUES (0,'Unknown', 'unknown', '','',0)")
    rs = dbSendQuery(conn, paste("select COUNTRY_ID,",AMLAnalyticConfig$CountryType,"as NAME, ISO3 from COUNTRY"))
    countriesdf = fetch(rs, -1)
    dbClearResult(rs)
  }
  colnames(countriesdf)[2] <- "NAME"
  countriesdf <- na.omit(countriesdf, cols="NAME")
  countryCount = nrow(countriesdf)

  rs = dbSendQuery(conn, "with DATA as (select row_number() over (partition by COUNTRY_ID) as num, COUNTRY_ID,ADDRESS_ID from ADDRESS WHERE NUMBER IS NULL AND LINE1 IS NULL AND LINE2 IS NULL AND LINE3 IS NULL AND CITY IS NULL AND CODE IS NULL AND COUNTY IS NULL AND STATE IS NULL) SELECT COUNTRY_ID,ADDRESS_ID from DATA where num=1")
  addressesdf = fetch(rs, -1)
  dbClearResult(rs)
  countriesdf <- merge(countriesdf, addressesdf, by="COUNTRY_ID", all.x=TRUE)

  for(i in 1:countryCount) {
    if (is.na(countriesdf[i,4])) {
      countriesdf[i,4] <- createCountryAddress(conn,countriesdf[i,1])
    }
  }
  assign("countriesdf", countriesdf, envir = .GlobalEnv)
}

createCountryAddress <- function(conn,countryID) {
  rs <- dbSendQuery(conn, paste("SELECT ADDRESS_ID FROM FINAL TABLE(INSERT INTO ADDRESS(COUNTRY_ID) VALUES(",countryID,"))",  sep = ''))
  newaddressdf = fetch(rs, -1)
  dbClearResult(rs)
  return(newaddressdf$ADDRESS_ID)
}

initializeAccountStatusIds <- function(conn) {
  rs = dbSendQuery(conn, "select ACCOUNT_STATUS_ID, lower(TYPEDEF) AS TYPEDEF from ACCOUNT_STATUS")
  accountstatusdf = fetch(rs, -1)
  dbClearResult(rs)
  assign("accountstatusdf", accountstatusdf, envir = .GlobalEnv)
}

initializeAccountTypeIds <- function(conn) {
  rs = dbSendQuery(conn, "select ACCOUNT_TYPE_ID, lower(TYPEDEF) AS TYPEDEF from ACCOUNT_TYPE")
  accounttypedf = fetch(rs, -1)
  dbClearResult(rs)
  assign("accounttypedf", accounttypedf, envir = .GlobalEnv)
}

initializeAlertDispositionIds <- function(conn) {
  rs = dbSendQuery(conn, "select ALERT_DISPOSITIONS_ID, lower(TYPEDEF) AS TYPEDEF from ALERT_DISPOSITIONS")
  alertdispdf = fetch(rs, -1)
  dbClearResult(rs)
  assign("alertdispdf", alertdispdf, envir = .GlobalEnv)
}

initializeCurrencyIds <- function(conn) {
  rs = dbSendQuery(conn, "select CURRENCY_ID, lower(TYPEDEF) AS TYPEDEF from CURRENCY")
  currencydf = fetch(rs, -1)
  dbClearResult(rs)
  assign("currencydf", currencydf, envir = .GlobalEnv)
}

initializeTransactionTypeIds <- function(conn) {
  rs = dbSendQuery(conn, "select TRANSACTION_TYPE_ID, lower(TYPEDEF) AS TYPEDEF from TRANSACTION_TYPE")
  transactiontypedf = fetch(rs, -1)
  dbClearResult(rs)
  assign("transactiontypedf", transactiontypedf, envir = .GlobalEnv)
}

addAddress <- function(x, orig_col, new_col) {
  x[new_col]=as.integer(0)
  x[new_col]=NA
  if ( !is.null(countriesdf) ) {
    for (i in 1:nrow(countriesdf)) {
      rows <- x[[orig_col]] == countriesdf$NAME[i]
      x[rows,new_col] <- as.integer(countriesdf$ADDRESS_ID[i])
    }
  }
  return(x)
}

addIDColumn <- function(x,idMap,origColumn,idColumn,tableName=NA) {
  if (!is.na(origColumn) && !all(is.na(x[[origColumn]]))) {
    x[[origColumn]] %<>% tolower()
    # the following seems to work with tidyr 0.8 but not with 0.7.1
    # x[[origColumn]] %<>% replace_na("unknown")
    # using base functionality instead
    x[is.na(x[[origColumn]]),origColumn] <- "unknown"
    colnames(idMap) <- c(idColumn,origColumn)
    x <- left_join(x,idMap)
    if (!all(!is.na(x[[idColumn]]))) {
      message(paste0(origColumn," values are missing corresponding TYPEDEF in TABLE ",tableName," (setting to 'unknown'): ",paste0(x[is.na(x[[idColumn]]),origColumn],collapse=",")))
      x[is.na(x[[idColumn]]),idColumn] <- as.integer(idMap[idMap[[2]]=="unknown",][[1]])
    }
  } else {
    x[idColumn] <- as.integer(idMap[idMap[[2]]=="unknown",][[1]])
  }
  return(x)
}

addIsCreditFlag <- function(x) {
  if (!is.na(txCreditDebitCol)) {
    x[[txCreditFlagCol]] = ifelse(x[[txCreditDebitCol]] %in% getFileAttribute("Transactions","CreditValue"),"Y","N")
  }
  return(x)
}

addAccountIDColumn <- function(x,idMap,origColumn,idColumn) {
  if (!is.na(origColumn) && !all(is.na(x[[origColumn]]))) {
    colnames(idMap) <- c(origColumn,idColumn)
    x <- left_join(x,idMap)
  } else {
    x[idColumn] <- NA
  }
  return(x)
}

getRelatedTransactions <- function(alertdf) {
  if (!is.na(alertTransactionIDCol)) {
    for (i in 1:nrow(alertdf)) {
      if (!exists("associatedTxList")) {
        associatedTxList <- unlist(strsplit(alertdf[[alertTransactionIDCol]][i], ";"))
      } else {
        associatedTxList <- unique(c(associatedTxList,unlist(strsplit(alertdf[[alertTransactionIDCol]][i], ";"))))
      }
    }
  } else {
    txMappingDef <- getFileAttributeObject("Alerts","TransactionIDMapping")
    if (!is.na(txMappingDef)) {
      filterCriteria = paste(getColumnName(txMappingDef$Source$Type,txMappingDef$Source$AlertIDColumn),"%in% alertdf[[alertIDCol]]")
      txMappings <- loadData(txMappingDef$Source$Type) %>% filter_(.dots = filterCriteria)
      associatedTxList <- sdf_read_column(txMappings,getColumnName(txMappingDef$Source$Type,txMappingDef$Source$TranIDColumn))
      associatedTxList <- unique(associatedTxList)
    } else {
      stop("Unable to determine related transactions from the Alerts configuration")
    }
  }
  if (!exists("associatedTxList")) {
    associatedTxList <- NULL
  }
  return(associatedTxList)
}

writeAccounts <- function(conn, alerts, transactions) {
  # get all associated accounts - from the alert and all accounts from the
  # associated transactions
  alertAccounts <- alerts[[alertAccountCol]]
  originatorAccounts <- transactions[[txOriginatorAccountCol]]
  intermediaryAccounts <- transactions[[txIntermediaryAccountCol]]
  destinationAccounts <- transactions[[txBeneficiaryAccountCol]]
  accounts <- c(alertAccounts,originatorAccounts,intermediaryAccounts,destinationAccounts)
  accounts <- accounts[!is.na(accounts)]
  accounts <- unique(accounts)

  # load the corresponding account data
  accountdf <- loadData("Accounts")
  filterCriteria = paste(accountIDCol,"%in% accounts")
  accountdf <- accountdf %>% filter_(.dots = filterCriteria)
  accountdf <- tbl_df(accountdf)

  # add account status and type ids
  accountdf <- addIDColumn(accountdf,accountstatusdf,accountStatusCol,
    accountStatusIDCol,"ALERT_REVIEW.ACCOUNT_STATUS")
  accountdf <- addIDColumn(accountdf,accounttypedf,accountTypeCol,
    accountTypeIDCol,"ALERT_REVIEW.ACCOUNT_TYPE")

  # add place holder for the FCAI_ACCOUNT_ID
  accountdf[[accountFCAIIDCol]] <- NA
  accountdf %<>% mutate_at(accountFCAIIDCol,as.numeric)

  # fix possible nulls from hive, they will be represented as 3.402823e+38
  if (!is.na(accountInitialDepositCol) && is.numeric(accountdf[[accountInitialDepositCol]])) {
    accountdf[[accountInitialDepositCol]] <- ifelse(abs(accountdf[[accountInitialDepositCol]])>10^38,0,accountdf[[accountInitialDepositCol]])
  }
  if (!is.na(accountBalanceCol) && is.numeric(accountdf[[accountBalanceCol]])) {
    accountdf[[accountBalanceCol]] <- ifelse(abs(accountdf[[accountBalanceCol]])>10^38,0,accountdf[[accountBalanceCol]])
  }

  if (doAccountmapping) {
    # load the parties for the accounts
    accountpartiesdf <- loadData("AccountCustomerMapping")
    filterCriteria = paste(accountmappingAccountCol,"%in% accounts")
    accountpartiesdf <- accountpartiesdf %>% filter_(.dots = filterCriteria)
    accountpartiesdf <- tbl_df(accountpartiesdf)

    # add the party id for the mapping
    accountpartiesdf <- addPartyID(accountpartiesdf, accountmappingCustomerIDCol,
      accountmappingPartyIDCol, addDisplayName=FALSE)
    if (is.na(accountmappingCustomerAccountRoleCol)) {
      accountpartiesdf[[accountmappingCustomerAccountRoleCol]] <- NA
    }
  }
  for (i in 1:nrow(accountdf)) {
    # determine which accounts are already in the db
    rs = dbSendQuery(conn, "SELECT ACCOUNT_ID,ACCOUNT_NUMBER FROM ACCOUNT WHERE ACCOUNT_NUMBER = ?",
      list=accountdf[i,][[accountIDCol]])
    accountDb = fetch(rs, -1)
    dbClearResult(rs)

    if (nrow(accountDb) > 0) {
      # update the existing record
      accountdf[i,][[accountFCAIIDCol]] <- accountDb$ACCOUNT_ID
      inss <- paste("UPDATE ACCOUNT SET (",
        paste(c("ACCOUNT_TYPE_ID","ACCOUNT_STATUS_ID",accountDBColumns),collapse=','),") = (",
        paste(rep("?", length(accountDBColumns) + 2), collapse = ','), ") WHERE ACCOUNT_ID=?", sep = '')
      dbSendUpdate(conn, inss, list = as.list(accountdf[i,] %>% select(c(accountTypeIDCol,accountStatusIDCol,accountDfColumns,accountFCAIIDCol))))

      if (doAccountmapping) {
        # remove and readd all account parties
        dbSendUpdate(conn,"DELETE FROM ACCOUNT_PARTY WHERE ACCOUNT_ID=?",list=accountdf[i,][[accountFCAIIDCol]])
        writeAccountParties(conn,accountpartiesdf,accountdf[i,][[accountIDCol]],
          accountdf[i,][[accountFCAIIDCol]])
      }
    } else {
      # create a new account record
      inss <- paste("SELECT ACCOUNT_ID FROM FINAL TABLE(INSERT INTO ACCOUNT (",
        paste(c("ACCOUNT_TYPE_ID","ACCOUNT_STATUS_ID",accountDBColumns),collapse=','),") VALUES (",
        paste(rep("?", length(accountDBColumns) + 2), collapse = ','), "))", sep = '')
      rs = dbSendQuery(conn, inss, list = as.list(accountdf[i,] %>% select(c(accountTypeIDCol,accountStatusIDCol,accountDfColumns))))
      newAccountDf = fetch(rs, -1)
      dbClearResult(rs)
      accountdf[i,][[accountFCAIIDCol]] <- newAccountDf$ACCOUNT_ID
      if (doAccountmapping) {
        writeAccountParties(conn,accountpartiesdf,accountdf[i,][[accountIDCol]],
          accountdf[i,][[accountFCAIIDCol]])
      }
    }
  }
  return(accountdf %>% select(c(accountIDCol,accountFCAIIDCol)))
}

writeAccountParties <- function(conn, accountParties, accountId, fcaiAccountId) {
  filterCriteria = paste(accountmappingAccountCol,"==",accountId)
  acc_maps <- accountParties %>% filter_(.dots=filterCriteria)
  if (nrow(acc_maps) > 0) {
    for (i in 1:nrow(acc_maps)) {
      dbSendUpdate(conn,"INSERT INTO ACCOUNT_PARTY (ACCOUNT_ID,PARTY_ID,PARTY_ACCT_ROLE) VALUES(?,?,?)",
        list=c(fcaiAccountId,acc_maps[i,accountmappingPartyIDCol],acc_maps[i,accountmappingCustomerAccountRoleCol]))
    }
  }
}

writeAlert <- function(conn, alert) {
  rs = dbSendQuery(conn, "select ALERT_ID from ALERT where EXTERNAL_ALERT_ID=?",
    list=c(alert[[alertIDCol]]))
  newAlertDf = fetch(rs, -1)
  dbClearResult(rs)

  if (nrow(newAlertDf)) {
    message("Updating existing alert")
    dbAlertData <- subset(alert, select=c(alertDispositionIDCol,alertDfColumns))
    names(dbAlertData) <- c("DISPOSITION_ID",alertDBColumns)

    # Use Prepared Statement.
    inss <- paste("UPDATE ALERT SET (",paste(names(dbAlertData[1:ncol(dbAlertData)-1]),collapse=','),") = (",
      paste(rep("?", length(dbAlertData)-1), collapse = ','), ") WHERE EXTERNAL_ALERT_ID=?", sep = '')
    dbSendUpdate(conn, inss, list = as.list(dbAlertData))
    return(c(0))
  } else {
    message("Creating new alert")
    dbAlertData <- subset(alert, select=c(alertCustomerIDCol,"calculatedScore",
      alertDispositionIDCol,alertDfColumns))
    names(dbAlertData) <- c("PARTY_ID","SCORE","DISPOSITION_ID",alertDBColumns)

    # Use Prepared Statement.
    inss <- paste("SELECT ALERT_ID FROM FINAL TABLE(INSERT INTO ALERT (STATUS_ID,",paste(names(dbAlertData),collapse=','),") VALUES (",
      "(SELECT MIN(ALERT_STATUS_ID) FROM ALERT_REVIEW.ALERT_STATUS),",paste(rep("?", length(dbAlertData)), collapse = ','), "))", sep = '')
    rs = dbSendQuery(conn, inss, list = as.list(dbAlertData))
    newAlertDf = fetch(rs, -1)
    dbClearResult(rs)
    return(newAlertDf$ALERT_ID)
  }
}

updateAlertScore <- function(conn,alert,score) {
  dbSendUpdate(conn, "UPDATE ALERT SET SCORE=? WHERE ALERT_ID=?",
    list=c(score,alert$dbAlertID))
}

writeTransaction <- function(conn, tx) {
  rs = dbSendQuery(conn, "select TRANSACTION_ID from TRANSACTION where EXTERNAL_TRANSACTION_ID=?",
    list=c(tx[[txIDCol]]))
  existingTxDf = fetch(rs, -1)
  dbClearResult(rs)

  if (nrow(existingTxDf)) {
    tx$dbTxID <- existingTxDf$TRANSACTION_ID
  } else {
    txFields <- subset(tx, select=txDfColumnsPost)
    names(txFields) <- txDBColumns
    # Use Prepared Statement.
    inss <- paste("SELECT TRANSACTION_ID FROM FINAL TABLE(INSERT INTO TRANSACTION (",
      paste(names(txFields),collapse=','),") VALUES (",
      paste(rep("?", length(txFields)), collapse = ','), "))", sep = '')
    rs = dbSendQuery(conn, inss, list = as.list(txFields))
    newTxDf = fetch(rs, -1)
    dbClearResult(rs)
    tx$dbTxID <- newTxDf$TRANSACTION_ID
  }
}

writeInsights <- function(conn, alert, allinsights) {
  insights <- allinsights %>% filter(alert_ID==alert[[alertIDCol]])
  if (!is.null(insights) && nrow(insights) > 0) {
    for (i in 1:nrow(insights)) {
      # Insert the insight record
      dbSendUpdate(conn, insightInsert, list=c(alert$dbAlertID,insights$insight_id[i],insights$band[i]))

      # Insert variables (if any)
      if (!is.na(insights$variables[i])) {
        # print(paste("Variables:",insights$variables[i]))
        for (j in 1:length(insights$variables[[i]])) {
          dbSendUpdate(conn, insightVarInsert, list=c(alert$dbAlertID,insights$insight_id[i],
            names(insights$variables[[i]])[j],
            ifelse(is.na(insights$variables[[i]][[j]]),"",insights$variables[[i]][[j]])))
        }
      }

      # Insert related transactions (if any)
      if (!is.na(insights$related_txn[i])) {
        # print(paste("Related txn:",insights$related_txn[i]))
        for (j in 1:length(insights$related_txn[i][[1]])) {
          tryCatch(
            {
              dbSendUpdate(conn, insightTxRefInsert, list=c(alert$dbAlertID,
                insights$insight_id[i], insights$related_txn[i][[1]][j]))
            },
            error=function(cond)
            {
              message(paste("No record found for related transaction",
              insights$related_txn[i][[1]][j]))
            },
            finally=
            {
              #leaving this blank
            }
          )
        }
      }

      # Insert related counterparties (if any)
      if (!is.na(insights$related_cntrparties[i])) {
        print(paste("Related counterparties:",insights$related_cntrparties[i]))
      }

      # Insert related alerts (if any)
      if (!is.na(insights$related_alerts[i])) {
        # print(paste("Related alerts:",insights$related_alerts[i]))
        for (j in 1:length(insights$related_alerts[i][[1]])) {
          tryCatch(
            {
              dbSendUpdate(conn, insightAlertRefInsert, list=c(alert$dbAlertID,
                insights$insight_id[i], insights$related_alerts[i][[1]][j]))
            },
            error=function(cond)
            {
              message(paste("No record found for related alert",insights$related_alerts[i][[1]][j]))
            },
            finally=
            {
              #leaving this blank
            }
          )
        }
      }
    }
  }
}

addPartyID <- function(x, orig_col, new_col, addDisplayName=FALSE, displayNameCol=NA) {
  if (!is.na(orig_col) && !all(is.na(x[[orig_col]]))) {
    customerData <- NULL
    if (!is.null(individualsdf) && sdf_nrow(individualsdf) > 0) {
      filterCriteria = paste0(individualExternalIDCol," %in% x$",orig_col)
      customers <- individualsdf %>% filter_(.dots = filterCriteria)
      if (!is.null(customers) && sdf_nrow(customers) > 0) {
        customers <- tbl_df(customers)
        if (addDisplayName) {
          customers$FCAI_DISPLAY_NAME <- getDisplayName(customers,"Individuals")
          customerData <- customers %>% select(c(individualExternalIDCol,
            individualIDCol,"FCAI_DISPLAY_NAME"))
          colnames(customerData) <- c(orig_col,new_col,"FCAI_DISPLAY_NAME")
        } else {
          customerData <- customers %>% select(c(individualExternalIDCol,
            individualIDCol))
          colnames(customerData) <- c(orig_col,new_col)
        }
      }
    }
    if (!is.null(organizationsdf) && sdf_nrow(organizationsdf) > 0) {
      filterCriteria = paste0(organizationExternalIDCol," %in% x$",orig_col)
      customers <- organizationsdf %>% filter_(.dots = filterCriteria)
      if (!is.null(customers) && sdf_nrow(customers) > 0) {
        customers <- tbl_df(customers)
        if (addDisplayName) {
          customers$FCAI_DISPLAY_NAME <- getDisplayName(customers,"Organizations")
          orgData <- customers %>% select(c(organizationExternalIDCol,
            organizationIDCol,"FCAI_DISPLAY_NAME"))
          colnames(orgData) <- c(orig_col,new_col,"FCAI_DISPLAY_NAME")
        } else {
          orgData <- customers %>% select(c(organizationExternalIDCol,
            organizationIDCol))
          colnames(orgData) <- c(orig_col,new_col)
        }
        if (!is.null(customerData)) {
          customerData <- rbind(customerData,orgData)
        } else {
          customerData <- orgData
        }
      }
    }
    if (!is.null(customerData)) {
      if (class(x[[orig_col]]) != class(customerData[[orig_col]])) {
        x %<>% mutate_at(orig_col,paste0("as.",class(customerData[[orig_col]])))
      }
      x <- left_join(x,customerData)
      if (addDisplayName) {
        x %<>% mutate_(.dots = setNames(paste("ifelse(is.na(",displayNameCol,"),FCAI_DISPLAY_NAME,",displayNameCol,")",sep=""),displayNameCol))
        x$FCAI_DISPLAY_NAME <- NULL
      }
    } else {
      x[new_col] <- NA
      if (addDisplayName) {
        x[displayNameCol] <- NA
      }
    }
  } else {
    x[new_col] <- NA
  }
  return(x)
}

exportToIGA <- function(alert, transaction) {

  iga <- data.frame(operationType="Insert Data", stringsAsFactors=FALSE)
  iga$originatingAccountID <- ifelse(!is.na(txOriginatorAccountCol),
    as.character(transaction[[txOriginatorAccountCol]]),"")
  iga$destinationAccountID <- ifelse(!is.na(txBeneficiaryAccountCol),
    as.character(transaction[[txBeneficiaryAccountCol]]),"")
  iga$intermediary1AccountID <- ifelse(!is.na(txIntermediaryAccountCol),
    as.character(transaction[[txIntermediaryAccountCol]]),"")
  iga$intermediary2AccountID <- ifelse(!is.na(txIntermediary2AccountCol),
    as.character(transaction[[txIntermediary2AccountCol]]),"")
  iga$intermediary3AccountID <- ifelse(!is.na(txIntermediary3AccountCol),
    as.character(transaction[[txIntermediary3AccountCol]]),"")
  iga$intermediary4AccountID <- ifelse(!is.na(txIntermediary4AccountCol),
    as.character(transaction[[txIntermediary4AccountCol]]),"")
  iga$externalTransactionID <- ifelse(!is.na(txIDCol),
    as.character(transaction[[txIDCol]]),"")
  iga$transactiontimestamp <- ifelse(!is.na(txTimestampCol),
    as.character(transaction[[txTimestampCol]]),"")
  iga$partyID <- ifelse(!is.na(alertCustomerIDCol),
    as.character(alert[[alertCustomerIDCol]]),"")
  iga$externalAlertID <- ifelse(!is.na(alertIDCol),
    as.character(alert[[alertIDCol]]),"")
  iga$timestamp <- ifelse(!is.na(alertAlertCreateDateCol),
    as.character(alert[[alertAlertCreateDateCol]]),"")
  iga$title <- ifelse(!is.na(alertTitleCol),
    as.character(alert[[alertTitleCol]]),"")
  iga$category <- ""
  iga$alertCode <- ifelse(!is.na(alertCodeCol),
    as.character(alert[[alertCodeCol]]),"")
  iga$alertTypology <- ifelse(!is.na(alertTypologyCol),
    as.character(alert[[alertTypologyCol]]),"")
  iga$alertSubTypology <- ifelse(!is.na(alertSubTypologyCol),
    as.character(alert[[alertSubTypologyCol]]),"")
  iga$alertDisposition <- ifelse(!is.na(alertDispositionCol),
    as.character(alert[[alertDispositionCol]]),"")
  iga$narative <- ifelse(!is.na(alertNarrativeCol),
    as.character(alert[[alertNarrativeCol]]),"")
  iga$reviewComments <- ifelse(!is.na(alertReviewCommentsCol),
    as.character(alert[[alertReviewCommentsCol]]),"")
  iga$caseHistory <- ifelse(!is.na(alertCaseHistoryCol),
    as.character(alert[[alertCaseHistoryCol]]),"")
  iga$sarHistory <- ifelse(!is.na(alertSARHistoryCol),
    as.character(alert[[alertSARHistoryCol]]),"")
  iga$originalScore <- ifelse(!is.na(alertScoreCol),
    as.character(alert[[alertScoreCol]]),"")
  iga$tenderType <- ""
  iga$instrumentNumber <- ""
  iga$referenceID <- ifelse(!is.na(txReferenceIDCol),
    as.character(transaction[[txReferenceIDCol]]),"")
  iga$branchNumber <- ""
  iga$branchDescription <- ""
  iga$vendor <- ""
  iga$productType <- ""
  iga$transactionAmount <- ifelse(!is.na(txAmountCol),
    as.character(transaction[[txAmountCol]]),"")
  iga$currency <- ifelse(!is.na(txCurrencyCol),
    as.character(transaction[[txCurrencyCol]]),"")
  iga$transactionType <- ifelse(!is.na(txTransactionTypeCol),
    as.character(transaction[[txTransactionTypeCol]]),"")
  iga$description <- ""
  iga$originatingPartyRelationship <- ""
  iga$destinationPartyRelationship <- ""
  iga$intermediatePartyRelationship <- ""
  iga$isCredit <- ifelse(!is.na(txCreditFlagCol),
    as.character(transaction[[txCreditFlagCol]]),"")
  iga[is.na(iga)] <- ""
  write(toJSON(unbox(iga)),file=paste0(AMLAnalyticConfig$IGAMessageDirectory,"/IGA_",alert[[alertIDCol]],
    "_",transaction[[txIDCol]],".json"))
}

convertTxToJson <- function(x) {
  return(data.frame(CLOB=as.character(toJSON(unbox(x))),stringsAsFactors=FALSE))
}

createPartyResultObject <- function(remoteKey, partyType, remSys, ID)
{
  #Creating partyNode
  partyNode = xmlNode(partyType)

  #Creating remoteKey node
  remoteKeyNode = xmlNode("remoteKey", remoteKey)

  #Creating sysRef node
  remoteSysNode = xmlNode("remoteSystemName", remSys)

  #Populate the partyNode
  partyNode = append.xmlNode(partyNode, remoteKeyNode)
  partyNode = append.xmlNode(partyNode, remoteSysNode)
  partyNode = toString.XMLNode(partyNode)

  #Turn partyNode into CDATA
  cData = xmlCDataNode(partyNode)

  #Creating the resultObject node
  resultObjectNode = xmlNode("resultObject", attrs=c(style = "xml", type = as.character(tolower(partyType)), Id = ID))
  resultObjectNode = append.xmlNode(resultObjectNode, cData)

  return(resultObjectNode)
}

createTxnResultObject <- function(remoteKey, curr, txnType, timestamp, remSys, ID)
{
  #Initialize transaction node
  transactionNode = xmlNode("Transaction")

  #Creating transaction CDATA block
   transactionIDNode = xmlNode("RemoteKey", remoteKey)
   transactionRemSysNode = xmlNode("remoteSystemName", remSys)
   currencyValueNode = xmlNode("CurrencyValue", curr)
   transactionTypeNode = xmlNode("TransactionType", txnType)
   businessTimeStampNode = xmlNode("BusinessTimestamp", timestamp)

   transactionNode = append.xmlNode(transactionNode, transactionIDNode)
   transactionNode = append.xmlNode(transactionNode, transactionRemSysNode)
   transactionNode = append.xmlNode(transactionNode, currencyValueNode)
   transactionNode = append.xmlNode(transactionNode, transactionTypeNode)
   transactionNode = append.xmlNode(transactionNode, businessTimeStampNode)

   transactionNode = toString.XMLNode(transactionNode)
   cDataTransaction = xmlCDataNode(transactionNode) #schema requires CDATA format

  #Creating the resultObject transaction node
  resultObjectNode = xmlNode("resultObject", attrs=c(style="xml",type="transaction", Id=ID))
  resultObjectNode = append.xmlNode(resultObjectNode, cDataTransaction)

  return(resultObjectNode)
}

processAlerts <- function() {

  #grab the start time of the analytics for platform messaging
  analyticTimeStart <- Sys.time()
  analyticTimeStartT <- sub(" ", "T", analyticTimeStart) #xml schema format requires a T in the timestamp

  alertdf <- tbl_df(loadData("Alerts"))
  if (nrow(alertdf) > 0) {
    alertCount = nrow(alertdf)
    reasonsDf <- populateReasonsDf()
    individualsdf <- loadData("Individuals")
    assign("individualsdf", individualsdf, envir = .GlobalEnv)
    organizationsdf <- loadData("Organizations")
    assign("organizationsdf", organizationsdf, envir = .GlobalEnv)
    if (!is.null(AMLAnalyticConfig$WriteResultsToDB) && AMLAnalyticConfig$WriteResultsToDB) {
      conn <- connectDb()
      initializeCountryAddresses(conn)
      initializeCurrencyIds(conn)
      initializeTransactionTypeIds(conn)
      initializeAlertDispositionIds(conn)
      initializeAccountStatusIds(conn)
      initializeAccountTypeIds(conn)
      reasontypedf <- initializeReasonTypes(conn)
      alertdf <- addIDColumn(alertdf,alertdispdf,alertDispositionCol,
        alertDispositionIDCol,"ALERT_REVIEW.ALERT_DISPOSITIONS")
      alertdf$dbAlertID <- 0
      alertdf$calculatedScore <- 0
      alertdf <- addPartyID(alertdf, alertCustomerCol, alertCustomerIDCol,
        addDisplayName=TRUE, displayNameCol=alertSubjectDisplayNameCol)

      associatedTxList <- getRelatedTransactions(alertdf)
      scoredTxdf <- NULL
      if (!is.null("associatedTxList") && length(associatedTxList) > 0) {
        filterCriteria = paste(txIDCol,"%in% associatedTxList")
        associatedTxdf <- collect(loadData("Transactions") %>% filter_(.dots = filterCriteria)) %>% distinct_(txIDCol, .keep_all=TRUE)

        # Add the original tx record as json
        associatedTxdf[[txClobCol]] <- (adply(associatedTxdf,1,convertTxToJson))$CLOB

        # score all of the associated transactions at once
        message("Calculating transaction scores")
        scoredTxdf <- calculateTransactionScores(associatedTxdf)
        scoredTxdf <- addOverallScore(scoredTxdf,reasonsDf)
        # Add the amldb transaction type id
        scoredTxdf <- addIDColumn(scoredTxdf,transactiontypedf,txTransactionTypeCol,
          txTransactionTypeIDCol,"ALERT_REVIEW.TRANSACTION_TYPE")
        # Add the amldb currency id
        scoredTxdf <- addIDColumn(scoredTxdf,currencydf,txCurrencyCol,
          txCurrencyIDCol,"ALERT_REVIEW.CURRENCY")
        scoredTxdf <- addIsCreditFlag(scoredTxdf)

        # Create accounts for all accounts referenced in the transactions
        accountIDMap <- writeAccounts(conn, alertdf, associatedTxdf)

        # Add the amldb account ids to the transactiopns
        scoredTxdf <- addAccountIDColumn(scoredTxdf,accountIDMap,txOriginatorAccountCol,txOriginatorAccountIDCol)
        scoredTxdf <- addAccountIDColumn(scoredTxdf,accountIDMap,txBeneficiaryAccountCol,txBeneficiaryAccountIDCol)
        scoredTxdf <- addAccountIDColumn(scoredTxdf,accountIDMap,txIntermediaryAccountCol,txIntermediaryAccountIDCol)

        # Add the amldb country address ids
        scoredTxdf <- addAddress(scoredTxdf, txBeneficiaryCountryCol, txBeneficiaryAddressIDCol)
        scoredTxdf <- addAddress(scoredTxdf, txOriginatorCountryCol, txOriginatorAddressIDCol)

        # Add the CEDM party id and display name (if needed)
        scoredTxdf <- addPartyID(scoredTxdf, txOriginatorCol, txOriginatorIDCol,
          addDisplayName=TRUE, displayNameCol=txOriginatorDisplayNameCol)
        scoredTxdf <- addPartyID(scoredTxdf, txBeneficiaryCol, txBeneficiaryIDCol,
          addDisplayName=TRUE, displayNameCol=txBeneficiaryDisplayNameCol)
        scoredTxdf <- addPartyID(scoredTxdf, txIntermediaryCol, txIntermediaryIDCol,
          addDisplayName=TRUE, displayNameCol=txIntermediaryDisplayNameCol)

        scoredTxdf$dbTxID <- 0
        # write all of the associated transactions to the db
        for (i in 1:nrow(scoredTxdf)) {
           writeTransaction(conn, scoredTxdf[i,])
        }
      }

      insights <- generateInsights(alertdf)

      for (i in 1:alertCount) {
        message(paste("Writing alert",as.character(i)))
        alertdf[i,]$dbAlertID <- writeAlert(conn, alertdf[i,])
        if (alertdf[i,]$dbAlertID) {
          associatedTxList <- getRelatedTransactions(alertdf[i,])
          message(paste("Alert",alertdf[[alertIDCol]][i],"associated transactions:",paste(associatedTxList, collapse=",")))
          filterCriteria = paste(txIDCol,"%in% associatedTxList")
          associatedTxdf <- scoredTxdf %>% filter_(.dots = filterCriteria)
          associatedTxCount = nrow(associatedTxdf)
          if (associatedTxCount > 0) {
            message(paste("Processing",associatedTxCount,"associatedTxdf"))
            updateAlertScore(conn,alertdf[i,],calculateCombinedScore(associatedTxdf$OverallScore))
            if (!is.null(AMLAnalyticConfig$IGAMessageDirectory) && !is.na(AMLAnalyticConfig$IGAMessageDirectory) && (nchar(trimws(AMLAnalyticConfig$IGAMessageDirectory)) > 0)) {
              for (j in 1:nrow(associatedTxdf)) {
                 exportToIGA(alertdf[i,], associatedTxdf[j,])
              }
            }
            analyticInsights <- generateAnalyticInsights(alertdf[[alertIDCol]][i],associatedTxdf)
            writeInsights(conn, alertdf[i,], analyticInsights)
          }
          writeInsights(conn, alertdf[i,], insights)
        }
      }
      if (AMLAnalyticConfig$AlertProcessing$TransactionHistory$Enabled) {
        # Add past transactions to display
        message(paste0("Adding other transactions (",
          AMLAnalyticConfig$AlertProcessing$TransactionHistory$PreviousDays,
          " days)"))
        allTx <- loadData("Transactions")
        for (i in 1:alertCount) {
          # filterCriteria = paste0(txCustomerIDCol," %in% alertdf$",alertCustomerCol,"[i]")
          # customerTx <- collect(allTx %>% filter_(.dots = filterCriteria))
          # message(paste0("============== CustomerID ",
          #   alertdf[[alertCustomerCol]][i]),": ALL ===============")
          # print(customerTx)

          alertDate <- as.Date(alertdf[[alertAlertCreateDateCol]][i])
          sixMonthsEarlier <- alertDate - AMLAnalyticConfig$AlertProcessing$TransactionHistory$PreviousDays
          filterCriteria = paste0(txOriginatorCol," %in% alertdf$",alertCustomerCol,"[i] & to_date(",txTimestampCol,") >= sixMonthsEarlier & to_date(",txTimestampCol,") <= alertDate")
          customerTx <- collect(allTx %>% filter_(.dots = filterCriteria)) %>% distinct_(txIDCol, .keep_all=TRUE)
          # message(paste0("============== CustomerID ",
          #   alertdf[[alertCustomerCol]][i],": ",sixMonthsEarlier," - ",
          #   alertDate," ==============="))
          # print(customerTx)
          txList <- paste0("'",paste0(customerTx[[txIDCol]],collapse="','"),"'")
          rs = dbSendQuery(conn, paste("SELECT DISTINCT(EXTERNAL_TRANSACTION_ID) FROM TRANSACTION WHERE EXTERNAL_TRANSACTION_ID IN (",txList,")"))
          existingTxdf = fetch(rs, -1)
          dbClearResult(rs)
          # filterCriteria = paste0("!",txIDCol," %in% existingTxdf[1]")
          # customerTx <- customerTx %>% filter_(.dots = filterCriteria)
          customerTx <- customerTx[!customerTx[[txIDCol]] %in% existingTxdf$EXTERNAL_TRANSACTION_ID,]
          if (nrow(customerTx) > 0) {
            message(paste("Copying",nrow(customerTx),
              "additional customer transactions for alert",i))

            # Add the original tx record as json
            customerTx[[txClobCol]] <- (adply(customerTx,1,convertTxToJson))$CLOB

            # Add the amldb transaction type id
            customerTx <- addIDColumn(customerTx,transactiontypedf,txTransactionTypeCol,
              txTransactionTypeIDCol,"ALERT_REVIEW.TRANSACTION_TYPE")
            # Add the amldb currency id
            customerTx <- addIDColumn(customerTx,currencydf,txCurrencyCol,
              txCurrencyIDCol,"ALERT_REVIEW.CURRENCY")
            customerTx <- addIsCreditFlag(customerTx)

            # Create accounts for all accounts referenced in the transactions
            accountIDMap <- writeAccounts(conn, alertdf, associatedTxdf)

            # Add the amldb account ids to the transactiopns
            customerTx <- addAccountIDColumn(customerTx,accountIDMap,txOriginatorAccountCol,txOriginatorAccountIDCol)
            customerTx <- addAccountIDColumn(customerTx,accountIDMap,txBeneficiaryAccountCol,txBeneficiaryAccountIDCol)
            customerTx <- addAccountIDColumn(customerTx,accountIDMap,txIntermediaryAccountCol,txIntermediaryAccountIDCol)

            # Add the amldb country address ids
            customerTx <- addAddress(customerTx, txBeneficiaryCountryCol, txBeneficiaryAddressIDCol)
            customerTx <- addAddress(customerTx, txOriginatorCountryCol, txOriginatorAddressIDCol)

            # Add the CEDM party id and display name (if needed)
            customerTx <- addPartyID(customerTx, txOriginatorCol, txOriginatorIDCol,
              addDisplayName=TRUE, displayNameCol=txOriginatorDisplayNameCol)
            customerTx <- addPartyID(customerTx, txBeneficiaryCol, txBeneficiaryIDCol,
              addDisplayName=TRUE, displayNameCol=txBeneficiaryDisplayNameCol)
            customerTx <- addPartyID(customerTx, txIntermediaryCol, txIntermediaryIDCol,
              addDisplayName=TRUE, displayNameCol=txIntermediaryDisplayNameCol)
            for (j in 1:nrow(customerTx)) {
               writeTransaction(conn, customerTx[j,])
            }
          } else {
            message(paste("No additional transactions to copy for alert",i))
          }
        }
      } else {
        message("TransactionHistory is not enabled.")
      }

      dbDisconnect(conn)

    } else { # WriteResultsToDB is FALSE
      message("Writing results to AML_ingestAlerts_out.csv")
      # score all of the associated transactions at once
      message("Calculating transaction scores")
      associatedTxList <- getRelatedTransactions(alertdf)
      if (!is.null("associatedTxList") && length(associatedTxList) > 0) {
        filterCriteria = paste(txIDCol,"%in% associatedTxList")
        associatedTxdf <- collect(loadData("Transactions") %>% filter_(.dots = filterCriteria))
        scoredTxdf <- calculateTransactionScores(associatedTxdf)
        scoredTxdf <- addOverallScore(scoredTxdf,reasonsDf)
        print(scoredTxdf, width=Inf)
      }
      alertdf$OverallScore <- 0
      for (i in 1:alertCount) {
        associatedTxList <- getRelatedTransactions(alertdf[i,])
        message(paste("Alert",alertdf[[alertIDCol]][i],"associated transactions:",paste(associatedTxList, collapse=",")))
        filterCriteria = paste(txIDCol,"%in% associatedTxList")
        associatedTxdf <- scoredTxdf %>% filter_(.dots = filterCriteria)
        associatedTxCount = nrow(associatedTxdf)
        if (associatedTxCount > 0) {
          alertdf$OverallScore[i] <- calculateCombinedScore(associatedTxdf$OverallScore)
        }
      }
      print(alertdf, width=Inf)

    }
    #grab the end time of the analytic for platform messaging
    analyticTimeStop <- Sys.time()
    analyticTimeStopT <- sub(" ", "T", analyticTimeStop)#xml schema format requires a T in the timestamp

    #Generating XML message

    #acquire parameters for connection to platform
    platformParms <- read_json("AML_platform_connection.json")

    #Check if the user has enabled platform messaging in AML_connection.json
    if (platformParms$sendMessage == TRUE)
      {

      library(httr)
      library(XML)
      xml <- xmlTree()

      tryCatch(
        {
          #The platform requires an additional token before a POST request can be sent
          addString <- sprintf("username=%s&password=%s", platformParms$platformUser, decodeValue(platformParms$platformPassword))
          tokenURL <- paste0(platformParms$tokenURL,addString)
          respToken <- GET(tokenURL, config = httr::config(ssl_verifypeer = platformParms$sslValidationEnabled))#, verbose())

      	  #the body contains the token
          body <- content(respToken, "parsed")
          cookie <- body$token

        },
          error=function(cond)
          {
          	message(paste("Failed to acquire session cookie"))
          	stop(paste("Error message: ", cond))

          },
          warning=function(cond)
          {
          	message(paste("There was a warning acquiring the session cookie"))
          	message(paste("Warning message: ", cond))
          },
          finally=
          {
          	#leaving this blank
          }
      )

      for (i in 1:(alertCount))#For every alert...
      {
        #Acquire the transactions in this alert
        associatedTxList <- getRelatedTransactions(alertdf[i,])

        #Acquire the scored transactions in this alert
        filterCriteria <- paste(txIDCol,"%in% associatedTxList")
        df_scoredTxdf <- collect(scoredTxdf %>% filter_(.dots = filterCriteria))#create a normal dataframe out of a spark dataframe

        #initialize variables used for focal/result object internal IDs
        objectIDs = NULL
        focalObjectID = 1

        #Acquire the alert score
        score <- df_scoredTxdf$OverallScore[1]#The first index is chosen because even if there are multiple transactions they will only be associated with the one alert with one score
        scoreNode = xmlNode("score", round(score, digits=0))

        #Acquire the name node
        name <- alertdf[[alertSubjectDisplayNameCol]][i]
        nameNode = xmlNode("name", name)

        #Acquire description
        description <- paste0("alertCode=", alertdf[[alertCodeCol]][i], ", ", "alertTypology=", alertdf[[alertTypologyCol]][i], ", ", "alertSubTypology=", alertdf[[alertSubTypologyCol]][i])
        descriptionNode = xmlNode("description", description)

        #Acquire the alert timestamp
        alertTimestamp <- alertdf[[alertAlertCreateDateCol]][i]
        alertTimestampT <- sub(" ", "T", alertTimestamp)

        #initializing top most nodes
        topNode = xmlNode("AnalysisAssessedResults")
        resultDataNode = xmlNode("resultData")
        resultDetailsNode = xmlNode("resultDetails")

        #Populating the AnalysisAssessedResults node
        if(!is.null(platformParms$remoteSystemRef))
        {
          topNode = append.xmlNode(topNode, xmlNode("remoteSystemRef", platformParms$remoteSystemRef))
        }
        else
        {
          topNode = append.xmlNode(topNode, xmlNode("remoteSystemRef", "FCAI_ALERT"))
          message("remoteSystemRef not set in AML_platform_connection configuration file. Using default value 'FCAI_ALERT'.")
        }

        topNode = append.xmlNode(topNode, xmlNode("success", "true"))

        # Filling resultData node with score, focalObject ID, context, name, description
        resultDataNode = append.xmlNode(resultDataNode, nameNode)
        resultDataNode = append.xmlNode(resultDataNode, descriptionNode)
        resultDataNode = append.xmlNode(resultDataNode, scoreNode)
        resultDataNode = append.xmlNode(resultDataNode, xmlNode("focalObject", attrs=c(Id = focalObjectID)))

        #Populating the AnalysisAssessedResults node
        if(!is.null(platformParms$context))
        {
          resultDataNode = append.xmlNode(resultDataNode, xmlNode("context", platformParms$context))
        }
        else
        {
          resultDataNode = append.xmlNode(resultDataNode, xmlNode("context", "cfm_default"))
          message("context not set in AML_platform_connection configuration file. Using default value 'cfm_default'.")
        }

        #Populate data node with timestamp
        resultDataNode = append.xmlNode(resultDataNode, xmlNode("timestamp", alertTimestampT))

        #Acquire the alert ID
        alertID <- alertdf[[alertIDCol]][i]
        keyString <- paste0(alertID, "-AI")

        #Save external and system key alert IDs
        resultPropertiesAlertIDExternal = xmlNode("resultProperties", attrs=c(propertyType="ExternalAlertId", propertyValue=alertID))
        resultPropertiesAlertID = xmlNode("resultProperties", attrs=c(propertyType="systemKey", propertyValue=keyString))

        #Creating searchFlag
        resultPropertiesSearch = xmlNode("resultProperties", attrs=c(propertyType="caseSearchFlag", propertyValue="search"))

        #Creating name and description
        resultPropertiesName = xmlNode("resultProperties", attrs=c(propertyType="createName", propertyValue=name))
        resultPropertiesDes = xmlNode("resultProperties", attrs=c(propertyType="createDescription", propertyValue=description))

        #Filling resultDetails node with alertID systemKey
        resultDetailsNode = append.xmlNode(resultDetailsNode, resultPropertiesAlertIDExternal)
        resultDetailsNode = append.xmlNode(resultDetailsNode, resultPropertiesAlertID)
        resultDetailsNode = append.xmlNode(resultDetailsNode, resultPropertiesSearch)
        resultDetailsNode = append.xmlNode(resultDetailsNode, resultPropertiesName)
        resultDetailsNode = append.xmlNode(resultDetailsNode, resultPropertiesDes)

        #Filling out extra properties from config file
        if(length(platformParms$resultProperties) > 0)#If there are extra properties...
        {
          for(b in 1:length(platformParms$resultProperties))#For each property...
          {
            #Acquire the necessary column name
            colName <- getColumnName("Alerts", platformParms$resultProperties[[b]])

            #Find the value
            value <- alertdf[[colName]][i]#Get teh value

            #Save property and value to resultDetailsNode
            resultProperties = xmlNode("resultProperties", attrs=c(propertyType=names(platformParms$resultProperties)[b], propertyValue=value))
            resultDetailsNode = append.xmlNode(resultDetailsNode, resultProperties)
          }
        }

        #Save the customer ID of the alert to be the focalObject
        customerFocalID <- alertdf[i, alertCustomerCol]

        #Set a flag for determining if the focal object has already been created
        focalObjSet <- 0

        #Set ID at 2 since focalObject has ID 1
        ID <- 2

        #Initialize a vector for keeping track of printed partyObjects
        printedObjects <- vector()

        #Create dataframe to keep track of resultObjects
        dfParty <- data.frame(partyID=numeric(), type=character(), remoteSys=character(), attrID=numeric())
        dfTxn <- data.frame(txnID=numeric(), curr=numeric(), txnType=character(), timestamp=character(), remoteSys=character(), attrID=numeric())

        for (m in 1:(length(associatedTxList)))#For each transaction...
        {

          #Find customerIDs of two parties involved in the transaction
          origID <- df_scoredTxdf[[txOriginatorCol]][which(df_scoredTxdf[[txIDCol]] == associatedTxList[m])]
          beneID <- df_scoredTxdf[[txBeneficiaryCol]][which(df_scoredTxdf[[txIDCol]] == associatedTxList[m])]

          #Save IDs to an array for easier processing
          IDArray <- c(origID, beneID)

          for(k in 1:length(IDArray))#For each party in this transaction
          {
            #Determine whether the party is in the "individuals" dataframe
            filterCriteria = paste0(individualExternalIDCol," == ",IDArray[k])
            customersInd <- individualsdf %>% filter_(.dots = filterCriteria)

            #If the party is in the indivduals dataframe, set partyType to Person
            #Otherwise set partyType to Organization
            if (sdf_nrow(customersInd) > 0)
            {
              partyType <- "Person"
              #Save the remote system source of the party
              remSys <- customersInd %>% select_(.dots=individualExternalSystemName)
              #remSys <- individuals_df[[individualExternalSystemName]][which(individuals_df[[individualExternalIDCol]] == IDArray[k])]
              #if the remote system source isn't set, automatically set it to CSV
              if (is.na(remSys) || remSys == "")
              {
                remSys <- "CSV"
              }
            }
            else
            {
              partyType <- "Organization"
              filterCriteria = paste0(organizationExternalIDCol," == ",IDArray[k])
              customersOrg <- organizationsdf %>% filter_(.dots = filterCriteria)
              #Save the remote system source of the party
              remSys <- customersOrg %>% select_(.dots=organizationExternalSystemName)

              #if the remote system source isn't set, automatically set it to CSV
              if (is.na(remSys) || remSys == "")
              {
                remSys <- "CSV"
              }
            }

            if(IDArray[k] != customerFocalID)#If the current party is not the focal party...
            {
              if (!(IDArray[k] %in% printedObjects))#...and it hasn't already been printed...
              {
                #Save the resultObject data
                tempdf <- data.frame(IDArray[k], partyType, remSys, ID)
                names(tempdf) <- c("partyID", "type", "remoteSys", "attrID")
                dfParty <- rbind(dfParty, tempdf)

                #Save the partyID so as not to print it again in the future
                printedObjects <- c(printedObjects, IDArray[k])

                #Create resultDetails property
                resultObjectProperties = xmlNode("resultObjects", attrs=c("Id"=ID))

                #Save to resultDetailsNode
                resultDetailsNode = append.xmlNode(resultDetailsNode, resultObjectProperties)

                #Increment the resultObject ID
                ID = ID + 1
              }

            }
            else #Otherwise, if the party IS the focal party...
            {
              if (focalObjSet == 0)#...and it hasn't been printed already...
              {
                #Create the result object
                tempdf <- data.frame(IDArray[k], partyType, remSys, 1)
                names(tempdf) <- c("partyID", "type", "remoteSys", "attrID")
                dfParty <- rbind(dfParty, tempdf)

                #Set the focalObject flag so the focalObject isn't printed again
                focalObjSet <- 1
              }
            }
          }

        	#Acquiring variables for transaction CDATA block
        	currencyValue <- df_scoredTxdf[[txAmountCol]][df_scoredTxdf[[txIDCol]]==associatedTxList[[m]]]
        	transactionType <- tolower(df_scoredTxdf[[txTransactionTypeCol]][m])
          tx_remSys <- df_scoredTxdf[[txReferenceSourceCol]][m]
        	timestamp <- df_scoredTxdf[[txTimestampCol]][m]
        	timestampT <- sub(" ", "T", timestamp) #xml schema format requires a T in the timestamp

          #if the remote system source isn't set, automatically set it to CSV
          if (is.na(tx_remSys) || tx_remSys == "")
          {
            tx_remSys <- "CSV"
          }

          #Save the txn data
          tempdf <- data.frame(associatedTxList[[m]], currencyValue, transactionType, timestampT, tx_remSys, ID)
          names(tempdf) <- c("txnID", "curr", "txnType", "timestamp", "remoteSys", "attrID")
          dfTxn <- rbind(dfTxn, tempdf)

          #Create resultDetails property
          resultObjectProperties = xmlNode("resultObjects", attrs=c("Id"=ID))

          #Save to resultDetailsNode
          resultDetailsNode = append.xmlNode(resultDetailsNode, resultObjectProperties)

          ID = ID + 1
        }

        #Append resultDetils to resultDataNode
        resultDataNode = append.xmlNode(resultDataNode, resultDetailsNode)

        #Append resultData to topNode
        topNode = append.xmlNode(topNode, resultDataNode)

        #Append party result objects to top node
        for(n in 1:nrow(dfParty))
        {
          resultObjectNode <- createPartyResultObject(dfParty$partyID[n], dfParty$type[n], dfParty$remoteSys[n], dfParty$attrID[n])
          topNode = append.xmlNode(topNode, resultObjectNode)
        }

        #Append transaction result to top node
        for (s in 1:nrow(dfTxn))
        {
          resultObjectNodeTxn <- createTxnResultObject(dfTxn$txnID[s], dfTxn$curr[s],
            dfTxn$txnType[s], dfTxn$timestamp[s], dfTxn$remoteSys[s], dfTxn$attrID[s])

          topNode = append.xmlNode(topNode, resultObjectNodeTxn)
        }

        #Save xml to file
        #saveXML((topNode), file=sprintf("message%s.xml", i)) #debugging only
        saveXML((topNode), file="message.xml")

        #Send xml to CFM

        #send the alert message
        tryCatch(
          {
            #adds the cookie acquired in the previous GET
            resp <- POST(url=platformParms$platformHost
            ,authenticate(platformParms$platformUser, platformParms$platformPassword),
            content_type_xml(), body=upload_file("message.xml"), add_headers('x-access-token' = cookie),
            config = httr::config(ssl_verifypeer = platformParms$sslValidationEnabled))#, verbose())

            print(content(resp))
            print(http_status(resp))#These may need to be taken out eventually since they print the cookie to the log
          },
          error=function(cond)
          {
            message(paste("Alert message failed to send"))
            message(paste("Error message: ", cond))
          },
          warning=function(cond)
          {
            message(paste("There is a warning with the alert message"))
            message(paste("Warning message: ", cond))
          },
          finally=
          {
            #leaving this blank
          }
        )

        #end sending XML message to platform

      }
    }
  }
}
