# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

library(tools)
library(jsonlite)
library(data.table)
library(magrittr)
library(plyr)
library(dplyr)
library(sparklyr)

AML_auditArtifacts_prefix = "ModelAuditArtifacts"
AML_clustering_nbclust_filename = "AML_clustering_nbclust.rda" #res
AML_rfmodel_FP_filename = "AML_rfmodel_FP.rda"
AML_rfmodel_TP_filename = "AML_rfmodel_TP.rda"
AML_tx_scored_filename <- "AML_tx_details_scored.csv"
AML_lowValue <- "low"
AML_mediumLowValue <- "mediumLow"
AML_medium <- "medium"
AML_mediumHighValue <- "mediumHigh"
AML_highValue <- "high"

sparkConnect <- function() {
  if (!exists("AMLAnalyticConfig")) {
    readAnalyticConfig()
  }
  sparkHome <- Sys.getenv(c("SPARK_HOME"))
  if (is.null(sparkHome) | sparkHome == "") {
    sparkHome <- AMLAnalyticConfig$Sparklyr$sparkHome
    Sys.setenv(SPARK_HOME=sparkHome)
    message(paste("Using SPARK_HOME from AMLAnalyticConfiguration:",sparkHome))
  } else {
    message(paste("Using SPARK_HOME from system environment:",sparkHome))
  }
  config <- spark_config()
  for (i in 1:length(AMLAnalyticConfig$Sparklyr$config)) {
    config[names(AMLAnalyticConfig$Sparklyr$config)[i]] <- AMLAnalyticConfig$Sparklyr$config[[i]]
  }
  spark_connect(master = AMLAnalyticConfig$Sparklyr$master,
    spark_home = sparkHome,
    app_name = ifelse(exists("appName"),appName,"AML_app_R"),
    config = config,
    version = AMLAnalyticConfig$Sparklyr$version)
}

# User configurable values
readAnalyticConfig <- function(training=FALSE, reset=FALSE) {
  if (!exists("AMLAnalyticConfig") | reset) {
    message(paste("Reading AMLAnalyticConfiguration.json, training =",training))
    AMLAnalyticConfig <- read_json("AMLAnalyticConfiguration.json")
    if (training) {
      for (i in 1:length(AMLAnalyticConfig$Files)) {
        for (ii in 1:length(AMLAnalyticConfig$Training$Files)) {
          if (AMLAnalyticConfig$Training$Files[[ii]]$Type == AMLAnalyticConfig$Files[[i]]$Type) {
            trainingElements <- names(AMLAnalyticConfig$Training$Files[[ii]])
            for (iii in 1:length(trainingElements)) {
              AMLAnalyticConfig$Files[[i]][[trainingElements[[iii]]]]<- AMLAnalyticConfig$Training$Files[[ii]][[trainingElements[[iii]]]]
            }
          }
        }
        if (!is.null(AMLAnalyticConfig$Files[[i]]$Aggregators)) {
          for (j in 1:length(AMLAnalyticConfig$Files[[i]]$Aggregators)) {
            if (AMLAnalyticConfig$Files[[i]]$Aggregators[[j]]$StoredAs$Type == "hive" | AMLAnalyticConfig$Files[[i]]$Aggregators[[j]]$StoredAs$Type == "csv") {
              AMLAnalyticConfig$Files[[i]]$Aggregators[[j]]$StoredAs$Name <- paste("Training_", AMLAnalyticConfig$Files[[i]]$Aggregators[[j]]$StoredAs$Name,sep="")
            }
          }
        }
      }
    }
    assign("AMLAnalyticConfig", AMLAnalyticConfig, envir = .GlobalEnv)
  }
}

loadCustomerCountries <- function(...) {
  individuals <- loadData("Individuals")
  individuals <- select(individuals, c(getColumnName("Individuals","ExternalIDColumn"),
    getColumnName("Individuals","ResidenceCountryColumn")))
  individuals <- tbl_df(individuals)
  colnames(individuals) <- c("CustomerID","Country")
  organizations <- loadData("Organizations")
  organizations <- select(organizations, c(getColumnName("Organizations","ExternalIDColumn"),
    getColumnName("Organizations","CountryOfResidencyColumn")))
  organizations <- tbl_df(organizations)
  colnames(organizations) <- c("CustomerID","Country")
  customers <- rbind(individuals, organizations)

  # if any countries are invalid, set to 'unknown'
  if (AMLAnalyticConfig$CountryType == "Name") {
    countryCol <- "Country"
  } else {
    countryCol <- AMLAnalyticConfig$CountryType
  }
  countries <- tbl_df(loadData("Countries"))
  # remove any countries from the country list which don't have a value
  countries <- countries[!is.na(countries[[countryCol]]),]
  # reset any countries not in the country list to 'unknown'
  customers %<>% mutate(Country=ifelse(Country %in% countries[[countryCol]],Country,"unknown"))
  return(customers)
}

isDataSrcValid <- function(src) {
  if (src$Type == "hive") {
    hTables <- src_tbls(sc)
    return(src$Name %in% hTables)
  } else if (src$Type == "csv") {
    if (startsWith(src$Path,"hdfs:/")) {
      return(TRUE) #unable to check the hdfs file system currently
    } else {
      return(file.exists(paste(src$Path,"/",src$Name,sep="")))
    }
  } else {
    stop(paste("Unsupported data source type:",src$Type))
  }
}

displayFeatures <- function(fileType=NA) {
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    featureContainer <- AMLAnalyticConfig$Files[[i]]
    if (is.na(fileType) || (!is.na(fileType) && featureContainer$Type==fileType)) {
      if (!is.null(featureContainer$Flags)) {
        writeLines(c("",paste("************************** Flags for:",featureContainer$Type,"****************************")))
        results <- loadData(featureContainer$Type, featureFlags=TRUE)
        sortColumn <- getColumnName(featureContainer$Type,"IDColumn")
        results <- sdf_sort(results, sortColumn)
        print(head(results), width=Inf)
        rm(results)
      }
      if (!is.null(featureContainer$Aggregators)) {
        writeLines(c("",paste("************************** Aggregators for:",featureContainer$Type,"****************************")))
        for (j in 1:length(featureContainer$Aggregators)) {
          agg <- featureContainer$Aggregator[[j]]
          writeLines(c("",paste("*** Aggregator:",agg$AggregateName),""))
          results <- loadData(featureContainer$Type, agg$AggregateName)
          sortColumns <- getColumnNames(featureContainer$Type,agg$AggregateBy)
          results <- sdf_sort(results, sortColumns)
          print(head(results), width=Inf)
          rm(results)
        }
      }
    }
  }
}

#calculate threshold for banding
FindTH <- function(x) {

  q <- quantile(x)
   lowerq = q[2]
   upperq = q[4]
   iqr = upperq - lowerq #Or use IQR(data)
   # we identify extreme outliers
   extreme.threshold.3upper = (iqr * 3) + upperq
   extreme.threshold.3lower = lowerq - (iqr * 3)
   extreme.threshold.2upper = (iqr * 2) + upperq
   extreme.threshold.2lower = lowerq - (iqr * 2)

   extreme.threshold.3std = (sd(x) * 3) + mean(x)
   extreme.threshold.2std = (sd(x) * 2) + mean(x)

   results <- c(lowerq, upperq, extreme.threshold.3upper, extreme.threshold.2upper, extreme.threshold.3std, extreme.threshold.2std, extreme.threshold.3lower, extreme.threshold.2lower)
   names(results) <- c("lowerq", "upperq", "3upperq", "2upperq", "3std", "2std", "3lowerq", "2lowerq")
   return(results)
}

augmentWithTimePeriods <- function(dt, timestampColumn, timestampFormat) {
  message(paste("augmentWithTimePeriods: Timestamp Column -",timestampColumn))
  message(paste("augmentWithTimePeriods: Timestamp Format -",timestampFormat))
  if (is.null(timestampFormat)) {
    dt %<>% mutate_(.dots = setNames(paste("unix_timestamp(",timestampColumn,")",sep=""),"DateTimeStamp"))
  } else {
    if (sdf_schema(dt)[[timestampColumn]]$type=="IntegerType") {
      dt %<>% mutate_at(c(timestampColumn), as.character)
    }
    dt %<>% mutate_(.dots = setNames(paste("unix_timestamp(",timestampColumn,",\"",timestampFormat,"\")",sep=""),"DateTimeStamp"))
  }
  dt %<>% mutate(Day=to_date(from_unixtime(DateTimeStamp)),
    Year=year(Day),
    Month=date_format(Day,"yyyy-MM"),
    Week=date_format(Day,"yyyy-ww"),
    Quarter=concat_ws("-",year(Day),quarter(Day)))
  return(dt)
}

setSource <- function(type, source) {
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (type == AMLAnalyticConfig$Files[[i]]$Type) {
      if (source$Type == "csv") {
        AMLAnalyticConfig$Files[[i]]$StoredAs$Name <- source$Name
        AMLAnalyticConfig$Files[[i]]$StoredAs$Type <- source$Type
        AMLAnalyticConfig$Files[[i]]$StoredAs$Path <- source$Path
      } else if (source$Type == "hive") {
        AMLAnalyticConfig$Files[[i]]$StoredAs$Name <- source$Name
        AMLAnalyticConfig$Files[[i]]$StoredAs$Type <- source$Type
        AMLAnalyticConfig$Files[[i]]$StoredAs$Path <- NULL
      } else {
        stop(paste("Unsupported data type:",source$Type))
      }
    }
  }
  assign("AMLAnalyticConfig", AMLAnalyticConfig, envir = .GlobalEnv)
}

loadData <- function(type, aggregateName=NA, featureFlags=FALSE, addTimes=FALSE, GII=FALSE) {
  if (is.na(aggregateName)) {
    message(paste("Loading",type))
  } else if (GII) {
    message(paste("Loading GII for aggregate ",aggregateName," (aggregated from ",type,")",sep=""))
  } else if (featureFlags) {
    message(paste("Loading flags for",type))
  } else {
    message(paste("Loading aggregate ",aggregateName," (aggregated from ",type,")",sep=""))
  }
  src <- NULL
  fileConfigObj <- NULL

  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (type == AMLAnalyticConfig$Files[[i]]$Type) {
      fileConfigObj <- AMLAnalyticConfig$Files[[i]]
      if (featureFlags) {
        if (!is.null(fileConfigObj$Flags)) {
          src <- fileConfigObj$Flags$StoredAs
        }
      } else if (!is.na(aggregateName)) {
        for (j in 1:length(fileConfigObj$Aggregators)) {
          if (aggregateName == fileConfigObj$Aggregators[[j]]$AggregateName) {
            if (GII) {
              src <- fileConfigObj$Aggregators[[j]]$GII$StoredAs
            } else {
              src <- fileConfigObj$Aggregators[[j]]$StoredAs
            }
            break
          }
        }
      } else {
        src <- fileConfigObj$StoredAs
      }
      break
    }
  }
  if (!is.null(src)) {
    delimiter <- ifelse(is.null(src$Delimiter),",",src$Delimiter)
    data <- readInput(src$Name, src$Type, src$Path, delimiter=delimiter)

    # if addTimes is true, the following columns will be appended to each row:
    # DateTimeStamp: unix timestamp
    # Day: yyyy-MM-dd
    # Year: yyyy
    # Month: yyyy-MM
    # Week: yyyy-ww
    # Quarter: yyyy-x (where x is in 1:4)
    if (!is.null(data) && addTimes && !is.null(fileConfigObj$TimestampColumn) && !is.null(fileConfigObj$TimestampFormat)) {
      data <- augmentWithTimePeriods(data, getColumnName(type,"TimestampColumn"), fileConfigObj$TimestampFormat)
    }

    # Join additional files as defined in the config
    # Two types of joins are supported:
    # indirect: there is a "mapping" file that is necessary to join the target Table
    #   Note: for an indirect join, all columns from the mapping table are removed
    #         from the final Table
    # direct: the target table is joined directly
    if (!GII && !is.null(data) && !is.null(fileConfigObj$JoinFiles)) {
      colsToBeRemoved <- c()
      for (i in 1:length(fileConfigObj$JoinFiles)) {
        joinfile <- fileConfigObj$JoinFiles[[i]]
        if (!is.null(joinfile$Source)) {
          if (tolower(joinfile$JoinType) == "indirect") {
            message(paste("Performing indirect join for",type))
            if (length(joinfile$Source) != 2) {
              stop(paste0("An indirect JoinType requires 2 sources, the JoinType for Type=",type," has ",length(joinfile$Source)))
            }
            # load and join the intermediate table
            mapping <- loadData(joinfile$Source[[1]]$Type)
            filterCriteria <- getFilterCriteria(joinfile$Source[[1]])
            if (!is.null(filterCriteria)) {
              message(paste("Filtering",joinfile$Source[[1]]$Type,"with filter:",filterCriteria))
              mapping %<>% filter_(.dots=filterCriteria)
              message(paste(sdf_nrow(mapping),"records after filter"))
            }
            originalMappingNames <- colnames(mapping)
            mapping %<>% select_(.dots=setNames(colnames(mapping), paste(joinfile$Prefix,colnames(mapping),sep="_")))
            mappingJoinByCols <- paste(joinfile$Prefix,getColumnNames(joinfile$Source[[1]]$Type,unlist(joinfile$Source[[1]]$JoinColumnsY)),sep="_")
            mappingColsToRemove <- colnames(mapping)[!(colnames(mapping) %in% mappingJoinByCols)]
            names(mappingJoinByCols) <- getColumnNames(type,unlist(joinfile$Source[[1]]$JoinColumnsX))
            data <- left_join(data,mapping,by=mappingJoinByCols)

            # load and join the target table
            joinData <- loadData(joinfile$Source[[2]]$Type)
            originalJoinNames <- colnames(joinData)
            filterCriteria <- getFilterCriteria(joinfile$Source[[2]])
            if (!is.null(filterCriteria)) {
              joinData %<>% filter_(.dots=filterCriteria)
              message(paste(sdf_nrow(joinData),"records after filter"))
            }
            joinData %<>% select_(.dots=setNames(colnames(joinData), paste(joinfile$Prefix,colnames(joinData),sep="_")))
            joinBy <- paste(joinfile$Prefix,getColumnNames(joinfile$Source[[2]]$Type,unlist(joinfile$Source[[2]]$JoinColumnsY)),sep="_")
            mappingColsToRemove <- mappingColsToRemove[!(mappingColsToRemove %in% joinBy)]
            names(joinBy) <- paste(joinfile$Prefix,getColumnNames(joinfile$Source[[1]]$Type,unlist(joinfile$Source[[2]]$JoinColumnsX)),sep="_")
            data <- left_join(data,joinData,by=joinBy)
            colsToBeRemoved <- c(colsToBeRemoved,mappingColsToRemove)
          } else if (tolower(joinfile$JoinType) == "direct") {
            message(paste("Performing direct join for",type))
            if (length(joinfile$Source) != 1) {
              stop(paste0("A direct JoinType requires 1 source, the JoinType for Type=",type," has ",length(joinfile$Source)))
            }
            # load and join the target table
            joinData <- loadData(joinfile$Source[[1]]$Type)
            filterCriteria <- getFilterCriteria(joinfile$Source[[1]])
            if (!is.null(filterCriteria)) {
              joinData %<>% filter_(.dots=filterCriteria)
              message(paste(sdf_nrow(joinData),"records after filter"))
            }
            joinData %<>% select_(.dots=setNames(colnames(joinData), paste(joinfile$Prefix,colnames(joinData),sep="_")))
            joinBy <- paste(joinfile$Prefix,getColumnNames(joinfile$Source[[1]]$Type,unlist(joinfile$Source[[1]]$JoinColumnsY)),sep="_")
            names(joinBy) <- getColumnNames(type,unlist(joinfile$Source[[1]]$JoinColumnsX))
            data <- left_join(data,joinData,by=joinBy)
          } else {
            stop(paste0("Unrecognized JoinType (",joinfile$JoinType,") for File with Type=",type))
          }
        } else {
          stop(paste0("A join requires at least one source, a JoinFile for Type=",type," has no source defined."))
        }
      }
      if (length(colsToBeRemoved) > 0) {
        data <- select(data,-one_of(colsToBeRemoved))
      }
    }
    return(data)
  } else {
    if (featureFlags) {
      message(paste("No Flags for ",type," is configured in AMLAnalyticConfiguration.json",sep=""))
    } else if (GII) {
      message(paste("No GII for aggregate named \"",aggregateName,"\" for ",type," is configured in AMLAnalyticConfiguration.json",sep=""))
    } else if (!is.na(aggregateName)) {
      message(paste("No aggregate named \"",aggregateName,"\" for ",type," is configured in AMLAnalyticConfiguration.json",sep=""))
    } else {
      message(paste0("Unable to load type ",type,",check configuration in AMLAnalyticConfiguration.json"))
    }
    return(NA)
  }
}

loadAnalyticInput <- function(inputSpec) {
  if (inputSpec$SourceType == "Aggregate") {
    dtData <- loadData(inputSpec$Type,inputSpec$AggregateName)
    if (!is.null(inputSpec$Thrd_GII) && inputSpec$Thrd_GII > 0) {
      #weight from univariate
      VarGII <- data.frame(loadData(inputSpec$Type,inputSpec$AggregateName, GII=TRUE),
        stringsAsFactors=FALSE)
      #select variable based on GII threshold
      VarGIIrds <- filter(VarGII, GII > inputSpec$Thrd_GII)
      GIIlist <- select(VarGIIrds,Feature) %>% collect()
      return(select(dtData,c(colnames(dtData)[1],GIIlist[["Feature"]])))
    } else {
      return(dtData)
    }
  } else if (inputSpec$SourceType == "File") {
    addTimes <- ifelse(!is.null(inputSpec$AddTimes),inputSpec$AddTimes,FALSE)
    dtData <- loadData(inputSpec$Type,addTimes=addTimes)
    if (!is.null(inputSpec$Columns) && length(inputSpec$Columns) > 0) {
      columns <- getColumnNames(inputSpec$Type,inputSpec$Columns)
      if (length(columns) > 0) {
        return(select(dtData,columns))
      }
    }
    return(dtData)
  } else if (inputSpec$SourceType == "Function") {
    if (!is.null(inputSpec$Source)) {
      source(inputSpec$Source)
    }
    func <- match.fun(inputSpec$FunctionName)
    return(func(inputSpec))
  } else {
    message(paste("Unsupported analytic InputSource.SourceType:",inputSpec$SourceType))
  }
  return(NA)
}

# Passed a configuration object containing a Filters object, generates a
# filterCriteria (string) which can be used to filter a spark dataframe
getFilterCriteria <- function(src) {
  filterCriteria <- NULL
  if (!is.null(src$Filters) && length(src$Filters) > 0) {
    for (j in 1:length(src$Filters)) {
      fltr <- src$Filters[[j]]
      if (length(fltr$Values)==1) {
        newFilterCriteria <- paste0(getColumnName(src$Type,fltr$Column)," == ",shQuote(fltr$Values,type="cmd"))
      } else {
        newFilterCriteria <- paste0(getColumnName(jsrc$Type,fltr$Column)," %in% c(",paste(toString(shQuote(fltr$Values,type="cmd"))),")")
      }
      if (is.null(filterCriteria)) {
        filterCriteria <- newFilterCriteria
      } else {
        filterCriteria <- paste0(filterCriteria," && ",newFilterCriteria)
      }
    }
  }
  return(filterCriteria)
}

getColumnName <- function(filetype, key) {
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (filetype == AMLAnalyticConfig$Files[[i]]$Type) {
      columnName <- AMLAnalyticConfig$Files[[i]][[key]]
      if (is.null(columnName)) {
        if (grepl(":",key)) {
          newParms <- unlist(strsplit(key,":"))
          columnName <- getColumnName(newParms[1],newParms[2])
        }
        if (is.null(columnName)) {
          stop(paste("Key",key,"is not defined for file type",filetype))
        }
      }
      if (!is.na(columnName)) {
        columnName <- trimws(columnName)
        if (nchar(columnName) == 0) {
          columnName <- NA
        } else if (AMLAnalyticConfig$Files[[i]]$StoredAs$Type == "hive") {
          columnName <- tolower(columnName)
        }
      }
      return(columnName)
    }
  }
  stop(paste("Key",key,"is not defined for file type",filetype))
}

getFileAttribute <- function(filetype, key) {
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (filetype == AMLAnalyticConfig$Files[[i]]$Type) {
      attribute <- AMLAnalyticConfig$Files[[i]][[key]]
      if (is.null(attribute)) {
        stop(paste("Key",key,"is not defined for file type",filetype))
      }
      if (!is.na(attribute)) {
        attribute <- trimws(attribute)
        if (nchar(attribute) == 0) {
          attribute <- NA
        }
      }
      return(attribute)
    }
  }
  stop(paste("Key",key,"is not defined for file type",filetype))
}

getFileAttributeObject <- function(filetype, key) {
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (filetype == AMLAnalyticConfig$Files[[i]]$Type) {
      attribute <- AMLAnalyticConfig$Files[[i]][[key]]
      if (is.null(attribute)) {
        stop(paste("Key",key,"is not defined for file type",filetype))
      }
      return(attribute)
    }
  }
  stop(paste("Key",key,"is not defined for file type",filetype))
}

getDisplayName <- function(df, filetype) {
  formatter <- getFileAttributeObject(filetype, "DefaultDisplayName")
  if (!is.null(formatter$Format) && !is.null(formatter$Columns)) {
    columnNames <- getColumnNames(filetype,formatter$Columns)
    displayNames <- do.call(sprintf, c(df %>% select(columnNames), formatter$Format))
    return(str_trunc(displayNames,200,side="right"))
  }
  return(NA)
}

calculateCombinedScore <- function(scores) {
  n=length(scores)
  if (n==1) {
    final_score <- scores[1]
  } else {
    da=c(1:n)
    scores = scores * exp(n/100)
    ss <- sort(scores)
    df_ss <- cbind(da, ss)
    rg_dfss <- lm(ss ~ da)
    da_p <- data.frame(da=n+1)
    p_score <- predict(rg_dfss, da_p)
    final_score <- min(1000, max(p_score, max(scores)))
  }
  return(final_score)
}

getResolvedEntities <- function(allIds) {

  resolvedEnts <- loadData("ResolvedEntities")
  if (sdf_nrow(resolvedEnts) == 0) {
    # set the altId for each entity to itself and return
    entitiesdf <- tbl_df(data.frame(entityId=allIds,altId=allIds,stringsAsFactors=FALSE))
    return(entitiesdf)
  }
  # Create a dataframe of external ids (entityId) and party ids (partyid) where
  # entityId consists of allIds
  individuals <- loadData("Individuals")
  individuals <- select(individuals, c(getColumnName("Individuals","ExternalIDColumn"),
    getColumnName("Individuals","IDColumn")))
  incomingIndividuals <- individuals %>%
    filter_(paste0(getColumnName("Individuals","ExternalIDColumn")," %in% allIds")) %>%
    rename_("entityId" = getColumnName("Individuals","ExternalIDColumn"), "partyid" = getColumnName("Individuals","IDColumn"))

  organizations <- loadData("Organizations")
  organizations <- select(organizations, c(getColumnName("Organizations","ExternalIDColumn"),
    getColumnName("Organizations","IDColumn")))
  incomingOrganizations <- organizations %>%
    filter_(paste0(getColumnName("Organizations","ExternalIDColumn")," %in% allIds")) %>%
    rename_("entityId" = getColumnName("Organizations","ExternalIDColumn"), "partyid" = getColumnName("Organizations","IDColumn"))

  incomingEntityPartyMap <- sdf_bind_rows(incomingIndividuals,incomingOrganizations)

  # get the list of partyids corresponding to allIds
  ips <- incomingEntityPartyMap %>% sdf_read_column("partyid")

  # read the ResolveEntities table (where reason = same, ie the entities represent
  # the same entity) and where partyid1 or partyid2 is in ips
  # TODO may not need the or in the last filter or the reverse if the recoreds are already duped
  resolvedEnts %<>%
    filter_(paste0(getColumnName("ResolvedEntities","ReasonColumn"),"=='same'")) %>%
    select(c(getColumnName("ResolvedEntities","PartyID1Column"),getColumnName("ResolvedEntities","PartyID2Column"))) %>%
    filter_(paste0(getColumnName("ResolvedEntities","PartyID1Column")," %in% ips | ",getColumnName("ResolvedEntities","PartyID2Column")," %in% ips")) %>%
    rename_("partyid" = getColumnName("ResolvedEntities","PartyID1Column"), "altpartyid" = getColumnName("ResolvedEntities","PartyID2Column"))

  # generate a dataframe with the inverse relatiionships (swap partyid1 and partyid2)
  reverseResolvedEnts <- resolvedEnts %>% rename(altpartyid=partyid,partyid=altpartyid)

  # create a single dataframe containing both normal and reversed relatiionships
  resolvedEnts <- sdf_bind_rows(resolvedEnts,reverseResolvedEnts)

  # do an inner join with the incomingEntityPartyMap (will join on partyid)
  resolvedIncomingParties <- incomingEntityPartyMap %>% inner_join(resolvedEnts)

  # now find the external ids for each of the alt party ids
  altParties <- resolvedIncomingParties %>% sdf_read_column("altpartyid") %>% unique()
  altIndividuals <- individuals %>%
    filter_(paste0(getColumnName("Individuals","IDColumn")," %in% altParties")) %>%
    rename_("altId" = getColumnName("Individuals","ExternalIDColumn"), "altpartyid" = getColumnName("Individuals","IDColumn"))
  altOrganizations <- organizations %>%
    filter_(paste0(getColumnName("Organizations","IDColumn")," %in% altParties")) %>%
    rename_("altId" = getColumnName("Organizations","ExternalIDColumn"), "altpartyid" = getColumnName("Organizations","IDColumn"))
  entityPartyMap <- sdf_bind_rows(altIndividuals,altOrganizations)

  # join the altId to the resolvedIncomingParties (joins on altpartyid) then
  # drop all columns except the entityId and the altId
  resolvedIncomingParties %<>% left_join(entityPartyMap) %>% select("entityId","altId")

  # create a self-mapping dataframe (each entity resolves to itself)
  selfResolvedEntities <- incomingEntityPartyMap %>% select("entityId") %>%
    mutate(altId=entityId)

  # combine the resolvedIncomingParties & selfResolvedEntities and return
  entitiesdf <- tbl_df(sdf_bind_rows(resolvedIncomingParties,selfResolvedEntities))
  return(entitiesdf)
}

getColumnNames <- function(filetype, keys) {
  keys <- unlist(keys)
  columnNames <- vector("list", length(keys))
  for (i in 1:length(keys)) {
    for (j in 1:length(AMLAnalyticConfig$Files)) {
      if (filetype == AMLAnalyticConfig$Files[[j]]$Type) {
        columnName <- AMLAnalyticConfig$Files[[j]][[keys[i]]]
        if (is.null(columnName)) {
          if (grepl(":",keys[i])) {
            newParms <- unlist(strsplit(keys[i],":"))
            columnName <- getColumnName(newParms[1],newParms[2])
          }
          if (is.null(columnName)) {
            stop(paste("Key",keys[i],"is not defined for file type",filetype))
          }
        }
        if (!is.na(columnName)) {
          columnName <- trimws(columnName)
          if (nchar(columnName) == 0) {
            columnName <- NA
          } else if (AMLAnalyticConfig$Files[[j]]$StoredAs$Type == "hive") {
            columnName <- tolower(columnName)
          }
        }
        columnNames[i] <- columnName
      }
    }
  }
  unlist(columnNames)
}

getAggregateByColumnNames <- function(filetype, aggregateName) {

  for (i in 1:length(AMLAnalyticConfig$Files)) {
    if (filetype == AMLAnalyticConfig$Files[[i]]$Type) {
      aggregators <- AMLAnalyticConfig$Files[[i]]$Aggregators
      if (is.null(aggregators)) {
        stop(paste("No aggregators are not defined for file type",filetype))
      }
      for (j in 1:length(aggregators)) {
        if (aggregateName == aggregators[[j]]$AggregateName) {
          aggregateByColumns <- aggregators[[j]]$AggregateBy
          if (is.null(aggregators)) {
            stop(paste("AggregateBy is not defined for file type",filetype,"with aggregator",aggregateName))
          }
          return(getColumnNames(filetype,aggregateByColumns))
        }
      }
      stop(paste("Aggregator",aggregateName,"is not defined for file type",filetype))
    }
  }
}

readInput <- function(name, type="csv", path=NA, delimiter=",") {
  if (tolower(type) == "csv") {
    fileName <- paste(path,"/",name,sep="")
    while (grepl(".",name,fixed=TRUE)) { # need to remove . from table name
      name <- file_path_sans_ext(name)
    }
    message(paste("Reading data from", fileName, "as", type))
    spark_read_csv(sc, name, fileName, delimiter=delimiter)
    rawData <- tbl(sc, name)
    message(paste(sdf_nrow(rawData),"records read"))
    return(rawData)
  } else if (tolower(type) == "hive") {
    message(paste("Reading data from hive table", name))
    spark_read_table(sc, name)
    rawData <- tbl(sc, name)
    message(paste(sdf_nrow(rawData),"records read"))
    return(rawData)
  } else if (tolower(type) == "rda") {
    if (is.na(path)) {
      path <- AMLAnalyticConfig$ModelDirectory
    }
    fullModelPath <- paste(path,"/",basename(name),sep="")
    message(paste("Reading model from file", fullModelPath))
    load(fullModelPath, envir = .GlobalEnv)
  } else {
    stop(paste("Unsupported data type:",type))
  }
}

storeOutput <- function(data, name, path=NA, type="csv") {
  if (tolower(type) == "csv") {
    name <- file_path_sans_ext(name)
    message(paste("Writing",name,"to",path,"as",type))
    fileName <- paste(path,"/",name,".",type,sep="")
    spark_write_csv(data, fileName, mode="overwrite")
  } else if (tolower(type) == "rda") {
    if (is.na(path)) {
      path <- AMLAnalyticConfig$ModelDirectory
    }
    fullModelPath <- paste(path,"/",basename(name),sep="")
    message(paste("Writing model to file", fullModelPath))
    if (file.exists(fullModelPath)) {
      file.remove(fullModelPath)
    }
    model <- save(list=data, file=fullModelPath)
    return(model)
  } else {
    stop(paste("Unsupported data type:",type))
  }
}

saveModelArtifacts <- function() {
  # configuration
  configuration <- toJSON(AMLAnalyticConfig, pretty=TRUE)
  assign("configuration", configuration, envir = .GlobalEnv)
  objectIndex <- c("configuration (AMLAnalyticConfig.json)")
  names(objectIndex) <- c("configuration")

  # get any artifacts from the Analytics
  allAnalytics <- AMLAnalyticConfig$Analytics
  for (i in 1:length(allAnalytics)) {
    parms <- allAnalytics[[i]]
    if (!is.null(parms$ArtifactsFunction)) {
      message(paste0("\n******* Found ",allAnalytics[[i]]$Type," (index ",i,") - ",
        allAnalytics[[i]]$Results$ReasonType))
      source(parms$Source)

      # execute score banding function
      func <- match.fun(parms$ArtifactsFunction)
      newObjects <- func(parms=parms)
      objectIndex <- c(objectIndex, newObjects)
    }
  }

  # get any GII produced through aggregation
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    aggContainer <- AMLAnalyticConfig$Files[[i]]
    if (!is.null(aggContainer$Aggregators)) {
      for (j in 1:length(aggContainer$Aggregators)) {
        agg <- aggContainer$Aggregator[[j]]
        if (!is.null(agg$GII)) {
          writeLines(c("",paste("*** Aggregator:",agg$AggregateName),""))
          gii <- loadData(aggContainer$Type, agg$AggregateName, GII=TRUE)
          artifactName <- paste(aggContainer$Type, agg$AggregateName,"GII",sep="_")
          artifactLabel <- paste0(artifactName," (General Interestingness Index)")
          assign(artifactName, gii, envir = .GlobalEnv)

          newObject <- c(artifactLabel)
          names(newObject) <- c(artifactName)
          objectIndex <- c(objectIndex, newObject)
        }
      }
    }
  }

  assign("objectIndex", objectIndex, envir = .GlobalEnv)
  modelAuditFile <- format(Sys.time(), paste0(AML_auditArtifacts_prefix,"%Y-%m-%d_%H.%M.%S.rda"))
  objectsToStore <- c("objectIndex", names(objectIndex))
  print(objectsToStore)
  storeOutput(objectsToStore, name=modelAuditFile, type="rda")
  rm(list=objectsToStore, envir = .GlobalEnv)
  return(modelAuditFile)
}

loadModelArtifacts <- function(fileName = NA) {
  if (is.na(fileName)) {
    path <- AMLAnalyticConfig$ModelDirectory
    modelFiles <- sort(list.files(AMLAnalyticConfig$ModelDirectory, pattern=paste0("^",AML_auditArtifacts_prefix)), decreasing=TRUE)
    if (length(modelFiles) > 0) {
      fileName <- modelFiles[1]
    } else {
      stop(paste0("No model artifacts files (",AML_auditArtifacts_prefix,"*) could be found in ",path))
    }
  }
  readInput(fileName, type="rda")
  message(paste("\nLoaded model artifacts from",fileName))
  for (i in 1:length(objectIndex)) {
    message(paste("\n\n***",objectIndex[i],"***\n"))
    objName <- names(objectIndex[i])
    if (objName=="configuration") {
      message(paste(substr(configuration,1,1000),"..."))
    } else {
      obj <- get(objName)
      if (!is.null(obj[["Best.nc"]])) { # cluster model
        print(obj$Best.nc)
      } else {
        print(obj)
      }
    }
  }
}

removeRowsWithInvalidIDs <- function(dtData, idColumns) {
  filteredData <- dtData
  for (i in 1:length(idColumns)) {
    filterCriteria = paste0("!is.na(",idColumns[i],")")
    filteredData <- filteredData %>% filter_(.dots=filterCriteria)
  }
  removedCount <- as.integer(collect(count(dtData))) - as.integer(collect(count(filteredData)))
  if (removedCount > 0) {
    message(paste0("*** Note: removed ",removedCount," records with an NA id column (",paste0(idColumns,collapse=","),")"))
  }
  return(filteredData)
}

doNAaggregate <- function(dtData) {
  dtData[sapply(dtData, is.numeric)] <- lapply(dtData[sapply(dtData, is.numeric)], function(x) ifelse(is.na(x), mean(x, na.rm = TRUE), x))
  return(dtData)
}

applyCommandLineFileArg <- function(filetype, args) {
  if (length(args)) {
    if (!is.na(args[2]) & tolower(args[2]) == "hive") {
      inputFile <- tbl_df(data.frame(Name=args[1],Type="hive",stringsAsFactors=FALSE))
      message(paste("Using input args for ",filetype," - Table: ", inputFile$Name, ", Type: ", inputFile$Type, sep=""))
    } else if (!is.na(args[2])) {
      inputFile <- tbl_df(data.frame(Name=basename(args[1]),Type=tolower(args[2]),Path=dirname(args[1]),stringsAsFactors=FALSE))
      message(paste("Using input args for ",filetype," - File: ", inputFile$Name, ", Type: ", inputFile$Type, ", Path: ", inputFile$Path, sep=""))
    } else {
      fileName <- basename(args[1])
      inputFile <- tbl_df(data.frame(Name=basename(fileName),Type=tolower(file_ext(fileName)),Path=dirname(args[1]),stringsAsFactors=FALSE))
      message(paste("Using input args for ",filetype," - File: ", inputFile$Name,".",inputFile$Type,", Type: ", inputFile$Type, ", Path: ", inputFile$Path,sep=""))
    }
    if (isDataSrcValid(inputFile)) {
      setSource(filetype, as.list(inputFile))
    } else {
      stop(paste(filetype,"source does not exist:",inputFile$Name,"of type",inputFile$Src))
    }
  } else {
    inputFile <- tbl_df(t(unlist(sapply(AMLAnalyticConfig$Files, function(X) if (X$Type == filetype) X$StoredAs))))
    colnames(inputFile) <- c("Name","Type","Path")
    if (isDataSrcValid(inputFile)) {
      message(paste("No arguments supplied, using default file (",filetype,") from AMLAnalyticConfiguration.json: ", inputFile$Name,sep=""))
      setSource(filetype, as.list(inputFile))
    } else {
      stop(paste(filetype," source does not exist, update the AMLAnalyticConfiguration.json with a valid ",filetype," file",sep=""))
    }
  }
}

validateScoredAlerts <- function() {
  AML_scored_alerts_input <- tbl_df(t(unlist(sapply(AMLAnalyticConfig$Training$Files, function(X) if (X$Type == "Alerts") X$StoredAs))))
  colnames(AML_scored_alerts_input) <- c("Name","Type","Path")
  if (!isDataSrcValid(AML_scored_alerts_input)) {
    stop("Alerts source does not exist, update the AMLAnalyticConfiguration.json with a valid Alerts training file")
  }
  return(AML_scored_alerts_input)
}

isDebug <- function(parms) {
  if (!is.null(parms$Debug) && parms$Debug) {
    return(TRUE)
  } else {
    return(FALSE)
  }
}

createSourceHeader <- function(source) {
  if (source$SourceType=="File") {
    return(paste("==========================",source$Type,"=========================="))
  } else if (source$SourceType=="Aggregate") {
    return(paste("==========================",source$Type,"-",source$AggregateName,"=========================="))
  } else if (source$SourceType=="Function") {
    return(paste("==========================",source$SourceType,"-",source$FunctionName,"=========================="))
  } else {
    return(paste("==========================",source$SourceType,"=========================="))
  }
}

createDataHeader <- function(title) {
  return(paste("==========================",title,"=========================="))
}

writeBandThresholds <- function(scores, reasonType, threeBand=FALSE) {

  thresholds <- FindTH(scores)

  if (!is.null(AMLAnalyticConfig$WriteResultsToDB) && AMLAnalyticConfig$WriteResultsToDB) {
    message(paste("Updating",reasonType,"bands in db"))
    conn <- connectDb()
    reasontypedf <- initializeReasonTypes(conn)
    reasonTypeID <- getReasonTypeID(reasontypedf,reasonType);
    dbSendUpdate(conn, paste0("DELETE FROM REASON_RISK WHERE REASON_TYPE_ID=",reasonTypeID))

    if (threeBand) {
      # 3-bands
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'3 band low','low',NULL,",thresholds['upperq'],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'3 band medium','medium',",thresholds['upperq'],",",thresholds['3upperq'],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'3 band high','high',",thresholds['3upperq'],",NULL)"))
    } else {
      # 5-bands
      thresholds <- sort(thresholds)
      thresholds <- thresholds[thresholds>0]
      thresholds <- thresholds[thresholds<=1000]
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'5 band low','low',NULL,",thresholds[1],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'5 band medium low','mediumLow',",thresholds[1],",",thresholds[3],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'5 band medium','medium',",thresholds[3],",",thresholds[4],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'5 band medium high','mediumHigh',",thresholds[4],",",thresholds[length(thresholds)],")"))
      dbSendUpdate(conn, paste0("INSERT INTO REASON_RISK (REASON_TYPE_ID,NAME,TYPEDEF,LOW_SCORE,HIGH_SCORE) VALUES(",reasonTypeID,",'5 band high','high',",thresholds[length(thresholds)],",NULL)"))
    }
    dbDisconnect(conn)
    message("Db update complete")
  }

  bandThresholds <- data.frame(band=character(), low_score=numeric(), high_score=numeric(),stringsAsFactors = FALSE)
  if (threeBand) {
    # 3-bands
    bandThresholds <- rbind(bandThresholds, data.frame(band="low",low_score=0,high_score=thresholds["upperq"],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="medium",low_score=thresholds["upperq"],high_score=thresholds["3upperq"],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="high",low_score=thresholds["3upperq"],high_score=Inf,stringsAsFactors = FALSE))
  } else {
    # 5-bands
    thresholds <- sort(thresholds)
    thresholds <- thresholds[thresholds>0]
    thresholds <- thresholds[thresholds<=1000]
    bandThresholds <- rbind(bandThresholds, data.frame(band="low",low_score=0,high_score=thresholds[1],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="mediumLow",low_score=thresholds[1],high_score=thresholds[3],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="medium",low_score=thresholds[3],high_score=thresholds[4],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="mediumHigh",low_score=thresholds[4],high_score=thresholds[length(thresholds)],stringsAsFactors = FALSE))
    bandThresholds <- rbind(bandThresholds, data.frame(band="high",low_score=thresholds[length(thresholds)],high_score=Inf,stringsAsFactors = FALSE))
  }
  rownames(bandThresholds) <- NULL
  return(bandThresholds)
}

connectDb <- function() {
    require(RJDBC)
    connParms <- read_json("AML_db2_connection.json")
    jcc = JDBC(connParms$driverClass,connParms$driverJar)
    conn = dbConnect(jcc,connParms$dbUrl,connParms$dbUser,decodeValue(connParms$dbPassword))
    return(conn)
}

decodeValue <- function(ev) {
  require(base64enc)
  return(rawToChar(base64decode(ev)))
}

initializeReasonTypes <- function(conn) {
    rs = dbSendQuery(conn, "select REASON_TYPE_ID, NAME from REASON_TYPE")
    reasontypedf = fetch(rs, -1)
    return(reasontypedf)
}

getReasonTypeID <- function(reasontypedf,name) {
   rt = as.integer(0)
   if ( !is.null(reasontypedf) ) {
      for (i in 1:nrow(reasontypedf)) {
          if (name == reasontypedf$NAME[i]) {
            rt = reasontypedf$REASON_TYPE_ID[i]
          }
      }
   }
   return(rt)
}
