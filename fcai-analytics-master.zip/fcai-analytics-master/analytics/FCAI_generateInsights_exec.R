# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list=ls())
source("AML_utils.R")

sc <- sparkConnect()

readAnalyticConfig(reset=TRUE)
args = commandArgs(trailingOnly=TRUE)
applyCommandLineFileArg("Alerts", args)
applyCommandLineFileArg("JoinedAlerts", args)

source("AML_generateInsights.R")
alerts <- tbl_df(loadData("Alerts"))
insights <- generateInsights(alerts)

if (!is.null(insights)) {
  insightIDs <- unique(insights$insight_id)

  if (length(insightIDs) > 0) {
    for (i in 1:length(insightIDs)) {
      message(createDataHeader(insightIDs[i]))
      tempData <- insights %>% filter(insight_id==insightIDs[i])
      print(as.data.frame(tempData), width=Inf)
      message()
    }
  } else {
    message("No insights were generated")
  }
} else {
  message("No insights were generated")
}
