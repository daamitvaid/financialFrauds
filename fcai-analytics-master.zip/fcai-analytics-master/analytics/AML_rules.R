# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

library(magrittr)
library(jsonlite)
library(dplyr)

roundDollar <- function(x, aggregateBy, aggregateByTime, tenderTypeCol, amountCol, ruleThresholds) {
  filterCriteria = paste(tenderTypeCol,"%in% ruleThresholds$TenderType")
  summV1 <- c(paste("sum(abs(",amountCol,"))",sep=""),
    "n()",
    paste("sum(ifelse(",amountCol,"!=0 & round(",amountCol,"/1000)==",amountCol,"/1000,",amountCol,",0))",sep=""),
    paste("sum(ifelse(",amountCol,"!=0 & round(",amountCol,"/1000)==",amountCol,"/1000,1,0))",sep=""),
    paste("max(abs(",amountCol,"))",sep=""))
  namesV1 <- c("TotalAmount","TotalCount","RoundAmount","RoundCount","MaxAmount")

  x %>%
  filter_(.dots = filterCriteria) %>%
  group_by_(aggregateBy, aggregateByTime) %>%
  summarize_(.dots = setNames(summV1,namesV1)) %>%
  filter(MaxAmount>=ruleThresholds$MinSingleTxAmt & RoundCount>=1 & (RoundCount/TotalCount>ruleThresholds$MinPercentRDTx))
}
