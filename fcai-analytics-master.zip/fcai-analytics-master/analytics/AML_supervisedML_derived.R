# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list = ls())

source("AML_univariate.R")

library(randomForest)
library(caret)
library(mlbench)
#write.csv(byCustomerID, file="AML_aggregate_customerID.csv")

rdsdt <- byCustomerID[ , colSums(is.na(byCustomerID)) == 0]

#for testing purpose, just use Score as target
#create 80-20/training-validation split
score_training <- createDataPartition(rdsdt$Score, p =0.8, list=FALSE)
validation <- rdsdt[-score_training,]
newtest <- rdsdt[score_training,]

#set training parm
u_control<- trainControl(method='cv', number = 10)
u_metric <- "Accuracy"


# Random Forest
set.seed(7)
fit.rf <- train(Score~., data=newtest, method="rf", trControl=u_control)

#summarize accuracy of models
#u_results <- resamples(list(lda=fit.lda, cart=fit.cart, knn=fit.knn, svm=fit.svm, rf=fit.rf))

# estimate skill of LDA on the validation dataset
predictions <- predict(fit.rf, validation)
confusionMatrix(predictions, validation$Score)

u_validation<- cbind(validation,predictions)

 save(fit.rf, file = "AML_rfmodel.rda")
 
## recall later
# load("AML_rfmodel.rda")
# predictions <- predict(fit.rf, newdata)
