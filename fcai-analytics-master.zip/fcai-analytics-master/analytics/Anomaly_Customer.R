# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

#rm(list = ls())
#library(outliers)
source("AML_aggregate1_main.R")

#drop customer_id and 3 last variables for now because they have a lot of missing values
df<-byCustomerID[c(-1,-61,-60,-59)]

#converting variables to numeric and then converting the data to data frame
df<-apply(df, 2, function(x)as.numeric(x))
df<-as.data.frame(df)

#calculate Euc distances from the mean for all columns in data frame
df_distance<-apply(df, 2, function(x)round((x-mean(x)),2))

#calculate the L2 norm
df$l2norm<- apply(df_distance, 1, function(x)round({sqrt(sum(x^2))},2))

#check distribution of l2norm
#hist(df$l2norm)

#normalising l2 norm
df$l2norm<- round(log(df$l2norm),2)
#hist(df$l2norm)

byCustomerID$anomalydist <- df$l2norm

byCustomerID$anomaly<-ifelse(df$l2norm>{mean(df$l2norm)+2*sd(df$l2norm)} 
                   | df$l2norm<{mean(df$l2norm)-2*sd(df$l2norm)}
                   ,1,0)

#write.csv(byCustomerID, file="anomaly_customer.csv") 
rm(df_distance,df)

testdata <- select(byCustomerID, CustomerID, anomalydist)
testdata <- data.frame(testdata)

names(testdata) <- c("KeyID", "score")
testdata$peer <- 1  

#convert anomalydist to score, add newscore to testdata
source("AML_anomaly_risk.R")

#add anomaly score to TXN data
#source("AML_aggregate1.R")
dtData <- readAMLTxData()

#names(dtData)
## [1] "RecordID"        "CustomerID"      "TransID"         "TransDate"       "CounterCountry" 
## [6] "Amount"          "TenderType"      "CustomerCountry" "OriginatorID"    "BeneficiaryID"  
##[11] "Timestamp"       "Day"             "Year"            "Month"           "Week"           
##[16] "Quarter" 

names(testdata)[names(testdata) == 'KeyID'] <- 'CustomerID' 
dtData <- merge(x = dtData, y = testdata, by = "CustomerID", all.x = TRUE)
names(dtData)[names(dtData) == 'newscore'] <- 'AnomalyScore' 


