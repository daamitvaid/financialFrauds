# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
source("FCAI_Clustering_common.R")

generateClusters <- function(parms, dfData) {
  flatparms <- unlist(parms)
  message(paste0("Generating clusters for reason type \"",flatparms["Results.ReasonType"],"\""))
  if (parms$InputSource$SourceType != "Aggregate") {
    stop("FCAI_AnomalyClustering generateClusters can only be executed with an InputSource.SourceType of Aggregate")
  }

  # copy target data to test
  message('Loading target data')
  dfDataIDCol <- colnames(dfData)[[1]]
  test <- dfData

  message('Restoring training data from file.')
  trainingData <- collect(readInput(getAnomalyClusterFileName(parms,"train","csv"),
    type="csv", path=AMLAnalyticConfig$DataDirectory))

  trainingIDs <- subset(trainingData,select=c(dfDataIDCol)) %>%
    mutate_(.dots=setNames(paste0("as.character(",dfDataIDCol,")"),dfDataIDCol))
  targetIDs <- subset(test,select=c(dfDataIDCol)) %>%
    mutate_(.dots=setNames(paste0("as.character(",dfDataIDCol,")"),dfDataIDCol))
  commonIDs <- intersect(trainingIDs, targetIDs)
  trainingOnlyIDs <- setdiff(trainingIDs, commonIDs)

  # remove items from the target that were included in the training data
  filterCriteria = paste0("!",dfDataIDCol," %in% commonIDs$",dfDataIDCol)
  test %<>% filter_(.dots = filterCriteria) %>% compute()

  #Part 4
  test$cluster <- NULL # clear this column just in case

  #weight from univariate
  VarGII <- data.frame(loadData(parms$InputSource$Type,
    parms$InputSource$AggregateName, GII=TRUE), stringsAsFactors=FALSE)

  #removing cluster variable from the data
  message('Restoring "nonCorrelatedData" from file.')
  # at this point, nonCorrelatedData is expected to have a IDColumn
  nonCorrelatedData <- collect(readInput(getAnomalyClusterFileName(parms,
    "nonCorrelatedData","csv"),
    type="csv", path=AMLAnalyticConfig$DataDirectory))
  df1<-as.data.frame(subset(nonCorrelatedData,select=-c(cluster)))

  #we will keep only the variables preselected in the clustering
  data_for_testing<- test[,names(df1)]
  data_for_training<-trainingData[,names(df1)]

  #we are binding together the data we will need, as we need to normalise together
  #before we assign labels to test
  normal<-rbind(data_for_testing,data_for_training)
  rm(data_for_testing,data_for_training)

  #replace the missing values with averages
  normal <- doNAaggregate(normal)

  #creating row.names out of id
  row.names(normal)<-as.character(normal[[dfDataIDCol]])

  #remove id
  normal[[dfDataIDCol]]<-NULL

  #converting the rest of variables to numeric
  normal<- as.data.frame(apply(normal,2,function(x)as.numeric(x)), row.names = rownames(normal))

  #standardize the fields (test and train together)
  normal <- as.data.frame(round(scale(normal),2))

  #bring back id to the table
  setDT(normal, keep.rownames = TRUE)[]
  names(normal)[names(normal) == 'rn'] <- dfDataIDCol

  #now we need to split back to test and train
  #first we extract the train data
  #we selecting all ids from df table (from initial clustering)
  train<-as.data.frame(subset(nonCorrelatedData,select=c(dfDataIDCol)))
  #then we merge with the normalised table we have created ie normal
  train<-merge(train,normal,by=dfDataIDCol, all.x=TRUE)
  #then we bring back from df cluster
  train <- merge(train, nonCorrelatedData[,which(names(nonCorrelatedData) %in% c("cluster",dfDataIDCol))],
                 by=dfDataIDCol,all.x = TRUE )

  #now we are preparing the test data
  #first we extracting id
  test1<-as.data.frame(subset(test,select=c(dfDataIDCol)))
  #then we are merging to ids all the normalised values we calculated
  test1<-merge(test1,normal, by=dfDataIDCol, all.x=TRUE)

  #we are setting id as row.names and deleting cust id as variable
  #for bost test and train
  row.names(train)<-as.character(train[[dfDataIDCol]])
  train[[dfDataIDCol]]<-NULL

  row.names(test1)<-as.character(test1[[dfDataIDCol]])
  test1[[dfDataIDCol]]<-NULL

  #we predicting the labels for test
  #pred <- knn(train = subset(train, select=c(1:7)), test = test1, cl = train$cluster, k=res$Best.nc[1])
  readInput(getAnomalyClusterFileName(parms,"model","rda"),
      type="rda", path=AMLAnalyticConfig$ModelDirectory)
  pred <- knn(train = train[,-which(names(train) %in% c("cluster"))],
                             test = test1, cl = train$cluster, k=res$Best.nc[1])

  test$cluster<-as.numeric(pred)

  #bring back id to the table
  #setDT(test1, keep.rownames = TRUE)[]
  #names(test1)[names(test1) == 'rn'] <- dfDataIDCol

  rm(test1,train,normal,pred)
  rm(res, envir = .GlobalEnv)

  #Part 5
  trainingData<-trainingData[,-which(names(trainingData) %in% c("AnomalyIndex",
    "Anomaly", "First_Contributor", "Second_Contributor", "Third_Contributor",
    "FirstContReason", "SecondContReason", "ThirdContReason"))]
  trainingData<-rbind(trainingData, test)
  rm(test)

  trainingData<-as.data.frame(trainingData)

  df1<-trainingData[,names(nonCorrelatedData)]
  rm(nonCorrelatedData)

  #fill missing value with average
  df1 <- doNAaggregate(df1)

  ##########anomaly detection on entity level #########################

  df1$cluster <- as.factor(df1$cluster)

  #looping through the clusters to calculate each entity's distance from the cluster mean
  #then calculating l2 norm (anomaly index)
  #finally creating a tag which defines whether a entity is anomalous within the
  df_anomaly <- data.frame()
  for (i in levels(df1$cluster)) {

    if (nrow(df1[df1$cluster == i,]) >= 2) {

      x <- df1[df1$cluster == i, -which(names(df1) %in% c(dfDataIDCol,"cluster"))]
      # New line:
      x_custID <- df1[df1$cluster == i, dfDataIDCol, drop = FALSE]
      #dat works fine - double checked
      #dat <- as.data.frame(apply(x, 2, function(x) {round(x-mean(x), 2)}))
      dat <- (as.data.frame(apply(x, 2, function(x) round((x-mean(x))/sd(x), 2))))
      #calculate the L2 norm
      dat$l2norm <- apply(dat, 1, function(x)round(sqrt(sum(x^2)),2))
      #normalising l2 norm
      dat$Anomaly <- ifelse(dat$l2norm > mean(dat$l2norm) + 2*sd(dat$l2norm), 1, 0)

      dat$cluster <-  rep(i, dim(dat)[1])
      # New line:
      dat[[dfDataIDCol]] <- x_custID[[dfDataIDCol]]
    } else {
      dat <- df1[df1$cluster == i,]
      dat$l2norm <- 1000
      dat$Anomaly <- rep(1, nrow(dat))
    }
    df_anomaly <- rbind(df_anomaly, dat)
    rm(dat)
  }
  rm(df1)

  #df_anomaly<-df_anomaly[,-which(names(df_anomaly) %in% c("AnomalyIndex"))]
  names(df_anomaly)[names(df_anomaly) == 'l2norm'] <- 'AnomalyIndex'

  #merging back to training table
  trainingData <- merge(trainingData, df_anomaly[,which(names(df_anomaly) %in% c("Anomaly","AnomalyIndex",dfDataIDCol))],
                        by=dfDataIDCol,all.x = TRUE )

  ###############factor sensitivity analysis###################

  #creating index out of entity id and getting rid of entity id as a result
  #we need to get rid of entity id to get df_rank but we need to keep track of it when we will merge by to dfData
  row.names(df_anomaly)<-as.character(df_anomaly[[dfDataIDCol]])
  df_anomaly[[dfDataIDCol]]<-NULL

  #we subset the data now into people who are anomalous and who are not
  #we deal with them separately
  df_rank_anomaly<-subset(df_anomaly,Anomaly == 1)
  df_rank_nonanomaly<-subset(df_anomaly,Anomaly == 0)
  rm(df_anomaly)

  #we getting rid of variables we do not need
  df_rank_anomaly<-df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("AnomalyIndex","Anomaly","cluster"))]
  df_rank_nonanomaly<-df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("AnomalyIndex","Anomaly","cluster"))]

  #we create new tables as these will be used for defining contributor reasons
  #we do it that way because for contributors reasons we need real data
  #for contributors themselves we will be looking at absolute values
  df_ano_reasons<-df_rank_anomaly
  df_nonano_reasons<-df_rank_nonanomaly

  #looking at REASONS FOR CONTRIBUTORS in anomaly data
  #we define reasons as the values which are the furthest away from the mean
  df_ano_reasons$FirstContReason<-apply(df_ano_reasons, 1,function(x) { x[which.max( abs(x) )]})

  df_ano_reasons$SecondContReason<-apply(df_ano_reasons[,-which(names(df_ano_reasons) %in% c("FirstContReason"))],1
                                         ,function(x) {x[which(rev(sort(abs(x)))[2] == abs(x))][1]})

  df_ano_reasons$ThirdContReason<-apply(df_ano_reasons[,-which(names(df_ano_reasons) %in% c("FirstContReason","SecondContReason"))],1
                                        ,function(x) {x[which(rev(sort(abs(x)))[3] == abs(x))][1]})


  #looking at reasons for contributors in nonanomaly data
  #we define contributors reasons as values the closest to the mean
  df_nonano_reasons$FirstContReason<-apply(df_nonano_reasons, 1, function(x){ x[which.min( abs(x) )]})

  df_nonano_reasons$SecondContReason <- apply(df_nonano_reasons[,-which(names(df_nonano_reasons) %in%
                                                                          c("FirstContReason"))], 1,
                                              function(x) {x[which(sort(unique(abs(x)))[2] == abs(x))][1]})

  df_nonano_reasons$ThirdContReason <- apply(df_nonano_reasons[,-which(names(df_nonano_reasons) %in%
                                                                         c("FirstContReason", "SecondContReason"))], 1,
                                             function(x) {x[which(sort(unique(abs(x)))[3] == abs(x))][1]})


  #combined reasons for anomaly and non anomaly into one table
  df_reasons<-rbind(df_nonano_reasons,df_ano_reasons)
  df_reasons<-df_reasons[,which(names(df_nonano_reasons) %in%
                                  c("FirstContReason","SecondContReason","ThirdContReason",dfDataIDCol))]

  #get entity ids from row names
  setDT(df_reasons, keep.rownames = TRUE)[]
  names(df_reasons)[names(df_reasons) == 'rn'] <- dfDataIDCol

  #get rid of redundant tables
  rm(df_nonano_reasons,df_ano_reasons)

  #NOW WE WILL BE GENERATING 3 CONTRIBUTORS
  #convert values to absolute values
  df_rank_anomaly<-abs(df_rank_anomaly)
  df_rank_nonanomaly<-abs(df_rank_nonanomaly)

  #creating a data which ranks the columns
  df_rank_anomaly<-as.data.frame(t(apply(df_rank_anomaly,1,function(x)rank(-x, ties.method = "first"))))
  df_rank_nonanomaly<-as.data.frame(t(apply(df_rank_nonanomaly,1,function(x)rank(x, ties.method = "first"))))

  #creating new columns for top 3 first contributors to anomaly/NONANOMALY
  df_rank_anomaly$First_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly, 1, function(x)which(x==1))]
  df_rank_anomaly$Second_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("First_Contributor"))], 1, function(x)which(x==2))]
  df_rank_anomaly$Third_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("First_Contributor","Second_Contributor"))], 1, function(x)which(x==3))]

  df_rank_nonanomaly$First_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly, 1, function(x)which(x==1))]
  df_rank_nonanomaly$Second_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("First_Contributor"))], 1, function(x)which(x==2))]
  df_rank_nonanomaly$Third_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("First_Contributor","Second_Contributor"))], 1, function(x)which(x==3))]

  #Combining both tabes together
  df_rank<-rbind(df_rank_nonanomaly,df_rank_anomaly)

  #bring back entity id to the df_rank
  setDT(df_rank, keep.rownames = TRUE)[]
  names(df_rank)[names(df_rank) == 'rn'] <- dfDataIDCol

  #df_rank changing back to data frame
  df_rank<-as.data.frame(df_rank)

  #merging back to reasons
  df_rank_reasons<-merge(df_rank, df_reasons, by=dfDataIDCol,all.x = TRUE)

  #merging back to training table
  trainingData <- merge(trainingData, df_rank_reasons[,which(names(df_rank_reasons) %in% c("First_Contributor", "Second_Contributor","Third_Contributor",dfDataIDCol,
                                                                                           "FirstContReason","SecondContReason","ThirdContReason"))], by=dfDataIDCol,all.x = TRUE )

  rm(df_rank_anomaly,df_rank_nonanomaly,df_rank,df_rank_reasons,df_reasons)

  testdata <- select(trainingData, dfDataIDCol, AnomalyIndex, cluster)
  testdata <- data.frame(testdata)

  names(testdata) <- c("KeyID", "score", "peer")

  #convert anomalydist to score, add newscore to testdata
  #calculate risk score based on different peer group
  testout <- ddply(testdata, c("peer"), summarise,
             N    = length(score),
             meanvar = mean(score),
             medianvar = median(score),
             stdvar   = sd(score)
             )

  bypeer_univar <- merge(x = testdata, y = testout, by = "peer", all.x = TRUE)
  rm(testout)

  #calculate score ## note the "peer" got moved to column 1 so variable start with i+1
  newscore <- 1000/(1+exp(-0.5*((bypeer_univar[["score"]]-(bypeer_univar$medianvar+bypeer_univar$stdvar))*10/((bypeer_univar$medianvar+3*bypeer_univar$stdvar)-(bypeer_univar$medianvar+bypeer_univar$stdvar)))))
  newscore[is.na(newscore)] <- 1

  newcol_ext <- cbind(bypeer_univar, newscore)
  rm(bypeer_univar,newscore)
  newcol_ext[c("newscore")][which(newcol_ext$N <=3),] <- max(newcol_ext$newscore)
  newcol_ext <- subset(newcol_ext, select = c(KeyID, newscore))
  colnames(newcol_ext) <- c("KeyID",parms$Results$ScoreColumn)

  trainingData <- merge(x = trainingData, y = newcol_ext, by.x=dfDataIDCol,by.y="KeyID", all.x = TRUE)
  rm(newcol_ext,testdata)

  # remove rows that only exist in the training data
  if (nrow(trainingOnlyIDs) > 0) {
    filterCriteria = paste0("!",dfDataIDCol," %in% trainingOnlyIDs$",dfDataIDCol)
    trainingData %<>% filter_(.dots = filterCriteria)
  }

  return(trainingData)
}

calculateScoringBands <- function(parms) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scoring bands for reason type \"",flatparms["Results.ReasonType"],"\""))
  if (parms$InputSource$SourceType != "Aggregate") {
    stop("FCAI_AnomalyClustering calculateScoringBands can only be executed with an InputSource.SourceType of Aggregate")
  }

  dfData <- tbl_df(loadAnalyticInput(parms$InputSource))

  scoredData <- generateClusters(parms, dfData)
  if (isDebug(parms)) {
    message(createDataHeader("scored data"))
    print(head(scoredData))
  }
  writeBandThresholds(scoredData[[parms$Results$ScoreColumn]], flatparms["Results.ReasonType"])
}

calculateScores <- function(parms, dfData) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scores for reason type \"",
    flatparms["Results.ReasonType"],"\""))

  if (parms$InputSource$SourceType != "Aggregate") {
    stop("FCAI_AnomalyClustering calculateScores can only be executed with an InputSource.SourceType of Aggregate")
  }

  dfDataIDCol <- colnames(dfData)[[1]]

  scoredData <- generateClusters(parms, dfData)
  scoredData$AnomalyINSGR1 <- "None"
  scoredData$AnomalyINSGS1 <- 0
  scoredData$AnomalyINSGR2 <- "None"
  scoredData$AnomalyINSGS2 <- 0
  #for (i in 1:(nrow(scoredData)))  {
  for (i in 1:(nrow(scoredData))) {
    if (!is.na(scoredData$First_Contributor[i])) {
      colnum1 <- which(colnames(scoredData) == scoredData$First_Contributor[i])
      scoredData$AnomalyINSGR1[i] <- scoredData$First_Contributor[i]
      scoredData$AnomalyINSGS1[i] <- round(scoredData[i,colnum1],2)
      if (!is.na(scoredData$Second_Contributor[i])) {
        colnum2 <- which(colnames(scoredData) == scoredData$Second_Contributor[i])
        scoredData$AnomalyINSGR2[i] <- scoredData$Second_Contributor[i]
        scoredData$AnomalyINSGS2[i] <- round(scoredData[i,colnum2],2)
      }
    } else {
      # no contributors, reset the score to 0
      scoredData[i,parms$Results$ScoreColumn] <- 0
    }
  }

  Anomaly_INSG <- copy_to(sc, select(scoredData, dfDataIDCol,
    parms$Results$ScoreColumn, AnomalyINSGR1, AnomalyINSGS1,
    AnomalyINSGR2, AnomalyINSGS2,), "AnomalyINSG", overwrite = TRUE)
  Anomaly_INSG <- Anomaly_INSG %>% mutate(AnomalyINSG = paste('{"',AnomalyINSGR1,'":', round(AnomalyINSGS1,2L),
    ',"',AnomalyINSGR2,'":',round(AnomalyINSGS2,2L),'}',sep=""))
  Anomaly_INSG <- select(Anomaly_INSG, dfDataIDCol,
    parms$Results$ScoreColumn, AnomalyINSG)

  return(Anomaly_INSG)
}

getModelArtifacts <- function(parms) {

  # nbclust model
  modelFileName <- getAnomalyClusterFileName(parms,"model","rda")
  readInput(modelFileName, type="rda", path=AMLAnalyticConfig$ModelDirectory)
  artifactName <- paste("res",parms$Results$ReasonType,sep="_")
  artifactLabel <- paste0(artifactName," (NBClust Model, ReasonType: ",parms$Results$ReasonType,")")
  assign(artifactName, res, envir = .GlobalEnv)

  labels <- c(artifactLabel)
  names(labels) <- c(artifactName)

  return(labels)
}

generateAnomalyInsight <- function(parms, scoredTx) {
  partyIdCol <- getAggregateByColumnNames(parms$InputSource$Type,parms$InputSource$AggregateName)
  results <- scoredTx %>% select(parms$Results$ScoreColumn,parms$Results$InsightColumn,partyIdCol) %>% distinct()
  colnames(results) <- c("score","insight","partyId")
  results$related_txn <- NA
  results$variables <- NA
  results$insight_id <- 3
  results %<>% mutate(band=ifelse(score>500,AML_highValue,AML_lowValue))
  results$related_cntrparties <- NA
  results$related_alerts <- NA

  #Initiate a list to hold relevant variables
  descrip_list <- list(list())
  for (i in 1:nrow(results)) {
    descrip_list[[1]]$reasonType <- parms$Results$ReasonType
    descrip_list[[1]]$partyId <- results$partyId
    if (results$score[i] > 500) {
      insightJson <- fromJSON(results$insight[i])
      descrip_list[[1]]$topReasons <- paste0(names(insightJson),collapse=",")
    }
    results$variables[i] <- descrip_list
  }
  results$insight <- NULL
  results$partyId <- NULL
  return(results)
}
