# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

#Author: Karolina Dufour-Kruszewska kkruszew@uk.ibm.com

library("RANN")
library("magrittr")
source("AML_utils.R")
source("AML_aggregate1.R")

#<<<<<<<<<<<<<<<<<<<<<<<Acquiring info from Config file<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#get the analytic configuration from the config file
readAnalyticConfig(reset=TRUE)

#open a spark connection
sc <- sparkConnect()

#save the entire "Analytics" block
allAnalytics <- AMLAnalyticConfig$Analytics

for (i in 1:length(allAnalytics)) { #step through each analytic looking for PeerGroup...
  if (allAnalytics[[i]]$Type == "PeerGroup") { #If a PeerGroup block is found...
    parms <- unlist(allAnalytics[[i]])
    
    #Save the PeerGroup block
    peerGroupConfig <- allAnalytics[[i]]
    
    #Acquire the input dataframe
    byCustomerID <- tbl_df(loadAnalyticInput(allAnalytics[[i]]$InputSource))
    
    customerIDColumn <- getColumnNames(peerGroupConfig$InputSource$Type, "CustomerIDColumn")
  }
}

#<<<<<<<<<<<<<<<<<<<<<Manipulating customer dataframe for pre-binning segmentation<<<<<<
#This block is for when the customer wants to segment based on data that is not currently contained in 
#the "InputSource" dataframe, and must be acquired from elsewhere.

if (!is.null(peerGroupConfig$JoinFeatures)) #If there is a "JoinFeatures" block in the PeerGroup config...
{
  #Determine the column to join upon inside the InputSource (should be a customer ID based aggregation)
  targetJoinBy <- getColumnNames(peerGroupConfig$InputSource$Type, peerGroupConfig$JoinFeatures[[1]]$InputSourceJoin)
  
  #Call copyExternalColumn, which takes the JoinFeatures group as input and compiles whatever external data
  #the customer wants to segment on (party type, country, etc)
  toAdd <- tbl_df(copyExternalColumn(peerGroupConfig$JoinFeatures[[1]], targetJoinBy))
  
  #Add the compiled segment data to the InputSource data by the join column determine earlier in targetJoinBy
  byCustomerID <- merge(x = byCustomerID, y = toAdd, by = targetJoinBy)
  
  #Clean up
  rm(toAdd)
}


#<<<<<<<<<<<<<<<<<<Segmentation of customers before binning<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#Create an empty dataframe to hold customer IDs
segmentedIDs <- NULL

if (!is.null(peerGroupConfig$SegmentColumn)) #If there is a "SegmentColumn" object, for segmentation prior to binning...
{
  #grab the name of the column to segment on (should be the name of the column created when adding external data to the input source)
  segmentColumn <- peerGroupConfig$SegmentColumn

  
  if (!is.null(byCustomerID[[segmentColumn]])) #If the segment column is actually a column in the InputSource data...
  {
    #determine how many unique values there are to segment the data (for example, number of different countries...)
    uniqueValues <- table(byCustomerID[[segmentColumn]])
    
    segmentedIDs <- vector("list", length(uniqueValues))
    
    for(i in 1:length(uniqueValues)) #for the number of unique values to segment the data (such as unique number of countries)...
    {
      #Save the customerIDs for the current unique segmentation value (such as a specific country) into a separate row
      segmentedIDs[[i]] <- byCustomerID[[customerIDColumn]][which(byCustomerID[[segmentColumn]] == dimnames(uniqueValues)[[1]][i])]
    }
  } else #If the segment column is not in the InputSource data, alert the user and proceed without segmenting.
        {
          #save the customer IDs as one group
          segmentedIDs[[1]] <- byCustomerID[[customerIDColumn]]
          message(paste("The selected SegmentColumn does not exist in the InputSource. Proceeding without segmentation"))
  }
  
} else #If there isn't a "SegmentColumn" object, meaning no segmentation prior to binning...
  {
    #save the customer IDs as one group
    segmentedIDs[[1]] <- byCustomerID[[customerIDColumn]]
  }

#<<<<<<<<<<<<<<<<<<Binning customers<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

if(!is.null(peerGroupConfig$BinningColumns))
{
  #Determine the number of columns to be used in binning (currently can only be three, assuming for R, F, and M)
  numBinningColumns <- length(peerGroupConfig$BinningColumns)
  
  if(numBinningColumns != 3)
  {
    stop("Please choose 3 binning columns and try again.")
  }
  
  #create a new dataframe to hold the binning information
  binDataFrame <- NULL
  
  #Initialize a variable for Peer Group ID
  m = 0 
  
  #Initialize a PeerGroup column in the InputSource
  byCustomerID$PeerGroups <- 0
  
  for (f in 1:length(segmentedIDs)) #For each segmented group of customer IDs...
  {
    #Save the customerIDs to the binning dataframe
    binDataFrame$CustomerID <- segmentedIDs[[f]]
    
    for (g in 1:numBinningColumns) #For the number of columns used for binning (should be 3)
    {
      #Save the name of the column to bin with
      columnName <- peerGroupConfig$BinningColumns[[g]][[1]]
      
      if(is.null(byCustomerID[[columnName]]))
      {
        stop ("One or more binning columns need to be assigned. A customary choice is to use Recency, Frequency, and Monetary data. Please assign binning columns and try again.")
      }
      
      #Create a header for the column that will be added to hold the bin IDs
      columnHeader <- (sprintf("%d_bins", g))
      
      #STOPGAP: Using log() when there are values == 0 doesn't work. Current solution is to do without log in that scenario.
      if (length(byCustomerID[[customerIDColumn]][which(byCustomerID[[columnName]] == 0)]))
      {
        #Automatically determine the number and cut of bins
        breaks <- hist(byCustomerID[[columnName]][byCustomerID[[customerIDColumn]] %in% segmentedIDs[[f]]], plot = FALSE)
      } else{
        #Automatically determine the number and cut of bins
        breaks <- hist(log(byCustomerID[[columnName]][byCustomerID[[customerIDColumn]] %in% segmentedIDs[[f]]]), plot = FALSE)
      }
      
      #Determine the bin labels based on the bin cuts 
      binLabels <- findInterval(log(byCustomerID[[columnName]][byCustomerID[[customerIDColumn]] %in% segmentedIDs[[f]]]), (1:(length(breaks$breaks)-1)), all.inside = TRUE)
      
      #Save the bin labels to the binning dataframe
      binDataFrame[[columnHeader]] <- binLabels
    }
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<FORM PEER GROUPS OUT OF BINS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    #NOTE: The agreed upon minimum size of a peer group is 30 customers. With less than 30 customers, clustering will be affected.
    
    #Initialize data frames to track the customer IDs of peer groups having less or more than 30 customers
    customerIDsGreaterThan30 <- NULL 
    customerIDsLessThan30 <- NULL
    
    for (i in 1:(length(table(binDataFrame[2])))) #For every bin created by the first binning column....
    {
      #Save the customer IDs from the current bin of the first binning column
      column1IDs <- binDataFrame$CustomerID[which(binDataFrame[[2]]==dimnames(table(binDataFrame[2]))[[1]][i])]
      
      for (j in 1:(length(table(binDataFrame[3])))) #For every bin created by the second binning column....
      { 
        #Save the customer IDs from the current bin of the second binning column
        column2IDs <- binDataFrame$CustomerID[which(binDataFrame[[3]]==dimnames(table(binDataFrame[3]))[[1]][j])]
        
        for (k in 1:(length(table(binDataFrame[4])))) #For every bin created by the third binning column....
        {
          #Save the customer IDs from the current bin of the third binning column
          column3IDs <- binDataFrame$CustomerID[which(binDataFrame[[4]]==dimnames(table(binDataFrame[4]))[[1]][k])]
          
          #Determine which customer IDs are common to all three bins currently selected
          intersection <- intersect(intersect(column1IDs, column2IDs), intersect(column2IDs, column3IDs))
          
          if (length(intersection) > 0 ) #If customer IDs common to all three current bins exist...
          {
            
            #Create a variable that contains the intersection of the customer IDs for this specific bin combination
            #assign(sprintf("peer_group_intersect_rec%d_freq%d_mon%d", i, j, k), intersection)
            
            #Increase the peer group ID
            m = m + 1
            
            if (length(intersection) < 30) #If the number of common customer IDs is less than 30...
            {
              #Save the customer IDs so that they can be redistrubted later
              customerIDsLessThan30 <- c(customerIDsLessThan30, intersection)
              
            }else #If the number of common customer IDs is greater than 30...
            {
              #Save the customer IDs to be used in nearest-neighbor calculations
              customerIDsGreaterThan30 <- c(customerIDsGreaterThan30, intersection)
            }
            
            #Assign the peer group ID to the correct customer ID for the current unique segmentation
            binDataFrame$PeerGroups[binDataFrame$CustomerID %in% intersection] <- m
            
            
          }
        }
      }
    }
    
    if(length(customerIDsGreaterThan30) <=0)
    {
      stop("The chosen segmentation/binning columns have resulted in extremely poor peer group performance. Please
           re-assess the columns chosen for binning/segmentation and try again.")
    }
    #<<<<<<<<If there are any peer groups with less than 30 customers, distribute the customers to the other peer groups using nearest-neighbor<<<<<<<<<<<
    #Initialize new dataframes to hold RFM information
    RFMOver30Customers <- NULL
    RFMUnder30Customers <- NULL
    
    if (length(customerIDsLessThan30) > 0) #If there are any groups that have less than 30 customers...
    {
      for (j in 1:numBinningColumns) #Go through each binning column and save the binning column data for each group of <30 and >30 customers
      {
        #Determine the name of the current binning column
        columnName <- peerGroupConfig$BinningColumns[[j]][[1]]
        
        #Save the current binning column data of each group of <30 and >30 customers
        RFMOver30Customers[[names(peerGroupConfig$BinningColumns[[j]])]] <- byCustomerID[[columnName]][byCustomerID[[customerIDColumn]] %in% customerIDsGreaterThan30]
        RFMUnder30Customers[[names(peerGroupConfig$BinningColumns[[j]])]] <- byCustomerID[[columnName]][byCustomerID[[customerIDColumn]] %in% customerIDsLessThan30]
      }
      
      for (i in 1:length(customerIDsLessThan30)) #Go through each customer ID from peer groups of less than 30...
      {
        #Determine the index of nearest-neighbor of the <30 customer ID contained within the >30 customerID groups
        index <- nn2(as.data.frame(RFMOver30Customers),as.data.frame(RFMUnder30Customers)[i,], k = 1)
        
        #Extract the peer group of the >30 customer that was determined to be the nearest neighbor
        peergroup <- binDataFrame$PeerGroups[binDataFrame$CustomerID %in% customerIDsGreaterThan30[index$nn.idx[[1]]]]
        
        #Reassign the peer group ID of the <30 customer to that of the nearest-neighbor's peer group
        binDataFrame$PeerGroups[binDataFrame$CustomerID %in% customerIDsLessThan30[i]] <- peergroup
      }
    }
    
    #Save the peer group ID to the overall byCustomerID dataframe (used later for results and output)
    byCustomerID$PeerGroups[byCustomerID[[customerIDColumn]] %in% binDataFrame$CustomerID] <-binDataFrame$PeerGroups
    
    #Reset the dataframes for the next segmentation group
    customerIDsGreaterThan30 <- NULL 
    customerIDsLessThan30 <- NULL
    
  } ##End of using segmentation constraints
  
  #<<<<<<<<<<<<<<<<<<<<<Clean up the PeerGroup IDs<<<<<<<<<<<<<<<<<<<<<<<
  #The peer group IDs get rather shuffled during the assignment process, so this just reassigns them to be 1, 2, 3... 
  #and so on
  
  #Save an array of the existing unique PeerGroup IDs
  uniquePeerGroupIDs <- table(byCustomerID$PeerGroups)
  
  #Save the number of existing unique PeerGroupIDs
  numPeerGroups <- length(uniquePeerGroupIDs)
  
  for (i in 1:numPeerGroups) #for the number of existing unique PeerGroup IDs...
  {
    #Save the ID of the current peer group
    currentPeerGroupID <- dimnames(uniquePeerGroupIDs)[[1]][i]
    
    #Reassign the current peer group ID to the index of that current peer group ID
    byCustomerID$PeerGroups[byCustomerID$PeerGroups %in% currentPeerGroupID] <- i
  }
  
  
  #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Save to .csv<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  
  if (!is.null(byCustomerID[[segmentColumn]])) #If the segment column is actually a column in the InputSource data...
  {
    columns <- c(customerIDColumn, "PeerGroups")
  }
  else
  {
    columns <- c(customerIDColumn, "PeerGroups", segmentColumn)
  }
  results <- select_(byCustomerID, .dots=columns)
  resultsSpark <- copy_to(sc, results, name = "resultsSpark")
  
  output <- peerGroupConfig$StoredAs
  if (!is.null(output))
  {
    if (output$Debug) 
    {
      print(resultsSpark, width=Inf)
    }
    
    if (!is.null(output$Name)) {
      storeOutput(resultsSpark, output$Name, path=output$Path, type=output$Type);
    }
  }
}else{
  stop("Please select binning columns. A customary choice is to use Recency, Frequency, and Monetary data.")
}


#<<<<<<<<<<<<<<EVALUATING THE PEER GROUPS<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

