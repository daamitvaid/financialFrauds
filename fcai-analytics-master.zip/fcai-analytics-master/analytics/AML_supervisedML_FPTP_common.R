# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

source("AML_utils.R")
library(randomForest)
library(caret)
library(mlbench)

getSupervisedMLModelFileName <- function(parms, contains) {
  paste0("FCAI_SupervisedML_",parms$Results$ReasonType,"_",contains,".rda")
}

getSupervisedMLValidationFileName <- function(parms, contains) {
  paste0("FCAI_SupervisedML_",parms$Results$ReasonType,"_",contains,".csv")
}

processInputSources <- function(parms, dtData = NULL) {
  inputSource <- NULL
  for (i in 1:length(parms$InputSource)) {
    if (!is.null(dtData) && parms$InputSource[[i]]$SourceType == "File" && parms$InputSource[[i]]$Type == "Transactions") {
      if (!is.null(parms$InputSource[[i]]$Columns) && !is.na(parms$InputSource[[i]]$Columns) && length(parms$InputSource[[i]]$Columns) > 0) {
        columns <- getColumnNames(parms$InputSource[[i]]$Type,parms$InputSource[[i]]$Columns)
        dtData <- select(dtData,columns)
      }
      if (isDebug(parms)) {
        message(createSourceHeader(parms$InputSource[[i]]))
        print(head(dtData))
      }
      if (is.null(inputSource)) {
        inputSource <- dtData
      } else {
        byX <- getColumnNames(parms$InputSource[[1]]$Type,
          parms$InputSource[[i]]$JoinColumnsX)
        byY <- getColumnNames(parms$InputSource[[i]]$Type,
          parms$InputSource[[i]]$JoinColumnsY)
        inputSource <- merge(x = inputSource, y = dtData, by.x = byX, by.y = byY, all.x = TRUE)
      }
    } else {
      if (is.null(inputSource)) {
        inputSource <- tbl_df(loadAnalyticInput(parms$InputSource[[i]]))
        if (!is.null(parms$InputSource[[i]]$Columns) && !is.na(parms$InputSource[[i]]$Columns) && length(parms$InputSource[[i]]$Columns) > 0) {
          columns <- getColumnNames(parms$InputSource[[i]]$Type,parms$InputSource[[i]]$Columns)
          inputSource <- select(inputSource,columns)
        }
        if (isDebug(parms)) {
          message(createSourceHeader(parms$InputSource[[i]]))
          print(head(inputSource))
        }
      } else {
        tmp <- tbl_df(loadAnalyticInput(parms$InputSource[[i]]))
        #fill missing value with average
        tmp <- doNAaggregate(tmp)
        if (!is.null(parms$InputSource[[i]]$Columns) && !is.na(parms$InputSource[[i]]$Columns) && length(parms$InputSource[[i]]$Columns) > 0) {
          columns <- getColumnNames(parms$InputSource[[i]]$Type,parms$InputSource[[i]]$Columns)
          tmp <- select(tmp,columns)
        }
        if (isDebug(parms)) {
          message(createSourceHeader(parms$InputSource[[i]]))
          print(head(tmp))
        }
        byX <- getColumnNames(parms$InputSource[[1]]$Type,
          parms$InputSource[[i]]$JoinColumnsX)
        byY <- getColumnNames(parms$InputSource[[i]]$Type,
          parms$InputSource[[i]]$JoinColumnsY)
        inputSource <- merge(x = inputSource, y = tmp, by.x = byX, by.y = byY, all.x = TRUE)
      }
    }
  }
  if (isDebug(parms)) {
    message(createDataHeader("Merged input sources"))
    print(head(inputSource))
  }
  return(inputSource)
}

addCountryRisk <- function(parms, dtData) {
  for (i in 1:length(parms$InputSource)) {
    if (!is.null(parms$InputSource[[i]]$CountryColumns) &&
        length(parms$InputSource[[i]]$CountryColumns) > 0 ) {

      columnNames <- getColumnNames(parms$InputSource[[i]]$Type,
        parms$InputSource[[i]]$CountryColumns)
      if (!exists("countryColumns")) {
        countryColumns <- columnNames
      } else {
        countryColumns <- unique(c(countryColumns,columnNames))
      }
    }
  }
  if (exists("countryColumns") && length(countryColumns) > 0) {
    countries <- as.data.frame(loadData("Countries"))
    countryJoinName <- getColumnName("Countries",
      paste0(AMLAnalyticConfig$CountryType,"Column"))
    countryRiskName <- getColumnName("Countries","RiskScoreColumn")
    for (i in 1:length(countryColumns)) {
      message(paste("Adding country risk scores for",countryColumns[i]))
      riskColumnName <- paste0(countryColumns[i],"_Risk")
      reducedCountries <- select(countries, countryJoinName, countryRiskName)
      colnames(reducedCountries)[2] <- riskColumnName
      dtData <- merge(x=dtData, y=reducedCountries, by.x=countryColumns[i],
        by.y=countryJoinName, all.x=TRUE)
      dtData[[countryColumns[i]]] <- NULL
      dtData[[riskColumnName]][is.na(dtData[[riskColumnName]])] <- max(dtData[[riskColumnName]], na.rm = TRUE)
    }
    return(dtData)
  } else {
    return(dtData)
  }
}
