# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list = ls())
appName <- "FCAI_featureGeneration_exec"
source("AML_utils.R")

sc <- sparkConnect()

readAnalyticConfig(reset=TRUE)
args = commandArgs(trailingOnly=TRUE)

runGenerateGII <- TRUE
source("AML_aggregate1.R")
if (length(args) > 0) {
  testStr <- tolower(args[1])
  if (grepl("=", testStr, fixed=TRUE)) {
    if (startsWith(testStr,"generategii=")) {
      if (endsWith(testStr,"false")) {
        runGenerateGII <- FALSE
        message("Setting runGenerateGII to FALSE")
      }
      if (length(args) > 1) {
        args <- args[2:length(args)]
      } else {
        args <- c()
      }
    } else {
      message(paste("Unrecognized option:", args[1]))
      message(paste("Valid options: generateGII=[TRUE|FALSE]"))
      stop("Rerun with a valid option")
    }
  }
}
if (length(args) > 0) {
  for (i in 1:length(args)) {
    system.time(processFeatures(args[i], runGenerateGII=runGenerateGII))
  }
} else {
  system.time(processFeatures(runGenerateGII=runGenerateGII))
}

if (length(args > 0)) {
  for (i in 1:length(args)) {
    displayFeatures(args[i])
  }
} else {
  displayFeatures()
}
