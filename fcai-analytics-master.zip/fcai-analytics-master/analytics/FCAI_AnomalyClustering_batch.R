# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list = ls())
appName <- "FCAI_AnomalyClustering_batch"
source("FCAI_Clustering_common.R")

sc <- sparkConnect()

readAnalyticConfig(training=TRUE, reset=TRUE)
args = commandArgs(trailingOnly=TRUE)

message("**** In training mode, default Transactions file is in the Training element ****")
applyCommandLineFileArg("Transactions", args)

source("AML_aggregate1.R")
processFeatures()

allAnalytics <- AMLAnalyticConfig$Analytics
for (i in 1:length(allAnalytics)) {
  if (allAnalytics[[i]]$Type == "AnomalyClustering") {
    message(paste0("******* Found AnomalyClustering (index ",i,") - ",allAnalytics[[i]]$Results$ReasonType))
    parms <- unlist(allAnalytics[[i]])
    clusteringConfig <- allAnalytics[[i]]

    source("FCAI_AnomalyClustering_Training.R")
  }
}
