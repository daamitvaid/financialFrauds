# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

source("AML_utils.R")
library(zoo)
library(class)
library(caret)
library(NbClust)
library(data.table)
library(codetools)

storeWithRownames <- function(data, filename, dataName, rowNameColumnName) {
  tempdata <- data
  tempdata[[rowNameColumnName]] <- rownames(tempdata)
  storeOutput(copy_to(sc,tempdata,dataName,overwrite=TRUE),
    name=filename, type="csv",
    path=AMLAnalyticConfig$DataDirectory)
  rm(tempdata)
}

retrieveWithRowNames <- function(fileName, rowNameColumnName) {
  data <- as.data.frame(collect(readInput(fileName, type="csv", path=AMLAnalyticConfig$DataDirectory)))
  row.names(data) <- data[[rowNameColumnName]]
  data[[rowNameColumnName]] <- NULL
  return(data)
}

getAnomalyClusterFileName <- function(parms, contains, type) {
  paste0("FCAI_AnomalyCluster_",parms$Results$ReasonType,"_",contains,".",type)
}
