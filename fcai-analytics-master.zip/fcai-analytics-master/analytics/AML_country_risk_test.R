# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list=ls())
appName <- "FCAI_country_risk_test"
source("AML_utils.R")

sc <- sparkConnect()

readAnalyticConfig(reset=TRUE)
args = commandArgs(trailingOnly=TRUE)
applyCommandLineFileArg("Transactions", args)
AML_scored_alerts_input <- validateScoredAlerts()

readAnalyticConfig(reset=TRUE)

allAnalytics <- AMLAnalyticConfig$Analytics
for (i in 1:length(allAnalytics)) {
  if (allAnalytics[[i]]$Type == "CountryRisk") {
    message(paste0("******* Found CountryRisk (index ",i,") - ",allAnalytics[[i]]$Results$ReasonType))
    parms <- unlist(allAnalytics[[i]])

    source(parms["Source"])

    # execute score banding function
    func <- match.fun(parms["BandingFunction"])
    bands <- func(parms=allAnalytics[[i]])
    print(head(bands), width=Inf)

    # execute assessment function
    func = match.fun(parms["AssessmentFunction"])
    dfData <- loadData("Transactions")
    dfDataIDCol <- getColumnName("Transactions","IDColumn")
    originatorCountryCol <- getColumnName("Transactions", "OriginatorCountryColumn")
    intermediaryCountryCol <- getColumnName("Transactions", "IntermediaryCountryColumn")
    destinationCountryCol <- getColumnName("Transactions", "BeneficiaryCountryColumn")
    dfData %<>% select_(dfDataIDCol,originatorCountryCol,intermediaryCountryCol,
      destinationCountryCol)
    dfData <- dfData %>% arrange_(dfDataIDCol)
    dfData <- tbl_df(dfData)

    message("\n\n***** Running assessment for full dataset *****\n")
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(head(scores %>% arrange_(dfDataIDCol)), width=Inf)

    message("\n\n***** Running assessment for first 100 elements dataset *****\n")
    dfData <- dfData[1:100,]
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(head(scores %>% arrange_(dfDataIDCol)), width=Inf)

    message("\n\n***** Running assessment for first element only *****\n")
    dfData <- dfData[1,]
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(scores, width=Inf)
  }
}
