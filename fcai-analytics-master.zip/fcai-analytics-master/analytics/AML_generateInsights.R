# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

insightResultsCols <- c("alert_ID","related_txn","variables", "insight_id",
  "score", "band", "related_cntrparties", "related_alerts")

generateInsights <- function(alerts, insightType=NA) {
  if (is.na(AMLAnalyticConfig$Insights) || (length(AMLAnalyticConfig$Insights) == 0)) {
    message("No Insights have been configured, skipping insight processing")
    return(NULL)
  }
  message(paste("Length of Insights:",length(AMLAnalyticConfig$Insights)))
  insightResults <- NULL
  for (i in 1:length(AMLAnalyticConfig$Insights)) {
    insightContainer <- AMLAnalyticConfig$Insights[[i]]
    if (is.na(insightType) || (!is.na(insightType) && insightContainer$Type==insightType)) {
      message(paste("Processing Insight ",i,": ",insightContainer$Type))
      parms <- unlist(insightContainer)
      if ("AML_generateInsights.R" != basename(parms["Source"])) {
        source(parms["Source"])
      }
      # execute insight function
      func <- match.fun(parms["InsightFunction"])
      if (!is.null(func)){
        insights <- func(alerts, parms=insightContainer)
        if (is.null(insightResults)) {
          insightResults <- insights
        } else {
          insightResults <- rbind(insightResults, insights)
        }
      }
    }
  }
  return(insightResults)
}

generateAnalyticInsights <- function(alertID, scoredTx) {
  allAnalytics <- AMLAnalyticConfig$Analytics
  insightResults <- NULL
  for (i in 1:length(allAnalytics)) {
    parms <- unlist(allAnalytics[[i]])

    if (!is.null(parms["InsightFunction"]) && !is.na(parms["InsightFunction"]) && (nchar(trimws(parms["InsightFunction"])) > 0)) {
      source(parms["Source"])
      # execute insight function
      func <- match.fun(parms["InsightFunction"])
      if (!is.null(func)){
        message(paste0("Processing insights for analytic ",allAnalytics[[i]]$Type," (index ",i,") - ",
          allAnalytics[[i]]$Results$ReasonType))
        insights <- func(parms=allAnalytics[[i]], scoredTx)
        insights$alert_ID <- alertID
        insights <- insights %>% select(insightResultsCols)
        if (is.null(insightResults)) {
          insightResults <- insights
        } else {
          insightResults <- rbind(insightResults, insights)
        }
      }
    }
  }
  return(insightResults)
}

generateHighRiskCountry <- function(alerts, parms) {
  #Load the alerts and transactions
  txn_alert <- loadData("JoinedAlerts","ByAlertID")
  transactions <- loadData("Transactions")

  #Get column names from transactions and alerts
  originCountry <- getColumnName("Transactions","OriginatorCountryColumn")
  benCountry <- getColumnName("Transactions","BeneficiaryCountryColumn")
  TxIDCol <- getColumnName("Transactions", "IDColumn")
  JoinAlertIDCol <- getColumnName("JoinedAlerts","IDColumn")
  JoinAlertTxIDCol <- getColumnName("JoinedAlerts","TxIDColumn")
  AlertsIDCol <- getColumnName("Alerts","IDColumn")

  #Select only the necessary transaction columns (ID, countries)
  rel_transactions <- transactions %>% select_(.dots=c(TxIDCol, originCountry, benCountry))

  #Create a filter to filter down the alerts to what was sent here
  filterCriteriaA = paste0(AlertsIDCol," %in% alerts$",
    getColumnName("Alerts","IDColumn"))

  #Filter the alerts down to what was sent here
  txn_alert <- txn_alert %>% filter_(.dots = filterCriteriaA)

  #Seperate out the alerts into high and low risk based on the countries involved with them
  high_risk_alerts <- collect(txn_alert %>% filter(TxRiskCntryCnt > 0))
  low_risk_alerts <- collect(txn_alert %>% filter(is.na(TxRiskCntryCnt)))

  #Turn the risk alerts into a dataframe
  high_risk_alerts_df <- tbl_df(high_risk_alerts)
  low_risk_alerts_df <- tbl_df(low_risk_alerts)

  #Filter down the transactions to only those involved with high risk alerts
  filterCriteriaT = paste0(TxIDCol," %in% high_risk_alerts_df$", getColumnName("JoinedAlerts","TxIDColumn"))
  ptl_high_risk_txn <- rel_transactions %>% filter_(.dots = filterCriteriaT)

  #Save the high risk countries to a vector
  highRiskCntry <- collect(loadData("HighRiskCountries"))
  riskCntryList <- highRiskCntry$Country
  cntryVector <- paste0("c('",paste0(riskCntryList,collapse="','"),"')")

  #Save the origin and bene country columns to a vector
  cols <- c(originCountry, benCountry)

  condition <- ""
  #Create a "condition" that selects high risk countries that are in originator country OR beneficiary country
  for (i in 1:(length(cols)-1)) {
    condition <- paste0(condition, paste("(", cols[i], " %in% ", cntryVector,") | ", sep=""))
  }
  condition <- paste0(condition,paste("(", cols[length(cols)], " %in% ", cntryVector,")", sep=""))

  #Pare down the transactions to only those that meet the criteria of having a high risk country involved
  high_risk_txn <- ptl_high_risk_txn %>%
    filter_(.dots = condition)

  #Turn the high risk transactions into a dataframe for manipulation
  high_risk_txn <- tbl_df(high_risk_txn)

  #Find the unique alert IDs among the alerts sent here
  unique_alert_id_list <- unique(alerts[[AlertsIDCol]])

  #Create a new dataframe for results
  results <- NULL

  #Copy the alerts into a new results dataframe and rename the alert ID column for continuity
  results <- alerts
  names(results)[names(results) == AlertsIDCol] <- 'alert_ID'

  #Create new columns
  results$related_txn <- NA
  results$variables <- NA
  results$insight_id <- 1
  results$score <- NA
  results$band <- NA
  results$related_cntrparties <- NA
  results$related_alerts <- NA

  #Initiate a list to hold relevant variables
  descrip_list <- list(list())

  #For each unique alert ID, find the corresponding high risk transactions (only those who have a high risk country) and save
  #the transactions to the new tran_id column
  for (i in 1:length(unique_alert_id_list))
  {
    #Determine if the current alert ID is a high risk alert
    alerts_in_high_risk <- intersect(unique_alert_id_list[i], high_risk_alerts_df[[JoinAlertIDCol]])

    #If the current alert ID is high risk...
    if (length(alerts_in_high_risk) > 0)
    {
      #Grab the transaction IDs associated with the current alert ID
      txn_list <- high_risk_alerts_df[[JoinAlertTxIDCol]][which(high_risk_alerts_df[[JoinAlertIDCol]] == unique_alert_id_list[i])]
      num_txn <- length(txn_list)

      #If there is more than one transaction associated with the high risk alert, determine exactly WHICH transactions
      #involve high risk countries and save the IDs to a list
      if (num_txn > 1)
      {
        txn_list <- intersect(txn_list, high_risk_txn[[TxIDCol]])
      }

      #Find the updated number of transactions
      num_txn <- length(txn_list)

      ##Acquiring country names of high risk countries involved in transactions
      #initialize a vector to hold the countries
      countryList <- vector()
      #For each transaction for this alert...
      for (j in 1:num_txn)
      {
        #Grab the countries involved with this transaction
        high_risk_txn_indv <- high_risk_txn[which(high_risk_txn[[TxIDCol]] == txn_list[j]), ]

        #For both originator and beneficiary countries...
        for (k in 1:(length(cols))) 
        {
          #Create a filter condition to find if the current party country is high risk
          conditionSplit <- ""
          conditionSplit <- paste0(conditionSplit, paste("(", cols[k], " %in% ", cntryVector,")", sep=""))

          #Determine whether the current party (o vs. b) of the current transaction has a high risk country
          high_risk_txn_split <- high_risk_txn_indv %>% filter_(.dots = conditionSplit)

          #If the current party is involved with a high risk country...
          if(nrow(high_risk_txn_split) > 0)
          {
            #Save the names of the involved countries of the current party
            involvedCountries <- high_risk_txn_split[[cols[k]]]

            #Add the country names to a list
            countryList <- c(countryList, involvedCountries)
          }
        }
      }
      
      #Define a list to hold the unique countries involved in this alert
      uniqueCountries <- list()
      
      #Save the unique countries involved in this alert to a named list 
      uniqueCountries[[AMLAnalyticConfig$CountryType]] <- unique(countryList)
      
      #Convert the unique country list to a dataframe (for for-loop avoidance purposes)
      dataframeCountries <- as.data.frame(uniqueCountries,stringsAsFactors=FALSE)
      
      #Load the country information (to acquire the full name of the countries)
      fullCountries <- as.data.frame(loadData("Countries"))
      fullCountries$Name <- fullCountries$Country
      
      #Create a dataframe containing the full names of the unique countries (for-loop avoidance!)
      namedCountries <- left_join(dataframeCountries, fullCountries) %>% select(Country)
      
      #Turn the named countries dataframe into a comma separated string list 
      stringCountries <- as.vector(namedCountries$Country)
      stringCountries <- paste0(stringCountries, collapse=",")
      
      #Save the involved countries to the variable list
      descrip_list[[1]]$countryNames <- stringCountries
      
      #Save the number of transactions to the variable list
      descrip_list[[1]]$numTransactions <- as.character(num_txn)

      #Turn the involved transaction list into a string
      txn_string <- paste0(txn_list, sep="")

      #Update the columns
      results$variables[i] <- descrip_list
      results$related_txn[i] <- list(txn_string)
      results$score[i] <- 999
      results$band[i] <- AML_highValue

    }
    else ##If the current alert ID is not high risk...
    {
      #Update the columns
      results$variables[i] <- NA   # No variables required
      results$score[i] <- 0
      results$band[i] <- AML_lowValue
    }
  }

  #Subset the relevant portions of the results
  results <- results[,insightResultsCols]

  return(results)
}

getPriorAlerts <- function(alerts, parms) {
  #Load the alerts and transactions
  alertHistByCust <- loadData("AlertHistory","ByCustomerID")
  alertHist <- loadData("AlertHistory")
  transactions <- loadData("Transactions")
  joinAlerts <- loadData("JoinedAlerts","ByAlertID")

  #Get column names from transactions and alerts
  AlertHistCustIDCol <- getColumnName("AlertHistory","CustomerIDColumn")
  AlertHistDisCol <- getColumnName("AlertHistory","DispositionColumn")
  AlertHistIDCol <- getColumnName("AlertHistory","IDColumn")
  AlertsCustIDCol <- getColumnName("Alerts", "CustomerIDColumn")
  AlertsIDCol <- getColumnName("Alerts", "IDColumn")
  JoinAlertIDCol <- getColumnName("JoinedAlerts","IDColumn")
  TxIDCol <- getColumnName("Transactions", "IDColumn")
  
  #Acquire Insight titles for waived and escalated values
  for (i in 1:length(AMLAnalyticConfig$Insights)) 
  {
    if (AMLAnalyticConfig$Insights[[i]]$Type == "PA")
    {
      EscArray <- AMLAnalyticConfig$Insights[[i]]$EscalatedValues
      WaivArray <- AMLAnalyticConfig$Insights[[i]]$WaivedValues
    }
  }
  
  #Create a filter to filter down the transactions (alerts) to what was sent here
  filterCriteriaT = paste0(JoinAlertIDCol," %in% alerts$", AlertsIDCol)

  #Filter the alerts down to what was sent here
  joinAlerts <- joinAlerts %>% filter_(.dots = filterCriteriaT)
  joinAlerts_df <-tbl_df(joinAlerts)

  #Create a filter to filter down the customers to those of the alerts that were sent here
  filterCriteriaC = paste0(AlertHistCustIDCol," %in% alerts$", AlertsCustIDCol)

  #Filter the customers down to those of the alerts that were sent here
  alertHist <- alertHist %>% filter_(.dots = filterCriteriaC)
  alertHist_df <- tbl_df(alertHist)
  alertHistByCust <- alertHistByCust %>% filter_(.dots = filterCriteriaC)
  alertHistByCust_df <- tbl_df(alertHistByCust)

  #Find the unique alert IDs among the alerts sent here
  unique_alert_id_list <- unique(alerts[[AlertsIDCol]])

  #Create a new dataframe for results
  results <- NULL

  #Copy the alerts into a new results dataframe and rename the alert ID column for continuity
  results <- alerts
  names(results)[names(results) == AlertsIDCol] <- 'alert_ID'

  #Create relevant columns
  results$related_txn <- NA
  results$variables <- NA
  results$insight_id <- 2
  results$score <- NA
  results$band <- NA
  results$related_cntrparties <- NA
  results$related_alerts <- NA

  #Initialize a layered list to hold the relevant variables
  descrip_list <- list(list())

  #For each unique alert ID,
  for (i in 1:length(unique_alert_id_list))
  {

    ####PRIORS
    #Find the customer ID of the current alert
    currentCustomerID <- alerts[[AlertsCustIDCol]][which(alerts[[AlertsIDCol]] == unique_alert_id_list[i])]

    #Find the disposition of the current alert
    currentDisposition <- alertHist_df[[AlertHistDisCol]][which(alertHist_df[[AlertHistIDCol]] == unique_alert_id_list[i])]

    #Acquire a list of all prior alerts of the current customer
    priorAlertsCurrentCustomer <- alertHist_df[[AlertHistIDCol]][which(alertHist_df[[AlertsCustIDCol]] == currentCustomerID)]
    #Remove the current alert ID from that list
    priorAlertsCurrentCustomer <- priorAlertsCurrentCustomer[ priorAlertsCurrentCustomer != unique_alert_id_list[i] ]
    #Turn the list into a string for results
    priors_string <- paste0(priorAlertsCurrentCustomer, sep="")

    #Find the IDs of all escalated and waived alerts (for later calculation)
    escAlertIDs <- alertHist_df[[AlertHistIDCol]][which(alertHist_df[[AlertHistDisCol]] %in% EscArray)]
    waivAlertIDs <- alertHist_df[[AlertHistIDCol]][which(alertHist_df[[AlertHistDisCol]] %in% WaivArray)]

    #Extract the previous alert count of the current customerID
    numAlertCount <- alertHistByCust_df$CustomerAlertCount[which(alertHistByCust_df[[AlertHistCustIDCol]] == currentCustomerID)]#HARDCODED

    #If the current customer has a previous alert count...
    if (length(numAlertCount) > 0)
    {
      #Extract the escalated alert count of the current customerID
      numEsclAlertCount <- alertHistByCust_df$CustomerAlertEsclCount[which(alertHistByCust_df[[AlertHistCustIDCol]] == currentCustomerID)]#HARDCODED
      #Extract the waived alert count of the current customerID
      numWaivAlertCount <- alertHistByCust_df$CustomerAlertWaivdCount[which(alertHistByCust_df[[AlertHistCustIDCol]] == currentCustomerID)]#HARDCODED

      if (is.na(numEsclAlertCount)) #If there are no escalated alerts...
      {
        numEsclAlertCount = 0 #Set the official escalated alert number to 0

        #Set the list of escalated alert IDs to NA for this alert
        descrip_list[[1]]$PriorEscalatedIDs <- NA
      }
      else #Otherwise if there ARE escalated alerts...
      {
        if (currentDisposition %in% EscArray) #If the disposition of the current alert is in the escalated array...
        {
          numEsclAlertCount = numEsclAlertCount - 1 #Subtract one from the overall escalated alert count so as not to include the currently assessed alert
        }

        #Get a list of the prior alerts that have disposition "Escalated"
        escAlertsCurrentCust <- intersect(priorAlertsCurrentCustomer, escAlertIDs)
        #Turn the list into a string
        escString = paste(escAlertsCurrentCust, collapse=",")

        #Save the string to the PriorEscalatedIDs variable for this alert
        descrip_list[[1]]$PriorEscalatedIDs <- escString
      }

      if (is.na(numWaivAlertCount)) #If there are no waived alerts
      {
        numWaivAlertCount = 0 #Set the official waived alert number to 0

        #Set the list of waived alert IDs to NA for this alert
        descrip_list[[1]]$PriorWaivedIDs <- NA
      }
      else #Otherwise if there ARE waived alerts
      {
        if (currentDisposition %in% WaivArray) #If the disposition of the current alert is in the waived names array...
        {
          print("Printing inside the waived array if")
          numWaivAlertCount = numWaivAlertCount - 1 #Subtract one from the overall waived alert count so as not to include the currently assessed alert
        }

        #Get a list of the prior alerts that have disposition "Waived"
        waivAlertsCurrentCust <- intersect(priorAlertsCurrentCustomer, waivAlertIDs)
        #Turn the list into a string
        waivString = paste(waivAlertsCurrentCust, collapse=",")

        #Save the string to the PriorWaivedIDs variable for this alert
        descrip_list[[1]]$PriorWaivedIDs <- waivString
      }

      #Update the variables for the current alert
      descrip_list[[1]]$numPriorAlerts <- as.character(numAlertCount - 1)
      descrip_list[[1]]$numPriorWaivedAlerts <- as.character(numWaivAlertCount)
      descrip_list[[1]]$numPriorEscalatedAlerts <- as.character(numEsclAlertCount)

      #Save the layered list of variables into the variables column for this alert
      results$variables[i] <- descrip_list

      #Set the score and band columns
      results$score[i] <- 999
      results$band[i] <- AML_highValue
    }
    else #Otherwise if the current customer does not have an history of alerts...
    {
      #Set the score and band columns
      results$score[i] <- 0
      results$band[i] <- AML_lowValue
      results$variables[i] <- NA   # No variables required

      # #Update the variables for the current alert
      # descrip_list[[1]]$numPriorAlerts <- "0"
      # descrip_list[[1]]$numPriorWaivedAlerts <- "0"
      # descrip_list[[1]]$numPriorEscalatedAlerts <- "0"
      # descrip_list[[1]]$PriorEscalatedIDs <- NA
      # descrip_list[[1]]$PriorWaivedIDs <- NA

    }

    #If the customer has prior alerts, save the prior alert IDs to the results
    if(length(priorAlertsCurrentCustomer)>0)
    {
      results$related_alerts[i] <- list(priors_string)
    }
  }

  #Subset the relevant portions of the results
  results <- results[,insightResultsCols]

  return(results)
}
