# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

calculateCountryScores <- function(parms) {
  df <- tbl_df(loadAnalyticInput(parms$InputSource))
  countryMatchName <- ifelse(AMLAnalyticConfig$CountryType != "Name", AMLAnalyticConfig$CountryType, "Country")
  riskScoreCol <- getColumnName(parms$InputSource$Type, "RiskScoreColumn")
  countryData <- data.frame(df[c(countryMatchName,riskScoreCol)])
  countryData$peer <- 1
  tmpvar <- countryData[c(countryMatchName,riskScoreCol)]
  tmpvar$peer <- 1
  by_peer <- group_by(tmpvar,peer)
  namesV <- c("meanvar","medianvar","stdvar")
  summV <- c(paste0("mean(",riskScoreCol,")"),paste0("median(",riskScoreCol,")"),
    paste0("sd(",riskScoreCol,")"))
  testout <- by_peer %>% summarise_(.dots = setNames(summV,namesV))
  bypeer_univar <- merge(x = countryData, y = testout, by = "peer", all.x = TRUE)
  newcol <- 1000/(1+exp(-0.5*((bypeer_univar[[riskScoreCol]]-(bypeer_univar$medianvar+bypeer_univar$stdvar))*10/((bypeer_univar$medianvar+3*bypeer_univar$stdvar)-(bypeer_univar$medianvar+bypeer_univar$stdvar)))))
  newcol[is.na(newcol)] <- 1
  countryData[[parms$Results$ScoreColumn]] <- newcol
  countryData$peer <- NULL
  countryData[[riskScoreCol]] <- NULL
  colnames(countryData)[colnames(countryData)==countryMatchName] <- "KeyID"
  return(countryData)
}

calculateScoringBands <- function(parms) {
  countryData <- calculateCountryScores(parms)
  scoreCol <- countryData[[parms$Results$ScoreColumn]]
  meanpairs1 <- tbl_df(combn(scoreCol,1,FUN=mean,simplify=TRUE))
  meanpairs2 <- tbl_df(combn(scoreCol,2,FUN=mean,simplify=TRUE))
  meanpairs <- rbind(meanpairs1,meanpairs2)
  writeBandThresholds(meanpairs[[1]], reasonType=parms$Results$ReasonType)
}

calculateScores <- function(parms, dfData) {
  txIDCol <- getColumnName("Transactions", "IDColumn")
  originatorCountryCol <- getColumnName("Transactions", "OriginatorCountryColumn")
  intermediaryCountryCol <- getColumnName("Transactions", "IntermediaryCountryColumn")
  destinationCountryCol <- getColumnName("Transactions", "BeneficiaryCountryColumn")
  countryData <- calculateCountryScores(parms)
  counterData <- countryData
  colnames(countryData)[colnames(countryData)=="KeyID"] <- originatorCountryCol
  colnames(counterData)[colnames(counterData)=="KeyID"] <- destinationCountryCol
  colnames(countryData)[colnames(countryData)==parms$Results$ScoreColumn] <- "CustomerGeoScore"
  colnames(counterData)[colnames(counterData)==parms$Results$ScoreColumn] <- "CounterGeoScore"
  dfData <- merge(x=dfData,y=countryData,by=originatorCountryCol,all.x=TRUE)
  dfData$CustomerGeoScore[is.na(dfData$CustomerGeoScore)] <- max(countryData$CustomerGeoScore, na.rm=TRUE)
  dfData <- merge(x=dfData,y=counterData,by=destinationCountryCol,all.x=TRUE)
  dfData$CounterGeoScore[is.na(dfData$CounterGeoScore)] <- max(counterData$CounterGeoScore, na.rm=TRUE)
  namesV <- c(parms$Results$ScoreColumn)
  summV <- c("1/2*(CustomerGeoScore+CounterGeoScore)")
  dfData <- dfData %>% mutate_(.dots = setNames(summV,namesV))
  dfData[[parms$Results$InsightColumn]] <- paste("{\"CustCntryScore\": ",
    format(round(dfData$CustomerGeoScore,2), nsmall=2),
    ", \"CntCntryScore\": ",
    format(round(dfData$CounterGeoScore,2), nsmall=2),"}",sep="")
  dfData <- select(dfData, c(txIDCol,parms$Results$ScoreColumn,parms$Results$InsightColumn))
  return(dfData)
}

getModelArtifacts <- function(parms) {
  countryRisk <- collect(loadData(parms$InputSource$Type))
  artifactName <- paste(parms$Type,parms$Results$ReasonType,sep="_")
  assign(artifactName, countryRisk, envir = .GlobalEnv)
  labels <- c(paste0(artifactName," (Country Risk Scores)"))
  names(labels) <- c(artifactName)
  return(labels)
}
