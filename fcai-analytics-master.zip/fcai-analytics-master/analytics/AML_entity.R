# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list = ls())
library(data.table)
library(plyr)

filename <- "AML_sim_party.csv"
PartyOrg <- read.csv(filename, header=T, stringsAsFactors=FALSE)
df_PartyOrg <- data.table(PartyOrg)
df_PartyOrg$AllName <- paste(df_PartyOrg$LastName, df_PartyOrg$FirstName, df_PartyOrg$MiddleName)
df_PartyOrg$TypeID <- paste(df_PartyOrg$IDType, df_PartyOrg$IDNum)

df_PartyOrg$Rule1 <- paste(df_PartyOrg$AllName, df_PartyOrg$DOB)
df_PartyOrg$Rule2 <- paste(df_PartyOrg$AllName, df_PartyOrg$TypeID)

#df_PartyOrg[, index1 := seq_len(.N), by = list(AllName, DOB)]
EAID1 <- transform(df_PartyOrg, id1=match(Rule1,unique(Rule1)))
EAID2 <- transform(df_PartyOrg, id2=match(Rule2,unique(Rule2)))
EAID2 <- subset(EAID2, select = c(PartyID, id2))

#use first party as resolved ID
subID1 <- EAID1[!duplicated(EAID1$id1),]
subID1 <- subset(subID1, select = c(PartyID, id1))
names(subID1) <- c("ResolvedID","id1")
EAID1 <- merge(x=EAID1, y= subID1, by="id1", all.x=TRUE)
EAID1 <- merge(x=EAID1, y= EAID2, by="PartyID", all.x=TRUE)

write.csv(EAID1, file="EA_check.csv")
t1 <- ddply(EAID1,~id2,summarise,no_of_unique_ID=length(unique(ResolvedID)))
#get id2 that are > 1
t1s1 <- subset(t1,t1$no_of_unique_ID>1)
EAID1_s1 <- subset(EAID1, id2 %in% t1s1$id2)
#pick the top resolved ID
EAID1_s1 <- ddply(EAID1_s1, "id2", head,1)

EAID1_s1 <- subset(EAID1_s1, select =c(ResolvedID, id2))
names(EAID1_s1) <- c("ResolvedID2","id2")

EAID1 <- merge(x=EAID1, y= EAID1_s1, by="id2", all.x=TRUE)

EAID1$ResolvedID2[is.na(EAID1$ResolvedID2)] <- as.character(EAID1$ResolvedID[is.na(EAID1$ResolvedID2)])


#Resolved_Party <- df_PartyOrg[!duplicated(df_PartyOrg$EAID),]
