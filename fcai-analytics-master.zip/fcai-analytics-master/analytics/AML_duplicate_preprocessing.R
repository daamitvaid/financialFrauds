# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.


##TODO Notes:
#Data acquisition eventually needs to happen through the config file, probably.

#If data acquisition does not end up using csv files, a different method of stripping
#trailing white spaces will need to be implemented.

#Currently the column names are hard coded; once this script is hooked into the greater
#analytics, the config file can be used to allow for dynamic column names

#Currently the file input and output names (and directories) are taken from command line arguments.
#This will probably need to be changed once the script is hooked into the greater analytics.

library(dplyr)

#Initialize columns to be added to hits file
uniqueHitsBucketOne <- NULL
uniqueHitsBucketTwo <- NULL
uniqueHitsBucketThree <- NULL

#Define function that finds duplicates of submitted dataframe and returns an array
#of "unique" tags stating whether each row is a unique hit or not
labelUniqueColumn <- function(hitData, toFindDuplicates) {
  
  #Initialize array that contains "unique" tags
  uniqueHitsBucket <- NULL
  
  #Find rows that are exact character duplicates of each other within the selected columns
  duplicateForward <- duplicated(toFindDuplicates)
  duplicateBackward <- duplicated(toFindDuplicates, fromLast = TRUE)
  
  #For each row, if either duplicate array is listed as true, label the unique tag as N (false).
  #Otherwise, label as Y (true).
  for (i in 1:nrow(hitData))
  {
    if (duplicateForward[i] == TRUE | duplicateBackward[i] == TRUE)
    {
      uniqueHitsBucket[i] <- "N"
    }
    else
    {
      uniqueHitsBucket[i] <- "Y"
    }
  }
  
  #return the array containing the unique tags
  return(uniqueHitsBucket)
}

#Acquire file input name and file output name from command line inputs
args = commandArgs(trailingOnly=TRUE)

#Stop the program if there are not two arguments fed into the file
if (length(args) < 2)
{
  stop("
Usage:AML_duplicate_preprocessing.R <input filename/path> <output filename/path>

Two arguments are required to run this file.")
}

#Read in the data and strip trailing white spaces
hitData<-read.csv(args[1], strip.white=TRUE)
hitDataEdited <- hitData

###BUCKET 1.0 equivalent
#Find unique hits for all columns regardless of trailing white space and capitalization

#Eliminate case type differences
noCase <- as.data.frame(sapply(hitData, toupper))

#Generate and save "unique" labels to data frame
uniqueHitsBucketOne <- labelUniqueColumn(hitData, noCase)
hitDataEdited$IsUnique_Bucket1 <- uniqueHitsBucketOne
###


###BUCKET 1.1 equivalent
#Remove /, ., # and - characters from every entry of the MATCH_DATA column, then find
#entries that are duplicates in fields AlertID, MATCH_DATA, WatchlistID and Input

#Remove special characters from MATCH_DATA
hitDataMatchEdit <- hitData
hitDataMatchEdit$MATCH_DATA <- gsub('\\.|/|#|-', '', hitDataMatchEdit$MATCH_DATA)

#Select data with columns ALERT_IDENTIFIER, MATCH_DATA, WATCHLIST_ENTRY_ID and INPUT
selectColumns <- select(hitDataMatchEdit, c("ALERT_IDENTIFIER", "MATCH_DATA", "WATCHLIST_ENTRY_ID", "INPUT"))

#Generate and save "unique" labels to data frame
uniqueHitsBucketTwo <- labelUniqueColumn(hitData, selectColumns)
hitDataEdited$IsUnique_Bucket2 <- uniqueHitsBucketTwo
###


##BUCKET 1.2 equivalent
#Remove /, ., # and - characters from every entry of the MATCH_DATA column, then find
#entries that are duplicates in fields MATCH_DATA, WatchlistID and Input

#Select data with columns MATCH_DATA, WATCHLIST_ENTRY_ID and INPUT (hitDataMatchEdit is pulled
#from above since special characters have already been removed)
selectColumns <- select(hitDataMatchEdit, c("MATCH_DATA", "WATCHLIST_ENTRY_ID", "INPUT"))

#Generate and save "unique" labels to data frame
uniqueHitsBucketThree <- labelUniqueColumn(hitData, selectColumns)
hitDataEdited$IsUnique_Bucket3 <- uniqueHitsBucketThree
###

#Temporary option for outputting a csv file before this script is hooked into the greater analytics
write.csv(hitDataEdited, file = args[2], row.names=FALSE)
