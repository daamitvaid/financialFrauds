# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
library(zoo)

#default weight for GII
FPS1_weight_default = 0.2;     #1-ratio of missing to valid record
FPS3_weight_default = 0.2;     #no. of outlier
FPS4_weight_default = 0.2;     #Skewness
FPS5_weight_default = 0.2;     #Standard Deviation
FPS6_weight_default = 0.2;     #Kurtosis

#Threshold compare for FindOutliers function
compareThrd_sum <- function(var1, var2) {
  sum(var1 > var2)
}

compareThrd <- function(var1, var2) {
  result <- ifelse(var1 > var2, 1, 0)
}

FindOutliers <- function(x) {
  #lowerq = quantile(x)[2]
  lowerq = sapply(x,quantile,0.25,na.rm=TRUE)
  #upperq = quantile(x)[4]
  upperq = sapply(x,quantile,0.75,na.rm=TRUE)
  iqr = upperq - lowerq #Or use IQR(data)
  # we identify extreme outliers
  extreme.threshold.3upper = (iqr * 3) + upperq
  extreme.threshold.3lower = lowerq - (iqr * 3)
  extreme.threshold.2upper = (iqr * 2) + upperq
  extreme.threshold.2lower = lowerq - (iqr * 2)

  #extreme.threshold.3std = (sd(x) * 3) + mean(x)
  #extreme.threshold.2std = (sd(x) * 2) + mean(x)
  extreme.threshold.3std = (sapply(x,sd) * 3) + sapply(x,mean)
  extreme.threshold.2std = (sapply(x,sd) * 2) + sapply(x,mean)

  #only use upperthreshold for now
  outlier1 <- mapply(compareThrd, x, extreme.threshold.3upper)
  outlier2 <- mapply(compareThrd, x, extreme.threshold.2upper)
  outlier3 <- mapply(compareThrd, x, extreme.threshold.3std)
  outlier4 <- mapply(compareThrd, x, extreme.threshold.2std)
  #outlier1 <- ifelse(x > extreme.threshold.3upper, 1, 0)
  #outlier2 <- ifelse(x > extreme.threshold.2upper, 1, 0)
  #outlier3 <- ifelse(x > extreme.threshold.3std, 1, 0)
  #outlier4 <- ifelse(x > extreme.threshold.2std, 1, 0)

  tot.outlier <- outlier1 + outlier2 + outlier3 + outlier4

  #outlier <- rbind(extreme.threshold.3upper, extreme.threshold.2upper, extreme.threshold.3std, extreme.threshold.2std,outlier1, outlier2, outlier3, outlier4)
  result <- ifelse(tot.outlier > 0, 1, 0)
  return(result)
  #return(tot.outlier)
}

GII_function <- function(x, FPS1_weight=FPS1_weight_default,
    FPS3_weight=FPS3_weight_default, FPS4_weight=FPS4_weight_default,
    FPS5_weight=FPS5_weight_default, FPS6_weight=FPS6_weight_default) {

  FPS1 <- apply(is.na(x),2,sum) #for each column, get no. of NA records
  FPS2 <- nrow(x)-FPS1      #for each column, get no. of valid records
  #replace NA with column mean
  x <- doNAaggregate(x)

  # use the function to identify outliers
  temp <- FindOutliers(x)
  FPS3 <- apply(temp,2, sum)             #for each column, get no. of outlier
  mean.ind <- t(matrix(rep(sapply(x,mean),nrow(x)), ncol(x), nrow(x)))    #matrix
  Skew.ind <- (x-mean.ind)^3                                              #matrix
  Kurtosis.ind <- (x-mean.ind)^4                                          #matrix

  #Skew.ind <- (x-sapply(x, mean))^3
  #Kurtosis.ind <- (x-sapply(x, mean))^4
  FPS5 <- sapply(x, sd)                               #for each column, get STD
  FPS4 <- apply(Skew.ind,2, sum)/FPS2/(FPS5^3)
  FPS6 <- apply(Kurtosis.ind, 2, sum)/FPS2/(FPS5^4)-3
  FPS1_score=1-FPS1/FPS2
  FPS1_score[FPS1_score<0] <- 0
  FPS3_score= FPS3/FPS2
  FPS4_score= 1 - exp(-0.346 * abs(FPS4))
  FPS5_score= 1 - exp(-0.1 * abs(FPS5))
  FPS6_score= 1 - exp(-0.18 * abs(FPS6))
  FPS4_score[is.na(FPS4_score)] <- 0
  FPS6_score[is.na(FPS6_score)] <- 0
  GII=FPS1_weight*FPS1_score+FPS3_weight*FPS3_score+FPS4_weight*FPS4_score+FPS5_weight*FPS5_score+FPS6_weight*FPS6_score

  #              II_weight <- list(FPS1_score, FPS3_score, FPS4_score, FPS5_score, FPS6_score, GII)
  II_list <- rbind(FPS1_score, FPS3_score, FPS4_score, FPS5_score, FPS6_score, GII)
  return(II_list)
}

# execute and store the GII (General Interestingness Index)
generateGII <- function(x, idColumnCount=1, outputName, outputPath=NA,
    outputType="csv", FPS1=FPS1_weight_default, FPS3=FPS3_weight_default,
    FPS4=FPS4_weight_default, FPS5=FPS5_weight_default,
    FPS6=FPS6_weight_default) {

  # in case any values were deleted from the config
  if (is.null(FPS1)) { FPS1=FPS1_weight_default }
  if (is.null(FPS3)) { FPS3=FPS3_weight_default }
  if (is.null(FPS4)) { FPS4=FPS4_weight_default }
  if (is.null(FPS5)) { FPS5=FPS5_weight_default }
  if (is.null(FPS6)) { FPS6=FPS6_weight_default }

  # Scale the weigths (if needed) so that their sum is 1.0
  FPS_sum = FPS1 + FPS3 + FPS4 + FPS5 + FPS6
  if (FPS_sum != 1.0) {
    FPS_scale = 1.0 / FPS_sum
    FPS1 = FPS_scale * FPS1
    FPS3 = FPS_scale * FPS3
    FPS4 = FPS_scale * FPS4
    FPS5 = FPS_scale * FPS5
    FPS6 = FPS_scale * FPS6
  }

  message(paste0("generateGII, using weights: FPS1=",FPS1,", FPS3=",FPS3,
    ", FPS4=",FPS4,", FPS5=",FPS5,", FPS6=",FPS6))
  II_weight <- GII_function((tbl_df(x) %>% select(-c(1:idColumnCount))),
    FPS1, FPS3, FPS4, FPS5, FPS6)
  T_weight <- matrix(0, ncol(II_weight),1)
  T_weight[,1]=II_weight[6,]
  T_weight[is.na(T_weight)] <- 0.1
  T_weight.df <- data.frame(Feature=colnames(II_weight),GII=T_weight[,1],
    stringsAsFactors=FALSE)
  storeOutput(copy_to(sc, tbl_df(T_weight.df) %>% arrange(desc(GII))),name=outputName,
    path=outputPath, type=outputType)
  rm(II_weight,T_weight,T_weight.df)
}

getFactorsFileName <- function(parms, type) {
  paste0("AML_Univariate_",parms$Results$ReasonType,"_factors.",type)
}

executeScoringCurve <- function(parms, dataset, F_Left_Edge, F_Midpoint, F_Right_Edge) {
  m_F_Left_Edge <- t(matrix(rep(F_Left_Edge,nrow(dataset)), ncol(dataset), nrow(dataset)))
  m_F_Midpoint <- t(matrix(rep(F_Midpoint,nrow(dataset)), ncol(dataset), nrow(dataset)))
  m_F_Right_Edge <- t(matrix(rep(F_Right_Edge,nrow(dataset)), ncol(dataset), nrow(dataset)))

  dummy <- matrix(0,nrow(dataset), ncol(dataset))
  if (parms$ScoringCurve == "Growth") {
    #growth curve
    dummy <-1000/(1+exp(-0.5*((dataset-m_F_Midpoint)*10/(m_F_Right_Edge - m_F_Midpoint))))
  } else if (parms$ScoringCurve == "Decline") {
    #decline curve
    dummy <-1000-1000/(1+exp(-0.5*((dataset-m_F_Left_Edge)*10/(m_F_Midpoint - m_F_Left_Edge))))
  } else {
    #use growth curve as the default
    warning("Unrecognized ScoringCurve (",parms$ScoringCurve,"), using Growth curve by default.")
    #growth curve
    dummy <-1000/(1+exp(-0.5*((dataset-m_F_Midpoint)*10/(m_F_Right_Edge - m_F_Midpoint))))
  }
  dummy[is.na(dummy)] <- 1
  return(dummy)
}

calculateScoringBands <- function(parms) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scoring bands for reason type \"",flatparms["Results.ReasonType"],"\""))
  if (parms$InputSource$SourceType != "Aggregate") {
    stop("AML_univariate calculateScoringBands can only be executed with an InputSource.SourceType of Aggregate")
  }

  dfData <- tbl_df(loadAnalyticInput(parms$InputSource))
  if (isDebug(parms)) {
    message(createSourceHeader(parms$InputSource))
    print(head(dfData))
  }
  dfDataColumns <- colnames(dfData)

  if (!is.null(parms$GroupingSource) && !is.null(parms$GroupingSource$SourceType)) {
    peerData <- tbl_df(loadAnalyticInput(parms$GroupingSource))
    if (isDebug(parms)) {
      message(createSourceHeader(parms$GroupingSource))
      print(head(peerData))
    }

    byX <- getColumnNames(parms$InputSource$Type,
      parms$GroupingSource$JoinColumnsX)
    dfDataColumns <- dfDataColumns[(length(byX)+1):length(dfDataColumns)]
    if (parms$GroupingSource$SourceType == "Function") {
      byY <- unlist(parms$GroupingSource$JoinColumnsY)
      peerGroupColumn <- parms$GroupingSource$PeerGroupColumn
    } else {
      byY <- getColumnNames(parms$GroupingSource$Type,
        parms$GroupingSource$JoinColumnsY)
      peerGroupColumn <- getColumnNames(parms$GroupingSource$Type,
        parms$GroupingSource$PeerGroupColumn)
    }

    #add peer information to dfData for peer group identification purpose
    dfData_ext <- merge(x = dfData, y = peerData, by.x = byX, by.y = byY, all.x = TRUE)
  } else {
    dfData_ext <- dfData %>% mutate(AI_artificial_group=1)
    peerGroupColumn = "AI_artificial_group"
    byX <- getAggregateByColumnNames(parms$InputSource$Type,
      parms$InputSource$AggregateName)
  }

  results <- data.frame(Date=as.Date(character()),
    File=character(),
    User=character(),
    stringsAsFactors=FALSE)

  peer_group_set <- unique(dfData_ext[[peerGroupColumn]])

  for (i in 1:length(peer_group_set)) {
    df_subset <- subset(dfData_ext, dfData_ext[[peerGroupColumn]] %in% peer_group_set[i])
    if (isDebug(parms)) {
      message(paste0("Peer_group_set: ",peer_group_set[i],", rows: ",nrow(df_subset)))
    }
    if (nrow(df_subset) > 0) {
      df_subset_ID <- subset(df_subset, select = c(byX, peerGroupColumn))
      df_subset <- subset(df_subset, select=dfDataColumns)
      df_subset %<>% mutate_all(as.numeric)
      F_Left_Edge <- sapply(df_subset, median)
      F_Midpoint <- sapply(df_subset, median) + sapply(df_subset, sd)
      F_Right_Edge <- sapply(df_subset, median) + 3*sapply(df_subset, sd)

      t_F_Left_Edge <- tbl_df(t(F_Left_Edge))
      t_F_Left_Edge$F_type <- "F_Left_Edge"
      t_F_Midpoint <- tbl_df(t(F_Midpoint))
      t_F_Midpoint$F_type <- "F_Midpoint"
      t_F_Right_Edge <- tbl_df(t(F_Right_Edge))
      t_F_Right_Edge$F_type <- "F_Right_Edge"

      F_storageTmp <- rbind(t_F_Left_Edge,t_F_Midpoint)
      F_storageTmp <- rbind(F_storageTmp,t_F_Right_Edge)
      F_storageTmp$Univariate_peer <- peer_group_set[i]

      if (!exists("F_Storage")) {
        F_Storage <- F_storageTmp
      } else {
        F_Storage <- rbind(F_Storage, F_storageTmp)
      }

      dummy <- executeScoringCurve(parms, df_subset, F_Left_Edge, F_Midpoint, F_Right_Edge)
      dummy <- cbind(df_subset_ID,dummy)
      results <- rbind(results, dummy)
    }
  }
  #save F_Storage
  storeOutput(copy_to(sc,F_Storage,overwrite=TRUE),
    name=getFactorsFileName(parms, type="csv"), type="csv",
    path=AMLAnalyticConfig$DataDirectory)

  rm(df_subset, dummy, df_subset_ID, F_Left_Edge, F_Midpoint, F_Right_Edge)

  VarGII <- data.frame(loadData(parms$InputSource$Type,
    parms$InputSource$AggregateName, GII=TRUE), stringsAsFactors=FALSE)
  T_scoring <- subset(results, select = VarGII$Feature)
  T_weight <- matrix(0, nrow(VarGII),1)
  T_weight[,1]=VarGII$GII

  Weighted_score <- (as.matrix(T_scoring) %*% as.matrix(T_weight))/sum(T_weight)
  writeBandThresholds(Weighted_score, flatparms["Results.ReasonType"])

}

calculateScores <- function(parms, dfData) {
  flatparms <- unlist(parms)
  message(paste0("Calculating scores for reason type \"",
    flatparms["Results.ReasonType"],"\""))

  if (parms$InputSource$SourceType != "Aggregate") {
    stop("AML_univariate calculateScores can only be executed with an InputSource.SourceType of Aggregate")
  }

  if (!is.null(parms$GroupingSource) && !is.null(parms$GroupingSource$SourceType)) {
    byX <- getColumnNames(parms$InputSource$Type,
      parms$GroupingSource$JoinColumnsX)
  } else {
    byX <- getAggregateByColumnNames(parms$InputSource$Type,
      parms$InputSource$AggregateName)
  }
  dfData <- dfData %>% arrange_(byX)
  if (isDebug(parms)) {
    message(createSourceHeader(parms$InputSource))
    print(head(dfData))
  }
  dfDataColumns <- colnames(dfData)
  dfDataColumns <- dfDataColumns[(length(byX)+1):length(dfDataColumns)]

  if (!is.null(parms$GroupingSource) && !is.null(parms$GroupingSource$SourceType)) {
    peerData <- tbl_df(loadAnalyticInput(parms$GroupingSource))
    if (isDebug(parms)) {
      message(createSourceHeader(parms$GroupingSource))
      print(head(peerData))
    }

    if (parms$GroupingSource$SourceType == "Function") {
      byY <- unlist(parms$GroupingSource$JoinColumnsY)
      peerGroupColumn <- parms$GroupingSource$PeerGroupColumn
    } else {
      byY <- getColumnNames(parms$GroupingSource$Type,
        parms$GroupingSource$JoinColumnsY)
      peerGroupColumn <- getColumnNames(parms$GroupingSource$Type,
        parms$GroupingSource$PeerGroupColumn)
    }

    #add peer information to dfData for peer group identification purpose
    dfData_ext <- merge(x = dfData, y = peerData, by.x = byX, by.y = byY, all.x = TRUE)
  } else {
    dfData_ext <- dfData %>% mutate(AI_artificial_group=1)
    peerGroupColumn = "AI_artificial_group"
  }
  results <- data.frame(Date=as.Date(character()),
    File=character(),
    User=character(),
    stringsAsFactors=FALSE)

  F_factors <- tbl_df(readInput(getFactorsFileName(parms, type="csv"), type="csv",
    path=AMLAnalyticConfig$DataDirectory))
  F_factorNames <- colnames(F_factors[,1:(ncol(F_factors)-2)])
  if (isDebug(parms)) {
    message(createDataHeader(getFactorsFileName(parms, type="csv")))
    print(F_factors,width=Inf)
  }

  peer_group_set <- unique(F_factors$Univariate_peer)

  for (i in 1:length(peer_group_set)) {
    df_subset <- subset(dfData_ext, dfData_ext[[peerGroupColumn]] %in% peer_group_set[i])
    if (isDebug(parms)) {
      message(paste0("Peer_group_set: ",peer_group_set[i],", rows: ",nrow(df_subset)))
    }
    if (nrow(df_subset) > 0) {
      df_subset_ID <- subset(df_subset, select = c(byX, peerGroupColumn))
      df_subset <- subset(df_subset, select=dfDataColumns)
      df_subset %<>% mutate_all(as.numeric)
      F_Left_Edge <- F_factors %>% filter(Univariate_peer==peer_group_set[i]) %>% filter(F_type=="F_Left_Edge")
      F_Left_Edge <- as.numeric(F_Left_Edge[1,1:(ncol(F_Left_Edge)-2)])
      # names(F_Left_Edge) <- F_factorNames
      F_Midpoint <- F_factors %>% filter(Univariate_peer==peer_group_set[i]) %>% filter(F_type=="F_Midpoint")
      F_Midpoint <- as.numeric(F_Midpoint[1,1:(ncol(F_Midpoint)-2)])
      # names(F_Midpoint) <- F_factorNames
      F_Right_Edge <- F_factors %>% filter(Univariate_peer==peer_group_set[i]) %>% filter(F_type=="F_Right_Edge")
      F_Right_Edge <- as.numeric(F_Right_Edge[1,1:(ncol(F_Right_Edge)-2)])
      # names(F_Right_Edge) <- F_factorNames

      dummy <- executeScoringCurve(parms, df_subset, F_Left_Edge, F_Midpoint, F_Right_Edge)
      dummy <- cbind(df_subset_ID,dummy)
      results <- rbind(results, dummy)
    }
  }
  results <- results %>% arrange_(byX)
  rm(df_subset, dummy, df_subset_ID, F_Left_Edge, F_Midpoint, F_Right_Edge)

  VarGII <- data.frame(loadData(parms$InputSource$Type,
    parms$InputSource$AggregateName, GII=TRUE), stringsAsFactors=FALSE)
  T_scoring <- subset(results, select = VarGII$Feature)
  T_weight <- matrix(0, nrow(VarGII),1)
  T_weight[,1]=VarGII$GII

  Weighted_score <- (as.matrix(T_scoring) %*% as.matrix(T_weight))/sum(T_weight)

  #pick top two reasons
  T_scoring <- data.matrix(T_scoring)
  names(T_scoring) <- names(dfData[c(2: ncol(dfData))])
  mx <- t(apply(T_scoring,1,function(x)names(T_scoring)[sort(head(order(x,decreasing=TRUE),2))]))
  dfData$topcol <- mx

  #add score column to the original statistics
  dfData[parms$Results$ScoreColumn] <- Weighted_score[,1]

  dfData$INSGR1 <- NA
  dfData$INSGS1 <- NA
  dfData$INSGR2 <- NA
  dfData$INSGS2 <- NA
  for (i in 1:(nrow(dfData))) {
    colnum1 <- which(colnames(T_scoring) == dfData$topcol[i,1])
    colnum2 <- which(colnames(T_scoring) == dfData$topcol[i,2])
    dfData$INSGR1[i] <- dfData$topcol[i,1]
    dfData$INSGS1[i] <- round(T_scoring[i,colnum1],2)
    dfData$INSGR2[i] <- dfData$topcol[i,2]
    dfData$INSGS2[i] <- round(T_scoring[i,colnum2],2)
    rm(colnum1,colnum2)
  }

  dfDataScore <- select(dfData, byX, parms$Results$ScoreColumn,
    INSGR1, INSGS1, INSGR2, INSGS2)
  dfDataScore <- copy_to(sc, dfDataScore, "dfDataScore", overwrite=TRUE)
  dfDataScore <- dfDataScore %>%
    mutate(insights = paste('{"',INSGR1,'":', round(INSGS1,2L),
    ',"',INSGR2,'":',round(INSGS2,2L),'}',sep="")) %>%
    rename_(.dots = setNames("insights", parms$Results$InsightColumn))
  dfDataScore <- select(dfDataScore, byX, parms$Results$ScoreColumn,
    parms$Results$InsightColumn)

  dfData <- subset(dfData, select = -c(topcol, INSGR1, INSGS1, INSGR2, INSGS2))

  rm(T_scoring, T_weight, Weighted_score, mx, VarGII, results,
    dfData_ext, peer_group_set)

  if (isDebug(parms)) {
    message("========================== Scored data ===========================")
    print(head(dfDataScore))
  }
  return(dfDataScore)
}
