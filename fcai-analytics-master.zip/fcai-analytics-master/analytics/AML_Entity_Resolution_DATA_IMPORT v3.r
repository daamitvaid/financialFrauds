
## Import the required R packages
library(sqldf)

#########################Import datasets ####################################################################################################
## Set file path
filepath <- paste0(root_dir,"aml-analytics-master/sample_data/")

## Import AML Sample datasets
AML_sim_data_v4 <- read.csv(paste0(filepath,"AML_sim_data_v4.csv"),sep=",",header = TRUE)
  
AML_tx_scored_alert_output <- read.csv(paste0(filepath,"AML_tx_scored_alert_output.csv"),sep=",",header = TRUE)

AML_sim_alert <- read.csv(paste0(filepath,"AML_sim_alert.csv"),sep=",",header = TRUE)

customerID_EA <- read.csv(paste0(filepath,"customerID_EA.csv"),sep=",",header = TRUE)

## Import G2 dataset for filling missing fields/values
inputdataset_G2_Generated <- read.csv(paste0(filepath,"inputdataset_G2_Generated.csv"),sep=",",header = TRUE)


## Combine AML datasets
inputdataset_AML_Generated <-sqldf(
	"SELECT
		
		/*********REQUIRED FIELDS*******/
		NULL AS CASE_NUM,
		a.CustomerID AS CUST_ID,
		NULL AS ACCT_NUM,
		NULL AS SOURCE_CODE,
		CAST(a.CustomerID AS TEXT) AS SOURCE_KEY,
		NULL AS EA_DEGREE,
		NULL AS EA_SOURCE,
		NULL AS EA_SOURCE_KEY,
		DATE(b.AlertCreateDate) AS CASE_DT,
		b.Disposition AS CASE_STATUS,
		NULL AS ANY_TRAN_ESCALATED,
		Date(CaseCreateDate) AS CASE_DISP_DT,
		NULL AS EQUIV_DISP_CODE,
		/* EA_ID  ...field is added in the next step through join*/
		NULL AS DB_INSTANCE,
		NULL AS OPS_CENTER,
		
		/**********MISSING FIELDS FOR RULES 1 to 4 *************/
		NULL AS FOCUS_PREV_ESC_RESOLVED_CPARTY_RECENCY,
		NULL AS FOCUS_PREV_ESC_RESOLVED_FOCUS_RECENCY,
		NULL AS FOCUS_PREV_ESC_ENABLE,
		NULL AS FOCUS_PREV_SUBJ2INQ_RESOLVED_CPARTY_RECENCY,
		NULL AS FOCUS_PREV_SUBJ2INQ_RESOLVED_FOCUS_RECENCY,
		NULL AS FOCUS_PREV_SUBJ2INQ_ENABLE,
		NULL AS FOCUS_PREV_ESC_CLOSE_RELATED_CPARTY_RECENCY,
		NULL AS FOCUS_PREV_ESC_CLOSE_RELATED_FOCUS_RECENCY,
		NULL AS FOCUS_PREV_ESC_CLOSE_ENABLE,
		NULL AS FOCUS_PREV_SUBJ2INQ_CLOSE_RELATED_CPARTY_RECENCY,
		NULL AS FOCUS_PREV_SUBJ2INQ_CLOSE_RELATED_FOCUS_RECENCY,
		NULL AS FOCUS_PREV_SUBJ2INQ_CLOSE_ENABLE,

		/***************MISSING FIELDS FOR RULE 5 **************/
		CAST(NULL AS INTEGER) AS CUST_BUS_RISK,
		CAST(NULL AS INTEGER) AS CUST_EFF_RISK,
		CAST(NULL AS INTEGER) AS CUST_GEO_RISK,
		CAST(NULL AS DATE) AS LAST_RISK_DT,
		CAST(NULL AS INTEGER) AS FOCUS_ELEVATED_RISK_RESOLVED_FOCUS_RECENCY,
		CAST(NULL AS INTEGER) AS FOCUS_ELEVATED_RISK_DURATION,
		NULL AS FOCUS_ELEVATED_RISK_ENABLE,
		
		/***************MISSING FIELDS FOR RULE 15 **************/
		NULL AS FLAG_CODE,
		CAST(NULL AS DATE) AS FLAG_DATE,
		NULL AS FLAG_VALUE,
		NULL AS PERSONAL_ACCTS_BIZ_PURPOSE_RESOLVED_FOCUS_RECENCY,
		NULL AS PERSONAL_ACCTS_BIZ_PURPOSE_ENABLE,

		/***************MISSING FIELDS FOR RULE 17 **************/
		CAST(NULL AS DATE) AS ACCT_OPEN_DT,
		NULL AS ACCT_STATUS,
		CAST(NULL AS DATE) AS ACCT_STATUS_DT,
		NULL AS PREV_CLOSED_ACCTS_DURATION,
		NULL AS PREV_CLOSED_ACCTS_RESOLVED_FOCUS_RECENCY,
		NULL AS PREV_CLOSED_ACCTS_ENABLE,
		
		/*********PASSTHROUGH FIELDS*******/
		NULL AS CASE_FOCUS_ID,
		NULL AS CASE_CPARTY_ID,
		NULL AS CASE_ALERT_ID
		
	FROM
		AML_sim_data_v4 as a
		INNER JOIN AML_tx_scored_alert_output as b
		INNER JOIN AML_sim_alert
		USING (CustomerID,TransID)
		ORDER BY a.CustomerID,a.TransID"
)

inputdataset_AML_Generated <- sqldf(
	"SELECT a.*,b.EA_ID
	FROM inputdataset_AML_Generated a
	LEFT JOIN customerID_EA b
	ON a.CUST_ID=b.CustomerID"
)

##write generated datset to file....for testing only
write.csv(inputdataset_AML_Generated, file = paste0(filepath,"inputdataset_AML_Generated.csv"))

## Combine AML sample data and G2 datasets to generate input dataset for the G2 rules 1 to 4

inputdataset <- sqldf(
"SELECT *
FROM inputdataset_G2_Generated
UNION
SELECT *
FROM inputdataset_AML_Generated "
)

##clean up of datasets
remove(
		AML_sim_alert,
		AML_sim_data_v4,
		AML_tx_scored_alert_output,
		customerID_EA,
		inputdataset_AML_Generated,
		inputdataset_G2_Generated)