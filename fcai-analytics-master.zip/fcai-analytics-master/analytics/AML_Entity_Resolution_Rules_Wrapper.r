## Set file path
root_dir <- "C:/Users/IBM_ADMIN/Documents/AML/"

setwd(paste0(root_dir,"v2/"))

source("AML_Entity_Resolution_DATA_IMPORT v3.r")
source("AML_Entity_Resolution Rule 1 to 4 v4.r")
source("AML_Entity_Resolution Rule 5 v3.r")
source("AML_Entity_Resolution Rule 15 v3.r")
source("AML_Entity_Resolution Rule 17 v3.r")

outputdataset <- rbind(output1to4,output5,output15,output17)

remove(output1to4,output5,output15,output17,filepath,rules_function,param_list)
