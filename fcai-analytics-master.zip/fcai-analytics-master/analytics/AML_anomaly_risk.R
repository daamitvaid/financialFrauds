# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

#names(testdata) <- c("KeyID", "score", "peer")


#calculate risk score based on different peer group

#for (i in 2:ncol(byCustomerID)) {
for (i in 2:2) {
   tmpvar <- testdata
    testout <- ddply(testdata, c("peer"), summarise,
               N    = length(score),
               meanvar = mean(score),
               medianvar = median(score),
               stdvar   = sd(score)
               )

     #by_peer <- group_by(tmpvar,peer)
     #testout <- summarise(by_peer, meanvar=mean(tmpvar$score), medianvar=median(tmpvar$score), stdvar=sd(tmpvar$score))
     bypeer_univar <- merge(x = testdata, y = testout, by = "peer", all.x = TRUE)
     rm(tmpvar,testout)
     #calculate score ## note the "peer" got moved to column 1 so variable start with i+1
     newscore <- 1000/(1+exp(-0.5*((bypeer_univar[[i+1]]-(bypeer_univar$medianvar+bypeer_univar$stdvar))*10/((bypeer_univar$medianvar+3*bypeer_univar$stdvar)-(bypeer_univar$medianvar+bypeer_univar$stdvar)))))

   newscore[is.na(newscore)] <- 1

   newcol_ext <- cbind(bypeer_univar, newscore)
   rm(bypeer_univar,newscore)
   newcol_ext[c("newscore")][which(newcol_ext$N <=3),] <- max(newcol_ext$newscore)
   newcol_ext <- subset(newcol_ext, select = c(KeyID, peer, newscore))

   #univar_scoring[[i]]=newcol
   ## need to make sure order of KeyID stay the same
}

testdata <- merge(x = testdata, y = newcol_ext, by = c("KeyID", "peer"), all.x = TRUE)
rm(newcol_ext)

#rm(newcol_ext, tmpvar, testout, bypeer_univar, newcol)
#write.csv(testdata, file="AML_Country_Risk.csv")
