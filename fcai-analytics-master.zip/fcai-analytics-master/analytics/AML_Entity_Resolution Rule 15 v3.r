

#################################### SPSS G2 ENTITY RESOLUTION STREAM TRANSLATION ########################################################
##                                                                                                                                      ##
## The script below translates super node 15 of G2 SPSS stream CASE_FOCUS_SIT.v12 into R scripts ##########################################
## This rule has a logic different to the other supernodes and thus has been coded separately ############################################
## The script takes in the CASE_FOCUS_RESUME.V12.csv as an input file and generates and outputdataset similar to the G2 SPSS stream ######
## The function is implemented using R library sqldf using SQLite scripts. If required a DB2 SQL script can replace the R script below ###
##                                                                                                                                      ##
##                                                                                                                                      ##
##                                                                                                                                      ##
## DEVELOPED BY : ANISH DIXIT                                                                                        DATE : 27-SEP-2017 ##
##########################################################################################################################################





######################################################## SCRIPT INPUTS ###################################################################

######################################################
## CHANGE THIS TO CORRECT INPUT FILE                ##
######################################################
#filename <- "C:/Users/IBM_ADMIN/Downloads/CASE_FOCUS_RESUME.V1.2.csv"


##################################################### START OF SCRIPT ####################################################################

## Import the required R packages
#library(readr)
library(plyr)
library(sqldf)

## Read the input file
#inputdataset <- read_csv(filename)

## Transformation scripts
  dataset0 <- sqldf(
    "SELECT
    SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    EA_ID,
    EA_DEGREE,
    EA_SOURCE,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    Date(substr(SUBSTR(CASE_DT,1,10), 7, 4) || '-' || substr(SUBSTR(CASE_DT,1,10), 4, 2) || '-' || substr(SUBSTR(CASE_DT,1,10), 1, 2)) AS CASE_DT,
    CASE_STATUS,
	FLAG_CODE,
	DATE(CASE
		WHEN substr(FLAG_DATE, -5, 1) = '/'	and FLAG_DATE LIKE '%/%/%'
		THEN
		substr(FLAG_DATE, -4) 
		|| '-' ||
		substr('0' || substr(FLAG_DATE, 1, instr(FLAG_DATE, '/')-1), -2) 
		|| '-' ||
		substr('0' || substr(FLAG_DATE, instr(FLAG_DATE, '/')+1, length(FLAG_DATE)-5-instr(FLAG_DATE, '/')), -2)
		ELSE
		NULL
		END) AS FLAG_DATE,
	FLAG_VALUE,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
    CAST(PERSONAL_ACCTS_BIZ_PURPOSE_RESOLVED_FOCUS_RECENCY AS INTEGER) AS RESOLVED_FOCUS_RECENCY,
	PERSONAL_ACCTS_BIZ_PURPOSE_ENABLE AS ENABLE
	FROM inputdataset"
  )
  
  dataset1 <- sqldf(
  "SELECT *
  FROM dataset0
  WHERE ENABLE ='YES'")
  
  dataset2 <- sqldf(
    "SELECT *,
	CASE_NUM AS [INPUT.CASE_NUM],
	OPS_CENTER AS [INPUT.OPS_CENTER],
	DB_INSTANCE AS [INPUT.DB_INSTANCE]
    FROM dataset1
    WHERE
    EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'"
  )
  
  
  dataset3 <- sqldf(
    "SELECT *
    FROM dataset1
    WHERE
    EA_SOURCE = 'CASE_FLAG'
    AND EA_DEGREE = 0
	AND FLAG_VALUE = 'Y' 
	AND FLAG_CODE = 'USED_FOR_BUSINESS'"
  )
  
  dataset4 <- sqldf(
	"SELECT
	dataset2.EA_ID,
	dataset2.SOURCE_KEY,
	dataset2.CUST_ID,
	dataset2.ACCT_NUM,
	dataset2.CASE_DT AS [INPUT.CASE_DT],
	dataset2.RESOLVED_FOCUS_RECENCY,
	dataset2.[INPUT.CASE_NUM],
	dataset2.[INPUT.OPS_CENTER],
	dataset2.[INPUT.DB_INSTANCE],
	dataset3.DB_INSTANCE,
	dataset3.ACCT_NUM AS [HIST.ACCT_NUM],
	dataset3.CASE_NUM,
	dataset3.CASE_DT,
	dataset3.FLAG_CODE,
	dataset3.FLAG_DATE,
	dataset3.FLAG_VALUE,
	dataset3.OPS_CENTER,
	CASE
		WHEN (julianday(dataset3.FLAG_DATE) - julianday(dataset2.CASE_DT)) IS NULL
		THEN -1
		ELSE (julianday(dataset3.FLAG_DATE) - julianday(dataset2.CASE_DT))
	END AS RECENCY
	FROM 
	dataset2
	INNER JOIN
	dataset3
	USING (EA_ID)"
  )
  
  dataset5 <- sqldf(
  "SELECT *,
  CASE
	WHEN (RECENCY >= 0 AND RESOLVED_FOCUS_RECENCY = 999) THEN 'PERSONAL-ACCTS-BIZ-PURPOSE' 
	WHEN (RECENCY >= 0 AND RECENCY <= RESOLVED_FOCUS_RECENCY) THEN 'PERSONAL-ACCTS-BIZ-PURPOSE' 
	ELSE 'NONE' 
  END AS TRAN_INSIGHT_CODE
  FROM dataset4"
  )

  ###################################################
  #################SUPER NODE 1######################

  dataset6 <- sqldf(
  "SELECT *
  FROM dataset5
  ORDER BY DB_INSTANCE,CASE_NUM,OPS_CENTER")
  
  dataset6 <- sqldf(
  "SELECT *
  FROM dataset6
  WHERE TRAN_INSIGHT_CODE IS NOT 'NONE'
  GROUP BY
  DB_INSTANCE,
  CASE_NUM,
  OPS_CENTER
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )

  dataset7 <- sqldf(
  "SELECT *,
  ROWID AS ROWNUM,
  'CASE_NUM: ' || CASE_NUM || '; DB_INSTANCE: ' || DB_INSTANCE || '; OPS_CENTER: ' || OPS_CENTER || '; ACCT_NUM: ' || [HIST.ACCT_NUM] || '; FLAG_DATE: ' || FLAG_DATE AS [RESUME.CASE_NUM]
  FROM dataset6"
  )

  dataset8 <- sqldf(
  "SELECT *,
  CASE
  WHEN ROWNUM = 1
  THEN [RESUME.CASE_NUM]
  ELSE
  (SELECT [RESUME.CASE_NUM]
  FROM dataset7
  LIMIT -1
  OFFSET 1)
  || ', ' || [RESUME.CASE_NUM]
  END AS TEMP_VAR
  FROM dataset7"
  )
  
  dataset9 <- sqldf(
  "SELECT *,
  'Previous Cases: ' || TEMP_VAR AS TRAN_INSIGHT_MEMO
  FROM dataset8"
  )
  ##############END OF SUPER NODE 1##################
  ###################################################
  
  dataset10 <- sqldf(
  "SELECT *
  FROM dataset9
  ORDER BY EA_ID, TRAN_INSIGHT_MEMO DESC"
  )
  dataset10 <- sqldf(
  "SELECT *
  FROM dataset10
  GROUP BY EA_ID
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )
  
  dataset11 <- sqldf(
    "SELECT
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	CUST_ID,
	dataset10.[HIST.ACCT_NUM],
	dataset10.TRAN_INSIGHT_CODE,
	dataset10.TRAN_INSIGHT_MEMO,
	dataset2.ACCT_NUM,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID
    FROM
    dataset2
    LEFT JOIN
    dataset10
    USING (CASE_NUM,DB_INSTANCE,OPS_CENTER,CUST_ID)
	UNION 
	SELECT
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	CUST_ID,
	dataset10.[HIST.ACCT_NUM],
	dataset10.TRAN_INSIGHT_CODE,
	dataset10.TRAN_INSIGHT_MEMO,
	dataset2.ACCT_NUM,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID
    FROM
    dataset10
    LEFT JOIN
    dataset2
    USING (CASE_NUM,DB_INSTANCE,OPS_CENTER,CUST_ID)"
  )
  
  dataset12 <- sqldf(
    "SELECT
		CASE_NUM,
		DB_INSTANCE,
		OPS_CENTER,
		TRAN_INSIGHT_MEMO,
		CASE_FOCUS_ID,
		CASE_CPARTY_ID,
		CASE_ALERT_ID,
		'15' AS INSIGHT_ID,
		'100' AS INSIGHT_WEIGHT,
		'' AS CPARTY_ACCT_NUM,
		ACCT_NUM AS FOCUS_ACCT_NUM,
		CUST_ID AS FOCUS_CUST_ID,
		'' AS CPARTY_CUST_ID,
		'' AS TRAN_ID,
		'' AS TRAN_GROUP_KEY,
		'' AS TRAN_INSIGHT_CODE
	FROM dataset11"
  )
  
  dataset13 <- sqldf(
    "SELECT
	DB_INSTANCE,
	OPS_CENTER,
	CUST_ID AS FOCUS_CUST_ID,
	ACCT_NUM AS FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	'15' AS INSIGHT_ID,
	'100' INSIGHT_WEIGHT,
	'' AS CPARTY_ACCT_NUM,
	'' AS CPARTY_CUST_ID,
	'' AS TRAN_GROUP_KEY,
	'' AS TRAN_ID,
	'INSIGHT DISABLED' AS TRAN_INSIGHT_MEMO,
	'' AS TRAN_INSIGHT_CODE
    FROM dataset0
	WHERE ENABLE ='NO'
	AND EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'"
  )
  
  output15 <- sqldf(
  "SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset12
  UNION
  SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset13"
  )
  
  remove(
    dataset0,
	dataset1,
    dataset2,
	dataset3,
	dataset4,
    dataset5,
    dataset6,
	dataset7,
    dataset8,
    dataset9,
	dataset10,
    dataset11,
    dataset12,
	dataset13
  )
  
###################################################### END OF SCRIPT #####################################################################