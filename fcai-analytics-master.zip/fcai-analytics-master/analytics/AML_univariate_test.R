# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
rm(list=ls())
appName <- "FCAI_univariate_test"
source("AML_utils.R")

sc <- sparkConnect()

readAnalyticConfig(reset=TRUE)
args = commandArgs(trailingOnly=TRUE)
applyCommandLineFileArg("Transactions", args)
AML_scored_alerts_input <- validateScoredAlerts()

source("AML_aggregate1.R")
processFeatures()

allAnalytics <- AMLAnalyticConfig$Analytics
for (i in 1:length(allAnalytics)) {
  if (allAnalytics[[i]]$Type == "Univariate") {
    message(paste0("******* Found Univariate (index ",i,") - ",
      allAnalytics[[i]]$Results$ReasonType))
    parms <- unlist(allAnalytics[[i]])

    source(parms["Source"])

    # execute score banding function
    func <- match.fun(parms["BandingFunction"])
    bands <- func(parms=allAnalytics[[i]])
    print(head(bands), width=Inf)

    # execute assessment function
    func = match.fun(parms["AssessmentFunction"])
    message("\n\n***** Running assessment for full dataset *****\n")
    dfData <- tbl_df(loadData(allAnalytics[[i]]$InputSource$Type,
      allAnalytics[[i]]$InputSource$AggregateName))
    dfDataIDCol <- colnames(dfData)[[1]]
    dfData <- dfData %>% arrange_(dfDataIDCol)
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(head(scores), width=Inf)

    message("\n\n***** Running assessment for first 100 elements dataset *****\n")
    dfData <- dfData[1:100,]
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(head(scores), width=Inf)

    message("\n\n***** Running assessment for first element only *****\n")
    dfData <- dfData[1,]
    scores <- func(parms=allAnalytics[[i]], dfData=dfData)
    print(head(scores), width=Inf)
  }
}
