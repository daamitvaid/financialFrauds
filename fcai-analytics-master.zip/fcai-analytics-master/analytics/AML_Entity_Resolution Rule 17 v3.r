

#################################### SPSS G2 ENTITY RESOLUTION STREAM TRANSLATION ########################################################
##                                                                                                                                      ##
## The script below translates super node 17 of G2 SPSS stream CASE_FOCUS_SIT.v12 into R scripts #########################################
## This rule has a logic different to the other supernodes and thus has been coded separately ############################################
## The script takes in the CASE_FOCUS_RESUME.V12.csv as an input file and generates and outputdataset similar to the G2 SPSS stream ######
## The function is implemented using R library sqldf using SQLite scripts. If required a DB2 SQL script can replace the R script below ###
##                                                                                                                                      ##
##                                                                                                                                      ##
##                                                                                                                                      ##
## DEVELOPED BY : ANISH DIXIT                                                                                        DATE : 08-OCT-2017 ##
##########################################################################################################################################





######################################################## SCRIPT INPUTS ###################################################################

######################################################
## CHANGE THIS TO CORRECT INPUT FILE                ##
######################################################
#filename <- "C:/Users/IBM_ADMIN/Downloads/CASE_FOCUS_RESUME.V1.2.csv"


##################################################### START OF SCRIPT ####################################################################

## Import the required R packages
#library(readr)
library(plyr)
library(sqldf)

## Read the input file
#inputdataset <- read_csv(filename)

## Transformation scripts
  dataset0 <- sqldf(
    "SELECT
	SOURCE_CODE,
    SOURCE_KEY,
    DB_INSTANCE,
    EA_ID,
    EA_DEGREE,
    EA_SOURCE,
    EA_SOURCE_KEY,
    CUST_ID,
    ACCT_NUM,
    CASE_NUM,
    Date(substr(SUBSTR(CASE_DT,1,10), 7, 4) || '-' || substr(SUBSTR(CASE_DT,1,10), 4, 2) || '-' || substr(SUBSTR(CASE_DT,1,10), 1, 2)) AS CASE_DT,
    CASE_STATUS,
	EQUIV_DISP_CODE,
	ANY_TRAN_ESCALATED,
	DATE(CASE
		WHEN substr(ACCT_OPEN_DT, -5, 1) = '/' AND ACCT_OPEN_DT LIKE '%%/%%/%%'
		THEN
		substr(ACCT_OPEN_DT, -4) 
		|| '-' ||
		substr('0' || substr(ACCT_OPEN_DT, 1, instr(ACCT_OPEN_DT, '/')-1), -2) 
		|| '-' ||
		substr('0' || substr(ACCT_OPEN_DT, instr(ACCT_OPEN_DT, '/')+1, length(ACCT_OPEN_DT)-5-instr(ACCT_OPEN_DT, '/')), -2)
		ELSE
		NULL
	END) AS ACCT_OPEN_DT,
	ACCT_STATUS,
	DATE(CASE
		WHEN substr(ACCT_STATUS_DT, -5, 1) = '/' AND ACCT_STATUS_DT LIKE '%%/%%/%%'
		THEN
		substr(ACCT_STATUS_DT, -4) 
		|| '-' ||
		substr('0' || substr(ACCT_STATUS_DT, 1, instr(ACCT_STATUS_DT, '/')-1), -2) 
		|| '-' ||
		substr('0' || substr(ACCT_STATUS_DT, instr(ACCT_STATUS_DT, '/')+1, length(ACCT_STATUS_DT)-5-instr(ACCT_STATUS_DT, '/')), -2)
		ELSE
		NULL
	END) AS ACCT_STATUS_DT,
    OPS_CENTER,
    CASE_FOCUS_ID,
    CASE_CPARTY_ID,
    CASE_ALERT_ID,
	PREV_CLOSED_ACCTS_DURATION AS DURATION,
	PREV_CLOSED_ACCTS_RESOLVED_FOCUS_RECENCY AS RESOLVED_FOCUS_RECENCY,
	PREV_CLOSED_ACCTS_ENABLE AS ENABLE
	FROM inputdataset"
  )
  
  dataset1 <- sqldf(
  "SELECT *
  FROM dataset0
  WHERE ENABLE ='YES'")
  
  dataset2 <- sqldf(
    "SELECT *
    FROM dataset1
    WHERE
    EA_SOURCE = SOURCE_CODE
    AND EA_SOURCE_KEY = SOURCE_KEY
    AND CASE_STATUS = 'I'"
  )

  dataset3 <- sqldf(
    "SELECT *
    FROM dataset1
    WHERE
    EA_DEGREE = 0
	AND ACCT_STATUS = 'C'"
  )

  dataset4 <- sqldf(
	"SELECT
	EA_ID,
	dataset2.DB_INSTANCE,
	dataset2.CASE_NUM,
	dataset2.OPS_CENTER,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID,
	dataset2.DURATION,
	dataset2.RESOLVED_FOCUS_RECENCY,
	dataset3.SOURCE_CODE,
	dataset3.SOURCE_KEY,
	dataset3.DB_INSTANCE AS [HIST.DB_INSTANCE],
	dataset3.EA_SOURCE,
	dataset3.EA_SOURCE_KEY,
	dataset3.CUST_ID,
	dataset3.ACCT_NUM,
	dataset3.ACCT_OPEN_DT,
	dataset3.ACCT_STATUS,
	dataset3.ACCT_STATUS_DT,
	dataset3.OPS_CENTER AS [HIST.OPS_CENTER]
	FROM 
	dataset2
	INNER JOIN
	dataset3
	USING (EA_ID)"
  )
  
  dataset5 <- sqldf(
  "SELECT *,
  	CASE 
	WHEN (julianday(ACCT_OPEN_DT) - julianday(ACCT_STATUS_DT)) IS NULL
	THEN -1
	ELSE (julianday(ACCT_OPEN_DT) - julianday(ACCT_STATUS_DT))
	END AS ACCOUNT_DURATION
  FROM dataset4"
  )
  
  dataset6 <- sqldf(
  "SELECT
	EA_ID,
	dataset2.SOURCE_CODE,
	dataset2.SOURCE_KEY,
	dataset2.DB_INSTANCE,
	dataset2.EA_SOURCE,
	dataset2.EA_SOURCE_KEY,
	dataset2.CUST_ID,
	dataset2.CASE_NUM,
	dataset2.CASE_DT AS [INPUT.CASE_DT],
	dataset2.CASE_STATUS,
	dataset2.EQUIV_DISP_CODE,
	dataset2.ANY_TRAN_ESCALATED,
	dataset2.OPS_CENTER,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID,
	dataset5.DURATION,
	dataset5.RESOLVED_FOCUS_RECENCY,
	dataset5.[HIST.DB_INSTANCE],
	dataset5.ACCT_NUM,
	dataset5.ACCT_OPEN_DT,
	dataset5.ACCT_STATUS,
	dataset5.ACCT_STATUS_DT,
	dataset5.[HIST.OPS_CENTER],
	dataset5.ACCOUNT_DURATION
  FROM
	dataset2
	LEFT JOIN
	dataset5
	USING(EA_ID)
  UNION
  SELECT
	EA_ID,
	dataset2.SOURCE_CODE,
	dataset2.SOURCE_KEY,
	dataset2.DB_INSTANCE,
	dataset2.EA_SOURCE,
	dataset2.EA_SOURCE_KEY,
	dataset2.CUST_ID,
	dataset2.CASE_NUM,
	dataset2.CASE_DT AS [INPUT.CASE_DT],
	dataset2.CASE_STATUS,
	dataset2.EQUIV_DISP_CODE,
	dataset2.ANY_TRAN_ESCALATED,
	dataset2.OPS_CENTER,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID,
	dataset5.DURATION,
	dataset5.RESOLVED_FOCUS_RECENCY,
	dataset5.[HIST.DB_INSTANCE],
	dataset5.ACCT_NUM,
	dataset5.ACCT_OPEN_DT,
	dataset5.ACCT_STATUS,
	dataset5.ACCT_STATUS_DT,
	dataset5.[HIST.OPS_CENTER],
	dataset5.ACCOUNT_DURATION
  FROM 
	dataset5
	LEFT JOIN
	dataset2
	USING(EA_ID)"
  )
  
  dataset7 <- sqldf(
  "SELECT *,
	CASE 
	WHEN (julianday(ACCT_OPEN_DT) - julianday([INPUT.CASE_DT])) IS NULL
	THEN -1
	ELSE (julianday(ACCT_OPEN_DT) - julianday([INPUT.CASE_DT]))
	END AS RECENCY
  FROM dataset6"
  )
  
  dataset8 <- sqldf(
  "SELECT *,
	CASE
		WHEN (RECENCY >= 0 AND RESOLVED_FOCUS_RECENCY = 999) THEN 'YES' 
		WHEN (RECENCY >= 0 AND RECENCY <= RESOLVED_FOCUS_RECENCY) THEN 'YES' 
		ELSE 'NO' 
	END AS RECENCY_ELIGIBILITY
  FROM dataset7"
  )
  
  dataset9 <- sqldf(
  "SELECT *,
  CASE
	WHEN (RECENCY_ELIGIBILITY = 'YES' AND ACCOUNT_DURATION <= DURATION) THEN 'PREV-CLOSED-ACCTS' 
	ELSE 'NONE' 
  END AS TRAN_INSIGHT_CODE
  FROM dataset8"
  )
  
  dataset10 <- sqldf(
  "SELECT *,
  ACCT_NUM AS [RESUME.CASE_NUM],
  ROWID AS ROWNUM
  FROM dataset9
  WHERE TRAN_INSIGHT_CODE IS NOT 'NONE'"
  )
  
  dataset11 <- sqldf(
  "SELECT
	*,
	CASE
		WHEN ROWNUM = 1 THEN [RESUME.CASE_NUM]
		ELSE
		(SELECT [RESUME.CASE_NUM]
		FROM dataset10
		LIMIT -1
		OFFSET 1)
		|| ', ' || [RESUME.CASE_NUM]
	END AS TEMP_VAR
  FROM dataset10"
  )
  
  dataset12 <- sqldf(
  "SELECT 
		*,
		CASE
			WHEN TRAN_INSIGHT_CODE = 'CASE_DT_ERROR' THEN 'CASE-DATE-INVALID' 
			WHEN TRAN_INSIGHT_CODE = 'PREV-CLOSED-ACCTS' THEN 'Closed Accounts; ' || TEMP_VAR
			ELSE NULL 
		END AS TRAN_INSIGHT_MEMO
  FROM dataset11"
  )
  
  dataset13 <- sqldf(
  "SELECT *
  FROM dataset12
  ORDER BY CASE_NUM, TRAN_INSIGHT_MEMO DESC"
  )
  dataset13 <- sqldf(
  "SELECT *
  FROM dataset13
  GROUP BY CASE_NUM
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )
  
  dataset14 <- sqldf(
  "SELECT 
	DB_INSTANCE,
	CASE_NUM,
	OPS_CENTER,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO
  FROM dataset13
  WHERE TRAN_INSIGHT_CODE= 'PREV-CLOSED-ACCTS' 
  AND EA_SOURCE = SOURCE_CODE AND EA_SOURCE_KEY = SOURCE_KEY and CASE_STATUS = 'I'
  GROUP BY TRAN_INSIGHT_CODE,TRAN_INSIGHT_MEMO,OPS_CENTER,DB_INSTANCE,CASE_NUM
  HAVING MIN(ROWID)
  ORDER BY ROWID"
  )
  
  dataset15 <- sqldf(
  "SELECT 
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	dataset2.CUST_ID AS FOCUS_CUST_ID,
	dataset2.ACCT_NUM AS FOCUS_ACCT_NUM,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID,
	dataset14.TRAN_INSIGHT_CODE,
	dataset14.TRAN_INSIGHT_MEMO
  FROM 
	dataset2
	LEFT JOIN
	dataset14
	USING(CASE_NUM,DB_INSTANCE,OPS_CENTER)
  UNION
  SELECT 
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	dataset2.CUST_ID AS FOCUS_CUST_ID,
	dataset2.ACCT_NUM AS FOCUS_ACCT_NUM,
	dataset2.CASE_FOCUS_ID,
	dataset2.CASE_CPARTY_ID,
	dataset2.CASE_ALERT_ID,
	dataset14.TRAN_INSIGHT_CODE,
	dataset14.TRAN_INSIGHT_MEMO
  FROM 
	dataset14
	LEFT JOIN
	dataset2
	USING(CASE_NUM,DB_INSTANCE,OPS_CENTER)"
  )
  
  dataset16 <- sqldf(
  "SELECT *,
	'100' AS INSIGHT_WEIGHT,
	'17' AS INSIGHT_ID,
	'' AS CPARTY_ACCT_NUM,
	'' AS CPARTY_CUST_ID,
	'' AS TRAN_ID,
	'' AS TRAN_GROUP_KEY
  FROM dataset15"
  )
  
  dataset17 <- sqldf(
  "SELECT 
	CASE_NUM,
	DB_INSTANCE,
	OPS_CENTER,
	CUST_ID AS FOCUS_CUST_ID,
	ACCT_NUM AS FOCUS_ACCT_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	'' AS TRAN_INSIGHT_CODE,
	'INSIGHT DISABLED' AS TRAN_INSIGHT_MEMO,
		'100' AS INSIGHT_WEIGHT,
	'17' AS INSIGHT_ID,
	'' AS CPARTY_ACCT_NUM,
	'' AS CPARTY_CUST_ID,
	'' AS TRAN_ID,
	'' AS TRAN_GROUP_KEY
  FROM dataset0
  WHERE 
	ENABLE='NO'
	AND EA_SOURCE = SOURCE_CODE 
	AND EA_SOURCE_KEY = SOURCE_KEY 
	AND CASE_STATUS = 'I'"
  )
  
  output17 <- sqldf(
  "SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset17
  UNION ALL
  SELECT 
	DB_INSTANCE,
	OPS_CENTER,
	FOCUS_CUST_ID,
	FOCUS_ACCT_NUM,
	CASE_NUM,
	CASE_FOCUS_ID,
	CASE_CPARTY_ID,
	CASE_ALERT_ID,
	TRAN_INSIGHT_CODE,
	TRAN_INSIGHT_MEMO,
	INSIGHT_ID,
	INSIGHT_WEIGHT,
	CPARTY_ACCT_NUM	,
	CPARTY_CUST_ID,
	TRAN_GROUP_KEY,
	TRAN_ID
  FROM dataset16"
  )
  ###################################################

  ###################################################
  

  remove(
    dataset0,
	dataset1,
    dataset2,
	dataset3,
	dataset4,
    dataset5,
    dataset6,
	dataset7,
    dataset8,
    dataset9,
	dataset10,
    dataset11,
    dataset12,
	dataset13,
	dataset14,
	dataset15,
	dataset16,
	dataset17
  )
  
###################################################### END OF SCRIPT #####################################################################