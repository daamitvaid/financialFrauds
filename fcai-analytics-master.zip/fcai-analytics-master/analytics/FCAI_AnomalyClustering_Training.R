# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

#install.packages("codetools")
#install.packages("caret")
#install.packages("NbClust")
#install.packages("data.table")

library(caret)
library(NbClust)
library(data.table)
library(codetools)

###PARAMETERS THAT CAN BE MODIFIED IN THE CODE
# 1. Correlation cut off point at line 35
# 2. Min and Max number of clusters at line 46
# 3. Methodology of calculating the number of clusters (index = "silhouette") line 46
# 4. Methodology for clustering ( method = "kmeans") line 46
# 5. Methodology for calculating the distance to cluster mean (distance = "euclidean") line 46

#Part 1
#default parameters
Thrd_GII = ifelse(!is.null(clusteringConfig$Thrd_GII),clusteringConfig$Thrd_GII,0.7);   #threshold for GII
Thrd_Crlt = ifelse(!is.null(clusteringConfig$Thrd_Crlt),clusteringConfig$Thrd_Crlt,0.9);   #threshold of correlation cutoff
message(paste("Threshold for GII (Thrd_GII):",Thrd_GII))
message(paste("Threshold of correlation cutoff (Thrd_Crlt):",Thrd_Crlt))

###Preparing data for analysis
dfData <- tbl_df(loadAnalyticInput(clusteringConfig$InputSource))
dfDataIDCol <- colnames(dfData)[[1]]

#spliting the data into training and testing
ind <- sample(2, nrow(dfData), replace=TRUE, prob=c(0.90, 0.10))

#training will take part in intital clustering
#we will use test for assigning cluster labels to the data
train <- dfData[ind==1,]
test <- dfData[ind==2,]

dfData<-train
rm(train)

#weight from univariate
VarGII <- data.frame(loadData(clusteringConfig$InputSource$Type,
  clusteringConfig$InputSource$AggregateName, GII=TRUE), stringsAsFactors=FALSE)

#we want to include in our clustering variables with GII (weight) > 0.6
VarGIIrds <- filter(VarGII, GII> Thrd_GII)
GIIlist <- VarGIIrds[c(1)]
#we are subseting for only variables with weights >0.6
myvars <- names(dfData) %in% ((GIIlist[,c(1)]))
rdsdt <- dfData[myvars]

#merging back to dfData to re-add id
rdsdt<-cbind(rdsdt,dfData[c(dfDataIDCol)])

#creating new table, fill missing value with average
df <- doNAaggregate(rdsdt)
rm(rdsdt)

#converting id to character variable
df[,dfDataIDCol] = as.character(df[,dfDataIDCol])

#preprocess the data
#preprocessParams <- preProcess(dtData, method=c("scale"))
#preprocessParams <- preProcess(dtData, method=c("center"))
##ask Christina --> what does this do? does this standardize the fields? we need to remember that
##we standardize for the clustering but then we need to use normal values
#preprocessParams <- preProcess(dfDatards, method=c("center", "scale"))
#preprocessParams <- preProcess(dtData, method=c("range"))
#preprocessParams <- preProcess(dtData, method=c("BoxCox"))
#preprocessParams <- preProcess(dtData, method=c("center", "scale", "pca"))
#df <- predict(preprocessParams, dfDatards)
#rm(dfDatards)

#defining the id as index
row.names(df)<-df[,dfDataIDCol]

#removing id as we need to exlude in the clustering
df[[dfDataIDCol]]<-NULL

#converting variables to numeric
df<- as.data.frame(apply(df,2,function(x)as.numeric(x)), row.names = rownames(df))

#before doing anything remove all the variables which are almost constant
#ie variance is close to 0
#df <- df[,-caret::nearZeroVar(df)]
df<-df[,sapply(df, function(v) var(v, na.rm=TRUE)>1)]

#before proceeding remove correlated fields
#cutoff point is a parameter which can be adjusted
#set it higher to be more conservative
#nonCorrelatedData <- df[, -caret::findCorrelation(cor(df[,-1]), cutoff = 0.5)]
corMatrix <- cor(df)
nonCorrelatedData <- df[, -caret::findCorrelation(corMatrix, cutoff = Thrd_Crlt)]
corMatrix <- cbind(corMatrix, varName = colnames(corMatrix))

#standardize the fields
standardizedData <- as.data.frame(round(scale(nonCorrelatedData),2))

storeWithRownames(nonCorrelatedData,
  getAnomalyClusterFileName(clusteringConfig,"nonCorrelatedData","csv"),
  "nonCorrelatedData", dfDataIDCol)
storeWithRownames(standardizedData,
  getAnomalyClusterFileName(clusteringConfig,"standardizedData","csv"),
  "standardizedData", dfDataIDCol)
storeOutput(copy_to(sc,test,overwrite=TRUE),
  name=getAnomalyClusterFileName(clusteringConfig,"test","csv"), type="csv",
  path=AMLAnalyticConfig$DataDirectory)
storeOutput(copy_to(sc,dfData,overwrite=TRUE),
  name=getAnomalyClusterFileName(clusteringConfig,"train","csv"), type="csv",
  path=AMLAnalyticConfig$DataDirectory)
storeOutput(copy_to(sc,corMatrix,overwrite=TRUE),
  name=getAnomalyClusterFileName(clusteringConfig,"corMatrix","csv"), type="csv",
  path=AMLAnalyticConfig$DataDirectory)

rm(df)

# Part 2
nonCorrelatedData$cluster <- NULL # clear this column just in case
minClust <- ifelse(!is.null(clusteringConfig$minClust),clusteringConfig$minClust,15)
maxClust <- ifelse(!is.null(clusteringConfig$maxClust),clusteringConfig$maxClust,30)
optClust <- ifelse(!is.null(clusteringConfig$optClust),clusteringConfig$optClust,0)

#performing kmeans clustering; NbClust finds optimum number of clusters using silhouette method
#res <- NbClust(standardizedData[], diss=NULL, distance = "euclidean",min.nc=15, max.nc=30,
#                method = "kmeans", index = "silhouette" )
if (optClust <= 0 ) {
  spark_standardizedData <- copy_to(sc,standardizedData,overwrite=TRUE)
  featureNames <- colnames(standardizedData)
  results <- vector()
  noOfClust <- c(minClust:maxClust)

  for (i in noOfClust) {
    spark_kmeans <- ml_kmeans(spark_standardizedData,centers = i, features = featureNames, iter.max = 100)
    #print(ml_compute_cost(spark_kmeans,spark_standardizedData))
    results <- c(results, spark_kmeans$cost)
  }

  optClust <- noOfClust[which.min(diff(results))+1]
  rm(spark_kmeans)
  rm(spark_standardizedData)

  plotClust <- data.frame(noOfClust=noOfClust,sumOfSquaredWihtinClust=results)
  storeOutput(copy_to(sc,plotClust,overwrite=TRUE),
              name=getAnomalyClusterFileName(clusteringConfig,"clustPlot","csv"), type="csv",
              path=AMLAnalyticConfig$DataDirectory)
}

#now we are using the best number of clusters in the kmeans calculation
fit.km<-kmeans(nonCorrelatedData,optClust, nstart=25)

res <- list(Best.nc=optClust)

#adding cluster number to dfData table
nonCorrelatedData$cluster <- fit.km$cluster

storeWithRownames(nonCorrelatedData,
  getAnomalyClusterFileName(clusteringConfig,"nonCorrelatedData","csv"),
  "nonCorrelatedData", dfDataIDCol)
storeOutput("res",
  name=getAnomalyClusterFileName(clusteringConfig,"model","rda"), type="rda")

rm(fit.km)

#Part 3
#converting back to a data frame
nonCorrelatedData<-as.data.frame(nonCorrelatedData)
nonCorrelatedData[[dfDataIDCol]] <- rownames(nonCorrelatedData)

#merge with data table
dfData <- merge(dfData,
  nonCorrelatedData[,which(names(nonCorrelatedData) %in%
    c("cluster",dfDataIDCol))],
  by=dfDataIDCol,all.x = TRUE )

##########anomaly detection on entiyt level #########################

nonCorrelatedData$cluster <- as.factor(nonCorrelatedData$cluster)

#looping through the clusters to calculate each entity's distance from the cluster mean
#then calculating l2 norm (anomaly index)
#finally creating a tag which defines whether a entity is anomalous within the
df_anomaly <- data.frame()
for (i in levels(nonCorrelatedData$cluster)) {

  if (nrow(nonCorrelatedData[nonCorrelatedData$cluster == i,]) >= 2) {

    x <- nonCorrelatedData[nonCorrelatedData$cluster == i,
      -which(names(nonCorrelatedData) %in% c(dfDataIDCol,"cluster"))]
    # New line:
    x_custID <- nonCorrelatedData[nonCorrelatedData$cluster == i,
      dfDataIDCol, drop = FALSE]
    #dat works fine - double checked
    #dat <- as.data.frame(apply(x, 2, function(x) {round(x-mean(x), 2)}))
    dat <- (as.data.frame(apply(x, 2, function(x) round((x-mean(x))/sd(x), 2))))
    #calculate the L2 norm
    dat$l2norm <- apply(dat, 1, function(x)round(sqrt(sum(x^2)),2))
    #normalising l2 norm
    dat$Anomaly <- ifelse(dat$l2norm > mean(dat$l2norm) + 2*sd(dat$l2norm), 1, 0)

    dat$cluster <-  rep(i, dim(dat)[1])
    # New line:
    dat[[dfDataIDCol]] <- x_custID[[dfDataIDCol]]
  } else {
    dat <- nonCorrelatedData[nonCorrelatedData$cluster == i,]
    dat$l2norm <- 1000
    dat$Anomaly <- rep(1, nrow(dat))
  }
  df_anomaly <- rbind(df_anomaly, dat)
}

#df_anomaly<-df_anomaly[,-which(names(df_anomaly) %in% c("AnomalyIndex"))]
names(df_anomaly)[names(df_anomaly) == 'l2norm'] <- 'AnomalyIndex'
if (isDebug(clusteringConfig)) {
  message(createDataHeader("df_anomaly"))
  print(head(df_anomaly))
}

#merging back to table
dfData <- merge(dfData,
  df_anomaly[,which(names(df_anomaly) %in% c("Anomaly","AnomalyIndex",dfDataIDCol))],
  by=dfDataIDCol,all.x = TRUE )

###############factor sensitivity analysis###################

#creating index out of entity id and getting rid of entity id as a result
#we need to get rid of entity id to get df_rank but we need to keep track of it when we will merge by to dfData
row.names(df_anomaly)<-as.character(df_anomaly[[dfDataIDCol]])
df_anomaly[[dfDataIDCol]]<-NULL

#we subset the data now into people who are anomalous and who are not
#we deal with them separately
df_rank_anomaly<-subset(df_anomaly,Anomaly == 1)
df_rank_nonanomaly<-subset(df_anomaly,Anomaly == 0)

#we getting rid of variables we do not need
df_rank_anomaly<-df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("AnomalyIndex","Anomaly","cluster"))]
df_rank_nonanomaly<-df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("AnomalyIndex","Anomaly","cluster"))]

#we create new tables as these will be used for defining contributor reasons
#we do it that way because for contributors reasons we need real data
#for contributors themselves we will be looking at absolute values
df_ano_reasons<-df_rank_anomaly
df_nonano_reasons<-df_rank_nonanomaly

#looking at REASONS FOR CONTRIBUTORS in anomaly data
#we define reasons as the values which are the furthest away from the mean
df_ano_reasons$FirstContReason<-apply(df_ano_reasons, 1,function(x) { x[which.max( abs(x) )]})

df_ano_reasons$SecondContReason<-apply(df_ano_reasons[,-which(names(df_ano_reasons) %in% c("FirstContReason"))],1
                                       ,function(x) {x[which(rev(sort(abs(x)))[2] == abs(x))][1]})

df_ano_reasons$ThirdContReason<-apply(df_ano_reasons[,-which(names(df_ano_reasons) %in% c("FirstContReason","SecondContReason"))],1
                                      ,function(x) {x[which(rev(sort(abs(x)))[3] == abs(x))][1]})


#looking at reasons for contributors in nonanomaly data
#we define contributors reasons as values the closest to the mean
df_nonano_reasons$FirstContReason<-apply(df_nonano_reasons, 1, function(x){ x[which.min( abs(x) )]})

df_nonano_reasons$SecondContReason <- apply(df_nonano_reasons[,-which(names(df_nonano_reasons) %in%
                                                                        c("FirstContReason"))], 1,
                                            function(x) {x[which(sort(unique(abs(x)))[2] == abs(x))][1]})

df_nonano_reasons$ThirdContReason <- apply(df_nonano_reasons[,-which(names(df_nonano_reasons) %in%
                                                                       c("FirstContReason", "SecondContReason"))], 1,
                                           function(x) {x[which(sort(unique(abs(x)))[3] == abs(x))][1]})


#combined reasons for anomaly and non anomaly into one table
df_reasons<-rbind(df_nonano_reasons,df_ano_reasons)
df_reasons<-df_reasons[,which(names(df_nonano_reasons) %in%
                                c("FirstContReason","SecondContReason","ThirdContReason",dfDataIDCol))]

#get entity ids from row names
setDT(df_reasons, keep.rownames = TRUE)[]
names(df_reasons)[names(df_reasons) == 'rn'] <- dfDataIDCol

#get rid of redundant tables
rm(df_nonano_reasons,df_ano_reasons)

#NOW WE WILL BE GENERATING 3 CONTRIBUTORS
#convert values to absolute values
df_rank_anomaly<-abs(df_rank_anomaly)
df_rank_nonanomaly<-abs(df_rank_nonanomaly)

#creating a data which ranks the columns
df_rank_anomaly<-as.data.frame(t(apply(df_rank_anomaly,1,function(x)rank(-x, ties.method = "first"))))
df_rank_nonanomaly<-as.data.frame(t(apply(df_rank_nonanomaly,1,function(x)rank(x, ties.method = "first"))))

#creating new columns for top 3 first contributors to anomaly/NONANOMALY
num_contributor <- max(apply(df_rank_anomaly,2,function(x)length(unique(x))))
if (num_contributor >= 1) {
  df_rank_anomaly$First_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly, 1, function(x)which(x==1))]
}
if (num_contributor >= 2) {
  df_rank_anomaly$Second_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("First_Contributor"))], 1, function(x)which(x==2))]
}
if (num_contributor >= 3) {
  df_rank_anomaly$Third_Contributor<-colnames(df_rank_anomaly)[apply(df_rank_anomaly[,-which(names(df_rank_anomaly) %in% c("First_Contributor","Second_Contributor"))], 1, function(x)which(x==3))]
}

num_contributor_no <- max(apply(df_rank_nonanomaly,2,function(x)length(unique(x))))
if (num_contributor_no >= 1) {
  df_rank_nonanomaly$First_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly, 1, function(x)which(x==1))]
}
if (num_contributor_no >= 2) {
  df_rank_nonanomaly$Second_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("First_Contributor"))], 1, function(x)which(x==2))]
}
if (num_contributor_no >= 3) {
  df_rank_nonanomaly$Third_Contributor<-colnames(df_rank_nonanomaly)[apply(df_rank_nonanomaly[,-which(names(df_rank_nonanomaly) %in% c("First_Contributor","Second_Contributor"))], 1, function(x)which(x==3))]
}

#Combining both tabes together
df_rank<-rbind(df_rank_nonanomaly,df_rank_anomaly)

#bring back entity id to the df_rank
setDT(df_rank, keep.rownames = TRUE)[]
names(df_rank)[names(df_rank) == 'rn'] <- dfDataIDCol

#df_rank changing back to data frame
df_rank<-as.data.frame(df_rank)

#merging back to reasons
df_rank_reasons<-merge(df_rank, df_reasons, by=dfDataIDCol,all.x = TRUE)

#merging back to data table
dfData <- merge(dfData, df_rank_reasons[,which(names(df_rank_reasons) %in% c("First_Contributor", "Second_Contributor","Third_Contributor",dfDataIDCol,
                                                                                         "FirstContReason","SecondContReason","ThirdContReason"))], by=dfDataIDCol,all.x = TRUE )

#testing
#df<-as.data.frame(df)
#yo<-as.data.frame(merge(df,df_rank[,which(names(df_rank) %in% c("First_Contributor",
#   "Second_Contributor","Third_Contributor","dfData"))]
#,by="dfDataIDCol",all.x = TRUE))


#setDT(df_anomaly, keep.rownames = TRUE)[]
#names(df_anomaly)[names(df_anomaly) == 'rn'] <- 'dfDataIDCol'
#df_anomaly<-as.data.frame(df_anomaly)
#yo2<-merge(yo, df_anomaly[,which(names(df_anomaly) %in% c("AnomalyIndex","Anomaly",dfDataIDCol))],
#           by=dfDataIDCol, all.x = TRUE )
#write.csv(yo2,"yo2.csv")
#remove tables
#rm(dat,df_rank,x,dtData,x_custID,df_rank_anomaly,df_rank_nonanomaly,df_anomaly,df_rank_reasons,df_reasons)

#rm(GIIlist,rdsdt, VarGII, VarGIIrds)

if (isDebug(clusteringConfig)) {
  message(createDataHeader("trained data"))
  print(head(dfData))
}
storeOutput(copy_to(sc,dfData,overwrite=TRUE),
  name=getAnomalyClusterFileName(clusteringConfig,"train","csv"), type="csv",
  path=AMLAnalyticConfig$DataDirectory)
