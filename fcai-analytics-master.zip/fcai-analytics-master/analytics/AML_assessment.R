# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

runScoringBands <- function() {
  allAnalytics <- AMLAnalyticConfig$Analytics
  for (i in 1:length(allAnalytics)) {
    message(paste0("******* Found ",allAnalytics[[i]]$Type," (index ",i,") - ",
      allAnalytics[[i]]$Results$ReasonType))
    parms <- unlist(allAnalytics[[i]])

    if (!is.null(parms["BandingFunction"]) && !is.na(parms["BandingFunction"]) &&
      nchar(trimws(parms["BandingFunction"])) > 0) {

      source(parms["Source"])

      # execute score banding function
      func <- match.fun(parms["BandingFunction"])
      if (!is.null(func)){
        bands <- func(parms=allAnalytics[[i]])
        message(paste("\n===========================",
          allAnalytics[[i]]$Results$ReasonType,"Bands ==========================="))
        print(head(bands), width=Inf)
        message()
      }
    }
  }
  scoredTx <- calculateTransactionScores(loadData("Transactions"),applyERfilter=FALSE)
  scoredTx <- addOverallScore(scoredTx, populateReasonsDf())
  bands <- writeBandThresholds(scoredTx$OverallScore, reasonType="Overall")
  message(paste("\n=========================== Overall Bands ==========================="))
  print(head(bands), width=Inf)
  message()
}

calculateTransactionScores <- function(dfData, applyERfilter=TRUE) {
  allAnalytics <- AMLAnalyticConfig$Analytics
  txIdColumn <- getColumnName("Transactions","IDColumn")
  for (i in 1:length(allAnalytics)) {
    message(paste0("******* Processing ",allAnalytics[[i]]$Type," (index ",i,") - ",
      allAnalytics[[i]]$Results$ReasonType))
    flatparms <- unlist(allAnalytics[[i]])

    if (!is.null(flatparms["AssessmentFunction"]) && !is.na(flatparms["AssessmentFunction"]) &&
      nchar(trimws(flatparms["AssessmentFunction"])) > 0) {

      source(flatparms["Source"])

      # execute assessment function
      func = match.fun(flatparms["AssessmentFunction"])
      if(!is.null(func))
      {

        # find the input source
        if (is.null(allAnalytics[[i]]$InputSource$SourceType)) {
          inputsource <- allAnalytics[[i]]$InputSource[[1]]
        } else {
          inputsource <- allAnalytics[[i]]$InputSource
        }

        if (inputsource$SourceType=="File") {
          scores <- func(parms=allAnalytics[[i]], dfData=dfData)
          if (!is.null(inputsource$IDColumns) & length(inputsource$IDColumns)) {
            idColumns <- getColumnNames(inputsource$Type,inputsource$IDColumns)
          } else {
            idColumns <- txIdColumn
          }
          dfData <- merge(x=dfData,y=scores,by=idColumns,all.x=TRUE)
          # print(scores)
          # print(dfData, width=Inf)
        } else if (inputsource$SourceType=="Aggregate" && applyERfilter) {
          idColumns <- getAggregateByColumnNames(inputsource$Type, inputsource$AggregateName)
          allIds <- select(dfData, idColumns)
          if (!is.null(ncol(allIds))) {
            allIds <- allIds[[1]]
          }
          allIds <- unique(allIds)
          resolvedEntities <- FALSE
          filterIds <- allIds
          if (!is.null(allAnalytics[[i]]$ResolveEntities) &&
              allAnalytics[[i]]$ResolveEntities) {
            resolvedEntities <- TRUE
            if (!exists("resolvedIds")) {
              resolvedIds <- getResolvedEntities(allIds)
              colnames(resolvedIds)[2] <- idColumns[1]
              multiIds <-  resolvedIds %>% group_by(entityId) %>% filter(n()>1)
            }
            filterIds <- resolvedIds[[2]]
          }
          filterCriteria = paste(idColumns[1],"%in% filterIds")
          aggData <- tbl_df(loadData(inputsource$Type, inputsource$AggregateName) %>% filter_(.dots = filterCriteria))
          scores <- func(parms=allAnalytics[[i]], dfData=aggData)
          if (exists("multiIds") && nrow(multiIds) > 0) {
            combinedScores <- scores %>% collect()
            namesV <- c("fcaiTempReason","fcaiTempScore")
            summV <- c(allAnalytics[[i]]$Results$InsightColumn,allAnalytics[[i]]$Results$ScoreColumn)
            combinedScores <- combinedScores %>% left_join(.,resolvedIds,by=idColumns[1]) %>%
              mutate_(.dots = setNames(summV,namesV))
            combinedScores <- combinedScores %>% group_by(entityId) %>%
              mutate_(.dots = setNames("calculateCombinedScore(fcaiTempScore)",allAnalytics[[i]]$Results$ScoreColumn))

            # find the reason corresponding to the highest score
            topReasons <- combinedScores %>% top_n(1,fcaiTempScore) %>% select(c("fcaiTempReason")) %>% ungroup()
            colnames(topReasons)[colnames(topReasons)=="fcaiTempReason"] <- allAnalytics[[i]]$Results$InsightColumn
            combinedScores[[allAnalytics[[i]]$Results$InsightColumn]] <- NULL
            combinedScores <- combinedScores %>% left_join(.,topReasons,by="entityId") %>% ungroup()
            scores <- combinedScores %>% select(colnames(.)[!colnames(.) %in% c(namesV,"entityId")])
          }
          dfData <- merge(x=dfData,y=scores,by=idColumns,all.x=TRUE)
        } else if (inputsource$SourceType=="Aggregate" && !applyERfilter) {
          aggData <- tbl_df(loadData(inputsource$Type, inputsource$AggregateName))
          scores <- collect(func(parms=allAnalytics[[i]], dfData=aggData))
          idColumns <- getAggregateByColumnNames(inputsource$Type, inputsource$AggregateName)
          dfData <- merge(x=dfData,y=scores,by=idColumns,all.x=TRUE)
        } else {
          message(paste("Unsupported sourceType:",inputsource$SourceType))
        }
      }
    }
  }
  return(dfData)
}

populateReasonsDf <- function() {
  allAnalytics <- AMLAnalyticConfig$Analytics
  reasonsDf <- data.frame(ReasonType=character(), ScoreColumn=character(),
    InsightColumn=character(), Weight=numeric(), stringsAsFactors = FALSE)
  for (i in 1:length(allAnalytics)) {
    ar <- allAnalytics[[i]]$Results
    reasonsDf <- rbind(reasonsDf, data.frame(ReasonType=ar$ReasonType,
      ScoreColumn=ar$ScoreColumn, InsightColumn=ar$InsightColumn,
      Weight=ar$Weight, stringsAsFactors = FALSE))
  }
  totalWeight <- sum(reasonsDf$Weight)
  reasonsDf$Weight <- reasonsDf$Weight / totalWeight
  return(reasonsDf)
}

addOverallScore <- function(txData, reasonsDf) {
  txData$OverallScore <- 0
  for (i in 1:nrow(reasonsDf)) {
    txData$OverallScore <- txData$OverallScore + reasonsDf$Weight[i] * ifelse(!is.na(txData[[reasonsDf$ScoreColumn[i]]]),txData[[reasonsDf$ScoreColumn[i]]],0)
  }
  return(txData)
}
