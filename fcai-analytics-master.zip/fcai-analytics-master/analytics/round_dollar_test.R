# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

library(magrittr)
library(jsonlite)
library(dplyr)

source("AML_utils.R")
source("AML_rules.R")

dtData <- readAMLTxData()
dtData

thresholds <- AMLAnalyticConfig$RoundDollarThresholds
thresholds

roundDollarTest <- roundDollar(dtData, aggregateBy="CustomerID",
                  aggregateByTime="Month",ruleThresholds=thresholds)
roundDollarTest

##show all TXN related to roundDollarTest customer
#dtData %>% filter(CustomerID %in% roundDollarTest$CustomerID & TenderType %in% thresholds$TenderType) %>% group_by(CustomerID,Month) %>% print(n=20)
roundDollar.Risk <- dtData %>% filter(CustomerID %in% roundDollarTest$CustomerID & TenderType %in% thresholds$TenderType & Month %in% roundDollarTest$Month) %>% group_by(CustomerID, Month)
roundDollar.Risk
