# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.


#rm(list = ls())
source("AML_univariate.R")

library(randomForest)
library(caret)
library(mlbench)
#write.csv(byCustomerID, file="AML_aggregate_customerID.csv")

byCustomerID <- subset(byCustomerID, select = -c(topcol, CustINSG))
dtData<- merge(x = dtData, y = byCustomerID, by = c("CustomerID"), all.x=TRUE)
dtData <- na.omit(dtData)

#obtain alerted TXN ; FP_TP_Tag is not used/needed in scoring
TPFP.TXN <- read.csv(AML_tx_scored_alerts_filename, header=T, stringsAsFactors=FALSE)
TPFP.TXN <- subset(TPFP.TXN, select = c(CustomerID, TransID, FP_TP_Tag))
TPFP.TXN$alert <- 1

TP.TXN <- TPFP.TXN
FP.TXN <- TPFP.TXN

#getting input for FP training
FP.TXN[FP.TXN=="TP"] <- "NotFP"

#FP.TXN <- filter(TPFP.TXN, FP_TP_Tag=="FP")
dtData.FPtag <- merge(x = dtData, y = FP.TXN, by = c("CustomerID","TransID"), all.x=TRUE)
dtData.FPtag[c("FP_TP_Tag")][is.na(dtData.FPtag[c("FP_TP_Tag")])] <- "NotFP"
dtData.FPtag[c("alert")][is.na(dtData.FPtag[c("alert")])] <- 0

#write.csv(dtData.FPtag, file="ML_input.csv")

dtData.FPtag <- subset(dtData.FPtag, select = -c(CustomerID, TransID))

if (AMLAnalyticConfig$CountryType != "ISO3") {
  countryMatchName <- ifelse(AMLAnalyticConfig$CountryType != "Name", AMLAnalyticConfig$CountryType, "Country")
  Country_ISO <- read.csv(AML_countries_filename, header=T, stringsAsFactors=FALSE)
  colnames(Country_ISO)[colnames(Country_ISO)==countryMatchName] <- "CustomerCountry"
  colnames(Country_ISO)[4] <- "CustomerISO3"
  Country_ISO <- subset(Country_ISO, select = c(CustomerCountry, CustomerISO3))
  dtData.FPtag <- merge(x = dtData.FPtag, y = Country_ISO, by = c("CustomerCountry"), all.x=TRUE)

  colnames(Country_ISO)[1] <- "CounterCountry"
  colnames(Country_ISO)[2] <- "CounterISO3"
  Country_ISO <- subset(Country_ISO, select = c(CounterCountry, CounterISO3))
  dtData.FPtag <- merge(x = dtData.FPtag, y = Country_ISO, by = c("CounterCountry"), all.x=TRUE)
  dtData.FPtag <- subset(dtData.FPtag, select = -c(CustomerCountry, CounterCountry))
  rm(Country_ISO)
} else {
  colnames(dtData.FPtag)[colnames(dtData.FPtag)=="CustomerCountry"] <- "CustomerISO3"
  colnames(dtData.FPtag)[colnames(dtData.FPtag)=="CounterCountry"] <- "CounterISO3"
}

dtData.FPtag[c("CustomerISO3")][is.na(dtData.FPtag[c("CustomerISO3")])] <- "XXX"
dtData.FPtag[c("CounterISO3")][is.na(dtData.FPtag[c("CounterISO3")])] <- "XXX"

rm(FP.TXN)
#write.csv(dtData.FPtag, file="ML_input_mod.csv")

load(AML_rfmodel_FP_filename)

#include independent variables
validation_FP <- subset(dtData.FPtag, select = c(all.vars(formula(fit_FP.rf))))
#count(validation_FP, FP_TP_Tag)

#exclude unseen CounterISO3
#tmp_FP <- distinct(dtData.FPtag, CounterISO3)
#validation_FP <- subset(dtData.FPtag, CounterISO3 %in% tmp_FP$CounterISO3)

## estimate skill of LDA on the validation dataset
predictions_FP <- predict(fit_FP.rf, validation_FP)
#summary(predictions_FP)
confusionMatrix(predictions_FP, validation_FP$FP_TP_Tag)
u_validation_FP <- cbind(validation_FP,predictions_FP)


## TP scoring
TP.TXN[TP.TXN=="FP"] <- "NotTP"

#FP.TXN <- filter(TPFP.TXN, FP_TP_Tag=="FP")
dtData.TPtag <- merge(x = dtData, y = TP.TXN, by = c("CustomerID","TransID"), all.x=TRUE)
dtData.TPtag[c("FP_TP_Tag")][is.na(dtData.TPtag[c("FP_TP_Tag")])] <- "NotTP"
dtData.TPtag[c("alert")][is.na(dtData.TPtag[c("alert")])] <- 0

#write.csv(dtData.FPtag, file="ML_input_TP.csv")

dtData.TPtag <- subset(dtData.TPtag, select = -c(CustomerID, TransID))

if (AMLAnalyticConfig$CountryType != "ISO3") {
  countryMatchName <- ifelse(AMLAnalyticConfig$CountryType != "Name", AMLAnalyticConfig$CountryType, "Country")
  Country_ISO <- read.csv(AML_countries_filename, header=T, stringsAsFactors=FALSE)
  colnames(Country_ISO)[colnames(Country_ISO)==countryMatchName] <- "CustomerCountry"
  colnames(Country_ISO)[4] <- "CustomerISO3"
  Country_ISO <- subset(Country_ISO, select = c(CustomerCountry, CustomerISO3))
  dtData.TPtag <- merge(x = dtData.TPtag, y = Country_ISO, by = c("CustomerCountry"), all.x=TRUE)

  colnames(Country_ISO)[1] <- "CounterCountry"
  colnames(Country_ISO)[2] <- "CounterISO3"
  Country_ISO <- subset(Country_ISO, select = c(CounterCountry, CounterISO3))
  dtData.TPtag <- merge(x = dtData.TPtag, y = Country_ISO, by = c("CounterCountry"), all.x=TRUE)
  dtData.TPtag <- subset(dtData.TPtag, select = -c(CustomerCountry, CounterCountry))
  rm(Country_ISO)
} else {
  colnames(dtData.TPtag)[colnames(dtData.TPtag)=="CustomerCountry"] <- "CustomerISO3"
  colnames(dtData.TPtag)[colnames(dtData.TPtag)=="CounterCountry"] <- "CounterISO3"
}

dtData.TPtag[c("CustomerISO3")][is.na(dtData.TPtag[c("CustomerISO3")])] <- "XXX"
dtData.TPtag[c("CounterISO3")][is.na(dtData.TPtag[c("CounterISO3")])] <- "XXX"

 load(AML_rfmodel_TP_filename)
#include independent variables
validation_TP <- subset(dtData.TPtag, select = c(all.vars(formula(fit_TP.rf))))
#count(validation_TP, FP_TP_Tag)

## estimate skill of LDA on the validation dataset
predictions_TP <- predict(fit_TP.rf, validation_TP)
#summary(predictions_TP)
confusionMatrix(predictions_TP, validation_TP$FP_TP_Tag)
u_validation_TP <- cbind(validation_TP,predictions_TP)
