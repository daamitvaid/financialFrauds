# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017,2018
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.


library(magrittr)
library(zoo)
library(jsonlite)
library(dplyr)
source("AML_univariate.R")

renameColumns <- function(x, baseLabel) {
  for (i in 2:ncol(x)) {
    names(x)[i] <- paste(baseLabel,names(x)[i],sep="_")
  }
  return(x)
}

appendColumns <- function(dataList, key) {
  results <- Reduce(function(...){
    full_join(..., by=c(key))},
    dataList)
  return(results)
}

appendRows <- function(dataList) {
 results <- Reduce(function(...){
     rbind(...)},
     dataList)
}

processFeatures <- function(fileType=NA, runGenerateGII=TRUE) {
  message(paste("runGenerateGII:",runGenerateGII))
  message(paste("Length of Files:",length(AMLAnalyticConfig$Files)))
  for (i in 1:length(AMLAnalyticConfig$Files)) {
    featureContainer <- AMLAnalyticConfig$Files[[i]]
    if (is.na(fileType) || (!is.na(fileType) && featureContainer$Type==fileType)) {
      if (!is.null(featureContainer$Aggregators) || !is.null(featureContainer$Flags)) {
        writeLines(c(" "))
        message(paste0("***** Processing File ",i,": ",featureContainer$Type," *****"))
        featureData <- loadData(featureContainer$Type, addTimes=TRUE)
        if (sdf_nrow(featureData) == 0) {
          warning(paste("File",featureContainer$Type,"has no data, skipping"),immediate.=TRUE)
          next
        }
        if (!is.null(featureContainer$Flags) && (length(featureContainer$Flags) > 0)) {
          flagDF <- processFlagFeatures(featureData,featureContainer$Flags, featureContainer$Type)
        }
        if (!is.null(featureContainer$Rules) && (length(featureContainer$Rules) > 0)) {
          message(paste("Length of Rules Aggregators:",length(featureContainer$Rules)))
          featureDF <- left_join(flagDF,featureData)
          for (j in 1:length(featureContainer$Rules)) {
            agg <- featureContainer$Rules[[j]]
            writeLines(c(" ", paste("*** Processing Rules Aggregator:",j,"-",agg$RuleAggregateName)))
            aggregateBy <- getColumnNames(featureContainer$Type,agg$AggregateBy)
            aggData2 <- removeRowsWithInvalidIDs(featureDF,aggregateBy)
            groupedData <- aggData2 %>% group_by_(.dots=aggregateBy)
            processRuleFeatures(groupedData, agg, featureContainer$Type, aggregateBy)
            rm(groupedData,aggData2)
          }
        }
        if (!is.null(featureContainer$Aggregators) && (length(featureContainer$Aggregators) > 0)) {
          message(paste("Length of Aggregators:",length(featureContainer$Aggregators)))
          for (j in 1:length(featureContainer$Aggregators)) {
            agg <- featureContainer$Aggregator[[j]]
            writeLines(c(" ", paste("*** Processing Aggregator:",j,"-",agg$AggregateName)))
            aggregateBy <- getColumnNames(featureContainer$Type,agg$AggregateBy)
            aggData2 <- removeRowsWithInvalidIDs(featureData,aggregateBy)
            groupedData <- aggData2 %>% group_by_(.dots=aggregateBy)
            initializeAggregate(groupedData, agg, featureContainer$Type, aggregateBy, runGenerateGII)
            rm(groupedData,aggData2)
          }
        }
        rm(featureData,featureDF,flagDF)
      }
    }
  }
}

processFlagFeatures <- function(xdf, flagConfig, filetype) {
  writeLines(c(" ", paste0("*** Processing FlagFeatures (",length(flagConfig$FlagFeatures),")")))
  if (length(flagConfig$FlagFeatures) > 0) {
    tmp <- vector("list", length(flagConfig$FlagFeatures))
    for (i in 1:length(flagConfig$FlagFeatures)) {
      featureFlag <- flagConfig$FlagFeatures[[i]]
      message(paste("Processing FlagFeature:",i,"-",featureFlag$Label))
      func = match.fun(featureFlag$Operation)
      tmp[[i]] <- func(xdf,featureFlag,filetype)
      rm(featureFlag)
    }
    results <- appendColumns(tmp, getColumnName(filetype,"IDColumn"))
    featureOutput <- flagConfig$StoredAs
    if (!is.null(featureOutput)) {
      if (featureOutput$Debug) {
        print(results, width=Inf)
      }
      if (!is.null(featureOutput$Name)) {
        storeOutput(results, featureOutput$Name, path=featureOutput$Path, type=featureOutput$Type);
      }
    }
  }
  return(results)
}

flagIfEqual <- function(xdf, featureFlag, filetype) {
  cols <- getColumnNames(filetype,featureFlag$Columns)
  if (length(cols) == 2) {
    col1 <- cols[1]
    col2 <- cols[2]
  } else if (length(cols) == 1 && !is.null(featureFlag$FixedValue)) {
    col1 <- cols[1]
    col2 <- paste0("'",featureFlag$FixedValue,"'")
  } else {
    stop(paste0("Invalid configuration for flagIfEqual: ",filetype," - ",featureFlag$Label))
  }
  xdf %>% mutate_(.dots = setNames(paste("ifelse(",col1,"==",col2,",TRUE,FALSE)",sep=""),featureFlag$Label)) %>%
    select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
}

# flagIfFound checks to see whether an element from the specified column in a transaction exists
# in another file for fixed vector.
flagIfFound <- function(xdf, featureFlag, filetype) {
  cols <- getColumnNames(filetype, featureFlag$Columns)

  # Compare the column(s) given in xdf to a "FixedValue" list of values.
  if (length(cols) == 1 && !is.null(featureFlag$FixedValue)) {
    col1 <- cols[1] # Column from our dataframe, xdf
    col2 <- unlist(featureFlag$FixedValue)  # Fixed vector list

  # Compare the column(s) given in xdf to the values in an external csv file.
  # In the case of AMLAnalyticConfiguration_test.json, this is AML_sim_highriskcountries.csv.
  } else if (!is.null(featureFlag$Source)) {
    col1 <- cols[1] # Column from our dataframe, xdf
    colName = getColumnName(featureFlag$Source$Type,featureFlag$Source$Column) # Column name in csv file
    col2 <- sdf_read_column(loadAnalyticInput(featureFlag$Source), colName) # Column data from csv file

  } else {
    stop(paste0("Invalid configuration for flagIfFound: ",filetype," - ",featureFlag$Label))
  }

  # mutate_ adds a new column that is a result of our "in" comparison
  # select_ gets the IDColumn data (from Transactions table) and the column of interest that contains
  #         the vector of TRUE/FALSE values.
  # col2 is in " %in% col2" because it is a vector of values (we do not need to search a table)
  xdf %>% mutate_(.dots = setNames(paste(col1," %in% col2",sep=""),featureFlag$Label)) %>%
    select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
}

# Compares transaction IDs to see if a record is in the top x records after grouping/ordering
flagTopRecords <- function(xdf, featureFlag, filetype) {
  groupBy <- unlist(getColumnNames(filetype, featureFlag$GroupBy))  # Column to group by
  orderBy <- unlist(getColumnNames(filetype, featureFlag$OrderBy))  # Column to order by

  groupBy = as.name(groupBy[1]) # Converts the name, or string, into an object.
  orderBy = as.name(orderBy[1])

  # n: Number of records to compare to (we want the first x number of records)
  # If Descending flagg is TRUE, then we want the n records with the highest value after they are ordered
  if (featureFlag$Descending) {
    N <- featureFlag$NumRecords  # top_n() gets top n records (records are in descending order)
  } else {
    N <- -featureFlag$NumRecords   # top_n() gets bottom n records (records are in ascending order)
  }

  col1 <- getColumnName(filetype, "IDColumn") # Comparison column from Original dataframe

  # Group by the groupBy column, find the top/bottom x records according to the orderBy column, and
  # get the values contained in the specified comparison column
  col2 <- xdf %>% group_by(groupBy) %>% top_n(n=N, orderBy) %>%
              sdf_read_column(getColumnName(filetype, "IDColumn"))

  xdf %>% mutate_(.dots = setNames(paste(col1," %in% col2",sep=""),featureFlag$Label)) %>%
          select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
}

flagIfDivByTenPower <- function(xdf, featureFlag, filetype) {
  col <- getColumnNames(filetype,featureFlag$Columns)
  minAmt <- featureFlag$MinAmount
  noDigit <- featureFlag$Digits
  # precondition check - if min. amount is numeric and no. of digits is integer
  if (!is.numeric(minAmt)) {
    stop(paste0("Invalid configuration for flagIfDivByTenPower: ",filetype," - ",minAmt))
  } else if (!is.numeric(noDigit) || !(noDigit%%1 == 0)) {
    stop(paste0("Invalid configuration for flagIfDivByTenPower: ",filetype," - ",noDigit))
  }
  powerTen <- 10^noDigit
  # check if the transaction amount is greater than min. amount AND is divisible by 10^n where n = no. of digits
  xdf %>% mutate_(.dots = setNames(paste("ifelse((",col,"%%",powerTen,"==0)&&(",col,">=",minAmt,"),TRUE,FALSE)",sep=""),featureFlag$Label)) %>%
    select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
}

flagCntUniq <- function(xdf, featureFlag, filetype) {
	cols <- getColumnNames(filetype,featureFlag$Columns)
	exclude <- c(unlist(featureFlag$Exclude),NA)
	# Check if the input column(s) is empty
	if (length(cols) == 0) {
		stop(paste0("Invalid configuration for flagCntUniq: ",filetype," - ",cols))
	}
	# Use set operation union/setdiff to count unique with exclusion
	uniqExcludeCnt <- xdf %>% select_(.dots=c(cols)) %>%
	  spark_apply(function(df)
	  apply(df, 1, function(x) length(setdiff(Reduce(union, x),exclude))),
	  columns = featureFlag$Label)
	xdf %>% select_(.dots=c(getColumnName(filetype,"IDColumn"))) %>%
			sdf_bind_cols(uniqExcludeCnt)
}

flagCntHighRisk <- function(xdf, featureFlag, filetype) {
  riskCntryList <- getHighRiskCountries()

	cols <- getColumnNames(filetype,featureFlag$Columns)
	# Check if the input column(s) is empty
	if (length(cols) == 0) {
		stop(paste0("Invalid configuration for flagCntHighRisk: ",filetype," - ",cols))
	}
	# Use set operation union/setdiff to count unique with exclusion
	uniqExcludeCnt <- xdf %>% select_(.dots=c(cols)) %>%
	  spark_apply(function(df)
	  apply(df, 1, function(x) length(setdiff(Reduce(union, x),riskCntryList))),
	  columns = featureFlag$Label)
	xdf %>% select_(.dots=c(getColumnName(filetype,"IDColumn"))) %>%
			sdf_bind_cols(uniqExcludeCnt)
}

# copy a column directly to the flags, with only a column name change
flagCopy <- function(xdf, featureFlag, filetype) {
	col <- getColumnName(filetype,featureFlag$Column)
	# Check if the input column(s) is empty
	if (is.na(col)) {
		stop(paste0("Invalid configuration for flagCopy: ",filetype," - ",col))
	}
  # return the designated column
	xdf %>% select_(.dots=c(getColumnName(filetype,"IDColumn"),col)) %>% rename_(.dots=setNames(col,featureFlag$Label))
}

# Flag values of a column if they match the specified regular expression pattern.
flagRegex <- function(xdf, featureFlag, filetype) {
  # Exit immediately if the passed column to perform the regex on is not of type character
  temp <- xdf %>% head %>% collect %>% lapply(class)
  if (temp[which(colnames(xdf) == getColumnName(filetype, featureFlag$Columns))] == "character") {
    rm(temp)
  } else {
    stop(paste0("Invalid input column data type for flagRegex: ", temp[which(colnames(xdf) == getColumnName(filetype, featureFlag$Columns))]))
  }

  # Apply the regex to the column of interest
  regexResult <- xdf %>% select_(.dots=c(getColumnName(filetype, featureFlag$Columns))) %>%
          spark_apply(
            function(df) apply(df, 1, function(x) ifelse(grepl(featureFlag$Regex,x), TRUE, FALSE)),
            columns=featureFlag$Label
          )

  # Bind the flag column to the dataframe
  xdf %>% select_(.dots=c(getColumnName(filetype,"IDColumn"))) %>% sdf_bind_cols(regexResult)
}

flagDateCompare <- function(xdf, featureFlag, filetype) {
  col <- getColumnNames(filetype,featureFlag$Columns)
	baseDate <- featureFlag$BaseDate
	range <- featureFlag$Range
  # Default to current date
	if (baseDate == "") {
		baseDate <- Sys.Date()
	}
  else {
	  baseDate <- as.Date(baseDate, "%Y-%m-%d")
	}
  # check if range value correct
	if (!is.numeric(range) || range < 0) {
	  stop(paste0("Invalid configuration for flagDateCompare: ",filetype," - ",range))
	} else if (length(col) == 0 ||length(col) > 1) {
	  stop(paste0("Invalid configuration for flagDateCompare: ",filetype," - ",col))
	}

	dayDuration <- xdf %>% select_(.dots=c(col)) %>%
	  spark_apply(function(df)
	    apply(df, 1, function(x)
	      ifelse(findInterval(baseDate-as.numeric(as.Date(as.POSIXct(x,origin="1970-01-01"))),c(0,range))==1,TRUE,FALSE)),
	    columns = featureFlag$Label)

	xdf %>% select_(.dots=c(getColumnName(filetype,"IDColumn"))) %>%
	  sdf_bind_cols(dayDuration)
}

# Flag that is true if the value is in the specified range: min (default 0), max (default infinity)
# Must represent Inf as a string in the .json file for Min/Max.
flagNumCompare <- function(xdf, featureFlag, filetype) {
  # Exit immediately if the passed column to perform the comparison on is not numeric
  temp <- xdf %>% head %>% collect %>% lapply(class)
  if (temp[which(colnames(xdf) == getColumnName(filetype, featureFlag$Columns))] == "numeric") {
    rm(temp)
  } else {
    stop(paste0("Invalid input column data type for flagNumCompare: ", temp[which(colnames(xdf) == getColumnName(filetype, featureFlag$Columns))]))
  }

  if (is.numeric(featureFlag$Min)) {
    min = featureFlag$Min
  } else if (featureFlag$Min == "-Inf") {
    min = -Inf
  } else {
    stop(paste("Invalid input value for min: ", featureFlag$Min))
  }

  if (is.numeric(featureFlag$Max)) {
    max = featureFlag$Max
  } else if (featureFlag$Max == "Inf") {
    max = Inf
  } else {
    stop(paste("Invalid input value for max: ", featureFlag$Max))
  }

  # Check to make sure the min is smaller than the max
  if (max != Inf && min != -Inf && min > max) {
    stop(paste("Invalid input values for min/max in flagNumCompare. Min must be less than Max: Min=", min, "; Max=",max,sep=""))
  }

  col <- getColumnName(filetype, featureFlag$Columns)

  # Select whether or not we wish to include the edge values of the range as inside the range
  if (featureFlag$Inclusive) {
    xdf %>% mutate_(.dots = setNames(paste("ifelse(",min," <= ",col," & ",col," <= ",max,",TRUE,FALSE)",sep=""),featureFlag$Label)) %>%
      select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
  } else {
    xdf %>% mutate_(.dots = setNames(paste("ifelse(",min," < ",col," & ",col," < ",max,",TRUE,FALSE)",sep=""),featureFlag$Label)) %>%
      select_(.dots=c(getColumnName(filetype,"IDColumn"),featureFlag$Label))
  }
}

processRuleFeatures <- function(xdf, agg, filetype, aggregateBy) {
  if (!is.null(agg$RuleFeatures)) {
    message(paste("Length of RuleFeatures:",length(agg$RuleFeatures)))
    tmp <- vector("list", length(agg$RuleFeatures))
    for (i in 1:length(agg$RuleFeatures)) {
      message(paste("Processing RuleFeature:",i,"-",agg$RuleFeatures[[i]]$Label))
      func = match.fun(agg$RuleFeatures[[i]]$Operation)
      tmp[[i]] = func(xdf, aggregateBy=aggregateBy, feature=agg$RuleFeatures[[i]], filetype=filetype)
    }
    results <- appendColumns(tmp, aggregateBy)
    rm(tmp)
  }
  featureOutput <- agg$StoredAs
  if (!is.null(featureOutput)) {
    if (featureOutput$Debug) {
      print(results, width=Inf)
    }
    if (!is.null(featureOutput$Name)) {
      storeOutput(results, featureOutput$Name, path=featureOutput$Path, type=featureOutput$Type);
    }
  }
}

featureSum <- function(xdf, aggregateBy, feature, filetype) {
  if (length(feature$Flags) != length(feature$FlagValues)) {
    stop(paste0("Invalid input data for featureSum: Length of ", feature$Flags, "must be equal to length of ",feature$FlagValues))
  }

  sumColName <- getColumnName(filetype,feature$Column)
  summV <- c(paste("sum(",sumColName,")",sep=""))
  values <- feature$FlagValues
  colName <- feature$Label

  for (i in 1:length(feature$Flags)) {
    flagColName <- feature$Flags[[i]]
    xdf <- xdf %>%
      filter_(.dots = paste(flagColName,"==",values[[i]],sep=""))
  }
  xdf %>%
    summarize_(.dots = setNames(summV,colName))
}

featureCnt <- function(xdf, aggregateBy, feature, filetype) {
  if (length(feature$Flags) != length(feature$FlagValues)) {
    stop(paste0("Invalid input data for featureSum: Length of ", feature$Flags, "must be equal to length of ",feature$FlagValues))
  }

  colName <- feature$Label
  values <- feature$FlagValues

  for (i in 1:length(feature$Flags)) {
    flagColName <- feature$Flags[[i]]
    xdf <- xdf %>%
      filter_(.dots = paste(flagColName,"==",values[[i]],sep=""))
  }
  xdf %>%
    summarize_(.dots = setNames("n()", colName))
}

initializeAggregate <- function(xdf, agg, filetype, aggregateBy, runGenerateGII) {
  if (!is.null(agg$AggregateFeatures)) {
    message(paste("Length of AggregateFeatures:",length(agg$AggregateFeatures)))
    tmp <- vector("list", length(agg$AggregateFeatures))
    for (i in 1:length(agg$AggregateFeatures)) {
      message(paste("Processing AggregateFeature:",i,"-",agg$AggregateFeatures[[i]]$BaseLabel))
      tmp[[i]] = processAggregate(xdf, aggregateBy=aggregateBy, feature=agg$AggregateFeatures[[i]], filetype=filetype)
    }
    results <- appendColumns(tmp, aggregateBy)
    rm(tmp)
  }
  if (!is.null(agg$JoinFeatures) && (length(agg$JoinFeatures) > 0)) {
    resultsIndex = ifelse(exists("results"),1L,0L)
    message(paste("Length of JoinFeatures:",length(agg$JoinFeatures)))
    tmp <- vector("list", length(agg$JoinFeatures) + resultsIndex)
    if (resultsIndex > 0) {
      tmp[[1]] <- results
    }
    for (i in 1:length(agg$JoinFeatures)) {
      message(paste("Processing JoinFeature:",i,"-",agg$JoinFeatures[[i]]$Label))
      func = match.fun(agg$JoinFeatures[[i]]$Operation)
      tmp[[resultsIndex+i]] <- func(feature=agg$JoinFeatures[[i]], targetJoinBy=aggregateBy)
    }
    results <- appendColumns(tmp, getColumnNames(filetype,agg$AggregateBy))
    rm(tmp)
  }
  # need to join back to the full set of ids (in case some rows had no values
  # and were dropped)
  lhs <- xdf %>% select_(.dots=c(getColumnNames(filetype,agg$AggregateBy))) %>% distinct()
  results <- left_join(lhs,results)
  featureOutput <- agg$StoredAs
  if (!is.null(featureOutput)) {
    if (featureOutput$Debug) {
      print(results, width=Inf)
    }
    if (!is.null(featureOutput$Name)) {
      storeOutput(results, featureOutput$Name, path=featureOutput$Path, type=featureOutput$Type);
    }
  }
  if (runGenerateGII && !is.null(agg$GII)) {
    message("Processing general interestingness index (GII)")
    aw <- agg$GII$Weights
    generateGII(results,idColumnCount=length(agg$AggregateBy),
      outputName=agg$GII$StoredAs$Name[1],
      outputPath=agg$GII$StoredAs$Path[1],
      outputType=agg$GII$StoredAs$Type[1],
      FPS1=aw$FPS1,FPS3=aw$FPS3,FPS4=aw$FPS4,FPS5=aw$FPS5,FPS6=aw$FPS6)
  }
  rm(results)
}

processAggregate <- function(xdf, aggregateBy, feature, filetype) {
  func = match.fun(feature$Operation)
  if (length(feature$TimeRanges)) {
    tmp <- vector("list", length(feature$TimeRanges))
    for (i in 1:length(feature$TimeRanges)) {
        res <- func(xdf, aggregateBy=aggregateBy, aggregateByTime=feature$TimeRanges[[i]], feature=feature, filetype=filetype)
        tmp[[i]] = res
    }
    results <- appendColumns(tmp, aggregateBy)
    rm(tmp)
  } else {
    results <- func(xdf, aggregateBy=aggregateBy, feature=feature, filetype=filetype)
  }
  return(results)
}

processFilter <- function(filetype, filters, operator=" & ") {
  filter <- ""  # additional filter to apply
  for (i in 1:length(filters)) {
    filter_col <- getColumnName(filetype, filters[[i]]$filterColumn)  # Filter column

    # Get all the values for this filter column and create a vector from them - as a string
    val_vec <- c(filters[[i]]$filterValue)
    val_vec <- paste0("c('",paste0(val_vec,collapse="','"),"')")

    # Check to see if this is first iteration of loop. If it is, we do not want a leading.
    if (i == 1) {
      # Check to see if we want this filter column's filter values included or excluded
      if (filters[[i]]$filterMatch == "include") {
        filter <- paste(filter, "(", filter_col, " %in% ", val_vec,")", sep="") # If included
      } else if (filters[[i]]$filterMatch == "exclude") {
        filter <- paste(filter, "!(", filter_col, " %in% ", val_vec,")", sep="")  # If excluded
      } else {
        stop(paste0("Invalid value for filterMatch feature: ", filters[[i]]$filterMatch))
      }

    } else {
      if (filters[[i]]$filterMatch == "include") {
        filter <- paste(filter, paste("(", filter_col, " %in% ", val_vec,")", sep=""), sep=operator)
      } else if (feature$filters[[i]]$filterMatch == "exclude") {
        filter <- paste(filter, paste("!(", filter_col, " %in% ", val_vec,")", sep=""), sep=operator)
      } else {
        stop(paste0("Invalid value for filterMatch feature: ", filters[[i]]$filterMatch))
      }
    }
  }
  return(filter)
}

summarizeBySum <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  summV <- c("mean(abs(Total))","min(abs(Total))","max(abs(Total))","var(abs(Total))","percentile(abs(Total),0.5)")
  namesV <- c(paste(feature$BaseLabel,aggregateByTime,"Avg",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Min",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Max",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Var",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Med",sep="_"))
  x %>%
  group_by_(aggregateByTime, add=TRUE) %>%
  summarize_(.dots = setNames(paste("sum(abs(",getColumnName(filetype,feature$Column),"))",sep=""), "Total")) %>%
  group_by_(.dots = aggregateBy, add=TRUE) %>%
  summarize_(.dots = setNames(summV,namesV))
}

summarizeByStats <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  sumColName <- getColumnName(filetype,feature$Column)
  summV1 <- c(paste("mean(abs(",sumColName,"))",sep=""),paste("min(abs(",sumColName,"))",sep=""),paste("max(abs(",sumColName,"))",sep=""))
  namesV1 <- c("FeatureAvg","FeatureMin","FeatureMax")
  summV2 <- c("mean(abs(FeatureAvg))","min(abs(FeatureMin))","max(abs(FeatureMax))")
  namesV2 <- c(paste(feature$BaseLabel,aggregateByTime,"Avg",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Min",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Max",sep="_"))
  if (!is.null(feature$filters) && length(feature$filters) > 0) {
    filter <- processFilter(filetype, feature$filters)
    x %>%
      filter_(.dots = filter) %>% # Additional condition to filter by before calculating the percentage
      group_by_(aggregateByTime, add=TRUE) %>%
      summarize_(.dots = setNames(summV1,namesV1)) %>%
      group_by_(.dots = aggregateBy, add=TRUE) %>%
      summarize_(.dots = setNames(summV2,namesV2))
  } else {
    x %>%
      group_by_(aggregateByTime, add=TRUE) %>%
      summarize_(.dots = setNames(summV1,namesV1)) %>%
      group_by_(.dots = aggregateBy, add=TRUE) %>%
      summarize_(.dots = setNames(summV2,namesV2))
  }
}

summarizeByVariance <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  #Returns min,max,avg of variance of selected field
  summV <- c("mean(Variance, na.rm = TRUE)","min(Variance, na.rm = TRUE)","max(Variance, na.rm = TRUE)")
  namesV <- c(paste(feature$BaseLabel,aggregateByTime,"Avg",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Min",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Max",sep="_"))
  col <- getColumnName(filetype,feature$Column)

  x %>%
  group_by_(aggregateByTime, aggregateBy, add=TRUE) %>%
  summarize_(.dots = setNames(paste("var(",col,")",sep=""),'Variance')) %>%
  group_by_(.dots = aggregateBy, add=TRUE) %>%
  summarize_(.dots = setNames(summV,namesV))
}

summarizeByUniqueCount <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  summV <- c("mean(Total)","min(Total)","max(Total)")
  namesV <- c(paste(feature$BaseLabel,aggregateByTime,"Avg",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Min",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Max",sep="_"))
  col <- getColumnName(filetype,feature$CountColumn)
  countHighRisk <- feature$CountHighRisk
  condition <- NULL

  if (!is.null(countHighRisk) && countHighRisk) {
    if(is.null(feature$Source)) {
      stop(paste0("Empty value for high-risk country source in summarizeByUniqueCount"))
    } else {
      colName <- getColumnName(feature$Source$Type,feature$Source$Column)
      riskCntry <- sdf_read_column(loadAnalyticInput(feature$Source), colName) 
      
      cntryVector <- paste0("c('",paste0(riskCntry,collapse="','"),"')")
      condition <- paste("(", col, " %in% ", cntryVector,")", sep="")
    }
  }
  
  if (!is.null(feature$filters) && length(feature$filters) > 0) {
    filter <- processFilter(filetype, feature$filters)
    if (!is.null(condition)) {
      x %>%
        filter_(.dots = condition) %>%
        filter_(.dots = filter) %>% 
        group_by_(aggregateByTime, add=TRUE) %>%
        summarize_(.dots = setNames(paste("n_distinct(",col,")",sep=""),"Total")) %>%
        group_by_(.dots = aggregateBy, add=TRUE) %>%
        summarize_(.dots = setNames(summV,namesV))
    } else {
      x %>%
        filter_(.dots = filter) %>% 
        group_by_(aggregateByTime, add=TRUE) %>%
        summarize_(.dots = setNames(paste("n_distinct(",col,")",sep=""),"Total")) %>%
        group_by_(.dots = aggregateBy, add=TRUE) %>%
        summarize_(.dots = setNames(summV,namesV))
    }

  } else {
    if (!is.null(condition)) {
      x %>%
        filter_(.dots = condition) %>%
        group_by_(aggregateByTime, add=TRUE) %>%
        summarize_(.dots = setNames(paste("n_distinct(",col,")",sep=""),"Total")) %>%
        group_by_(.dots = aggregateBy, add=TRUE) %>%
        summarize_(.dots = setNames(summV,namesV))
    } else {
      x %>%
        group_by_(aggregateByTime, add=TRUE) %>%
        summarize_(.dots = setNames(paste("n_distinct(",col,")",sep=""),"Total")) %>%
        group_by_(.dots = aggregateBy, add=TRUE) %>%
        summarize_(.dots = setNames(summV,namesV))
    }
  }
}

summarizeByCount <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  summV <- c("mean(Total)","min(Total)","max(Total)","var(Total)","percentile(Total,0.5)")
  namesV <- c(paste(feature$BaseLabel,aggregateByTime,"Avg",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Min",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Max",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Var",sep="_"),paste(feature$BaseLabel,aggregateByTime,"Med",sep="_"))
  x %>%
  group_by_(aggregateByTime, add=TRUE) %>%
  summarize(Total=n()) %>%
  group_by_(.dots = aggregateBy, add=TRUE) %>%
  summarize_(.dots = setNames(summV,namesV))
}

summarizeByCountGrouped <- function(x, aggregateBy, aggregateByTime, feature, filetype) {
  summV <- c("mean(Total2)","min(Total2)","max(Total2)")
  tmp <- vector("list", length(feature$GroupingColumns))
  for (i in 1:length(feature$GroupingColumns)) {
    groupColName <- getColumnName(filetype,feature$GroupingColumns[[i]])
    namesV <- c(paste(groupColName,feature$BaseLabel,aggregateByTime,"Avg",sep="_"),
      paste(groupColName,feature$BaseLabel,aggregateByTime,"Min",sep="_"),
      paste(groupColName,feature$BaseLabel,aggregateByTime,"Max",sep="_"))
    res <- x %>%
          group_by_(aggregateByTime, groupColName, add=TRUE) %>%
          summarize(Total1=1) %>%
          summarize(Total2=n()) %>%
          group_by_(.dots = aggregateBy, add=TRUE) %>%
          summarize_(.dots = setNames(summV,namesV))
    tmp[[i]] = res
  }
  results <- appendColumns(tmp, aggregateBy)
  rm(tmp)
  return(results)
}

summarizeByFrequency <- function(x, aggregateBy, feature, filetype, ...) {
  summV <- c("mean(TimeDiff, na.rm=TRUE)","min(TimeDiff, na.rm= TRUE)","max(TimeDiff, na.rm= TRUE)")
  namesV <- c(paste(feature$BaseLabel,"Avg",sep="_"),
    paste(feature$BaseLabel,"Min",sep="_"),
    paste(feature$BaseLabel,"Max",sep="_"))

    
  if (!is.null(feature$filters) && length(feature$filters) > 0) {
    filter <- processFilter(filetype, feature$filters)
      
    #Calculating time diff in days
  	x %>%
  	filter_(.dots = filter) %>% 
  	mutate(PreDT=lag(DateTimeStamp,1,order=DateTimeStamp)) %>% filter(PreDT>0) %>% 
  	mutate(TimeDiff=round((DateTimeStamp-PreDT)/86400,0)) %>% 
  	group_by_(.dots = aggregateBy, add=TRUE) %>%
  	summarize_(.dots = setNames(summV,namesV))
  }
  else {
  	x %>%
  	mutate(PreDT=lag(DateTimeStamp,1,order=DateTimeStamp)) %>% filter(PreDT>0) %>% 
  	mutate(TimeDiff=round((DateTimeStamp-PreDT)/86400,0)) %>%
  	group_by_(.dots = aggregateBy, add=TRUE) %>%
  	summarize_(.dots = setNames(summV,namesV))
  }
}

summarizeByRiskCount <- function(x, aggregateBy, feature, filetype) {
  summV <- c("max(totRiskTxn, na.rm = TRUE)")
  nameV <- feature$BaseLabel
  riskCntryList <- getHighRiskCountries()

  cols <- getColumnNames(filetype,feature$Columns)

  condition <- ""
  for (i in 1:(length(cols)-1)) {
    condition <- paste0(condition, paste("(", cols[i], " %in% riskCntryList) | ", sep=""))
  }
  condition <- paste0(condition,paste("(", cols[length(cols)], " %in% riskCntryList)", sep=""))

  x %>%
    filter_(.dots = condition) %>%
    group_by_(.dots = aggregateBy, add=TRUE) %>%
    mutate(totRiskTxn = count()) %>%
    summarize_(.dots = setNames(summV,nameV))
}

summarizeByPercentage <- function(x, aggregateBy, feature, filetype) {
  summV = c("max(Percent, na.rm = TRUE)") # We take the max so that we only have one result per customer to use in the join
  namesV = c(paste(feature$BaseLabel, feature$Category, sep="_")) # What we want our output column name to be
  agg_col <- as.name(getColumnName(filetype, feature$Column)) # Column we want the percentage for a category of
  agg_cat <- feature$Category # Category we want the percentage of from the specified column

  # Check for additional filter conditions.
  if (!is.null(feature$filters) && length(feature$filters) > 0) {
    filter <- processFilter(filetype, feature$filters, " | ")
    x %>%
      filter_(.dots = filter) %>% # Additional condition to filter by before calculating the percentage
      mutate(tot_records=count()) %>% # First, get the total records per customer
      filter(agg_col==agg_cat) %>%  # Next, filter the table to get the rows of the specified category for the column we want percentage values for
      mutate(category_count=count()) %>% # Count the number of values in this category for each customer
      mutate(Percent = (category_count / tot_records)) %>% # Calculate the percent in this category for each customer
      summarize_(.dots = setNames(summV,namesV))

  # Otherwise, there were no additional filter conditions
  } else {
    x %>%
      mutate(tot_records=count()) %>%
      filter(agg_col==agg_cat) %>%
      mutate(category_count=count()) %>%
      mutate(Percent = (category_count / tot_records)) %>%
      summarize_(.dots = setNames(summV,namesV))
  }
}

countMatching <- function(x, aggregateBy, feature, filetype) {
  # Check for filter conditions.
  if (!is.null(feature$Values) && length(feature$Values) > 0) {
    val_vec <- c(feature$Values)
    val_vec <- paste0("c('",paste0(val_vec,collapse="','"),"')")
    filterCriteria <- paste0(getColumnName(filetype, feature$Column)," %in% ",val_vec)
    tempX <- x %>%
      filter_(.dots = filterCriteria) %>%
      summarize_(.dots = setNames(c("n()"),c(feature$BaseLabel)))
  } else {
    x %>%
      summarize_(.dots = setNames(c("n()"),c(feature$BaseLabel)))
  }
}

copyExternalColumn <- function(feature, targetJoinBy) {
  tmp <- vector("list", length(feature$Source))
  for (i in 1:length(feature$Source)) {
    tempdata <- loadData(feature$Source[[i]]$Type)
    sourceJoinBy <- getColumnNames(feature$Source[[i]]$Type,feature$Source[[i]]$JoinColumns)
    copyColumnName <- getColumnName(feature$Source[[i]]$Type,feature$Source[[i]]$Column)
    sourceColumns <- c(sourceJoinBy,copyColumnName)
    targetColumns <- c(targetJoinBy,feature$Label)
    tempdata <- select_(tempdata, .dots=sourceColumns)
    for (j in 1:length(sourceColumns)) {
      tempdata %<>% rename_(.dots=setNames(sourceColumns[j],targetColumns[j]))
    }
    tmp[[i]] <- tempdata
  }
  results <- appendRows(tmp)
  rm(tmp)
  return(results)
}

getHighRiskCountries <- function() {
  if (!exists("highRiskCountryList", envir = .GlobalEnv)) {
    highRiskCntry <- collect(loadData("HighRiskCountries"))
    assign("highRiskCountryList", highRiskCntry$Country, envir = .GlobalEnv)
  }
  return(get("highRiskCountryList", envir = .GlobalEnv))
}
