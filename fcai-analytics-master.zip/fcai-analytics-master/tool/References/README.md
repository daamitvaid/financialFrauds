This directory is used to store images, screencuts, etc that are used inside Tools.
