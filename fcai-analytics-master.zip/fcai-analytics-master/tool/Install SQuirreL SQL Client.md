## Download
Go to [SQuirreL homepage](http://www.squirrelsql.org/#installation) and download the SQL Client for the most recent version. (Should be the one listed on top)

## Install
Open Terminal and run `java -jar squirrel-sql-3.8.1-MACOSX-install.jar `. Change the filename if you have downloaded other version. This should initiate the interface below.

<p align="center">
  <img src="References/squirrel1.png">
</p>
Click Next.
<p align="center">
  <img src="References/squirrel2.png">
</p>
Click Next.
<p align="center">
  <img src="References/squirrel3.png">
</p>
Click Next.
<p align="center">
  <img src="References/squirrel4.png">
</p>
Click Ok then Next.
<p align="center">
  <img src="References/squirrel5.png">
</p>
Select DB2 as well and click Next.
<p align="center">
  <img src="References/squirrel6.png">
</p>
Click Next.
<p align="center">
  <img src="References/squirrel7.png">
</p>
Click Done.



### If launching SQuirreL crashes...
Locate squirrel-sql.sh on your laptop and open with your editor.
<p align="center">
  <img src="References/squirrel8.png">
</p>
Change the SQUIRREL_SQL_HOME to the value in the screencut and this should do the job.
<p align="center">
  <img src="References/squirrel9.png">
</p>


## Configure
Create a new Driver.
<p align="center">
  <img src="References/squirrel10.png">
</p>
Fill out info box as indicated. Reach out to Russ Lambert for the jar file and password information. You'll need to add jar file in extra path here and type password in a later step.
<p align="center">
  <img src="References/squirrel11.png">
</p>
You'll see the page below if successfully configured.
<p align="center">
  <img src="References/squirrel12.png">
</p>
Create a new alias and configure as indicated. Fill in the password here.
<p align="center">
  <img src="References/squirrel13.png">
</p>
When you see this page, your SQuirreL configuration is finished and you're ready to roll!
<p align="center">
  <img src="References/squirrel14.png">
</p>

