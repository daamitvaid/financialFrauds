# Generating sample data: Disclaimer**

The current data generation scripts are `createSampleIndividuals.R` and `createSampleOrganizations.R`. If the user desires any changes to the generated sample data from its current state, edits must be made directly to the code in these scripts. 

# Generating sample data: Individuals

Run the R file `createSampleIndividuals.R` to generate a csv file containing the individual sample data. The csv file name will follow the format of: `AML_sampleIndividuals_<num row>.csv`, where `<num_rows>` is the number of records generated. For example, if the number of records generated is 100, the output file name will be `AML_sampleIndividuals_100.csv`

## Usage

### To change the number of individuals generated:

At Line 30 in`createSampleIndividuals.R`, set the `customerIDCount` variable to the number of rows you wish to generate. 

For example, to generate 100 rows, you would change Line 30 to:
`customerIDCount <- 100`

### To add or subtract output columns to/from the final .csv output

At Line 325 in `createSampleIndividuals.R`, a subset() function is used on the dataset to select which columns are sent to the output file. The user can add or subtract column names to the list on this line. 

For example, if the user wishes to only generate the `CUSTOMER_ID`, `PARTY_TYPE`, and `OCCUPATION` columns in the output file, they would change Line 325 to the following:

`customers <- subset(customers,select=c("CUSTOMER_ID", "PARTY_TYPE", "OCCUPATION"))`

**NOTE: The chosen column names must exist in order for the subset() function to work.** If the user desires a column that does not exist, they must create and populate the column themselves. 

## Currently available columns

**If the user desires a column that does not exist, they must create and populate the column themselves.** 

### Populated

The following columns exist and are populated with relevant values:

~~~~
CUSTOMER_ID
REMOTE_SYSTEM_ID
PARTY_TYPE
FIRST_NAME
MIDDLE_NAME
LAST_NAME
MAIDEN_NAME
GENDER
BIRTH_TIME
MARITAL_STATUS
NATIONALITY
SSN
CITIZENSHIP
OCCUPATION
COUNTRY_OF_RESIDENCY
HOME_PHONE
HOME_ADDRESS_LINE1
HOME_ADDRESS_CITY
HOME_ADDRESS_STATE
HOME_ADDRESS_COUNTRY
HOME_ADDRESS_LAT
HOME_ADDRESS_LONG
WORK_ADDRESS_LINE1
WORK_ADDRESS_CITY
WORK_ADDRESS_STATE
WORK_ADDRESS_COUNTRY
WORK_ADDRESS_LAT
WORK_ADDRESS_LONG
WORK_PHONE
~~~~

### Unpopulated

The following columns exist but are populated only with NA or 0 as values:

~~~~
LEGAL_NAME
ALIAS
DEATH_TIME
CREATION_TIME
NEXT_REVIEW_TIME
LAST_REVIEW_TIME
PRIOR_SAR_COUNT
LAW_ENFORCEMENT_ALERT_COUNT
PAST_CONFIRMED_FRAUD
PAST_SUSPECTED_FRAUD
POSITION
DIVISION
LINE_OF_BUSINESS
WORKS_FOR
REPORTS_TO
LOCATION
PRIMARY_CONTACT_POINT
ALTERNATE_CONTACT_POINT
CELL_PHONE
ALTERNATE_ADDRESS_NAME
ALTERNATE_ADDRESS_LINE1
ALTERNATE_ADDRESS_LINE2
ALTERNATE_ADDRESS_LINE3
ALTERNATE_ADDRESS_CITY
ALTERNATE_ADDRESS_CODE
ALTERNATE_ADDRESS_COUNTY
ALTERNATE_ADDRESS_STATE
ALTERNATE_ADDRESS_COUNTRY
ALTERNATE_ADDRESS_LAT
ALTERNATE_ADDRESS_LONG
HOME_ADDRESS_LINE2
HOME_ADDRESS_LINE3
HOME_ADDRESS_CODE
HOME_ADDRESS_COUNTY
WORK_ADDRESS_LINE2
WORK_ADDRESS_LINE3
WORK_ADDRESS_CODE
WORK_ADDRESS_COUNTY
~~~~

## Currently output columns

The following columns are currently set at Line 325 and sent to the .csv output file: 
~~~~
CUSTOMER_ID
PARTY_TYPE 
CREATION_TIME
LAST_REVIEW_TIME
NEXT_REVIEW_TIME
GENDER
BIRTH_TIME
DEATH_TIME
MARITAL_STATUS
NATIONALITY
LAST_NAME
FIRST_NAME
MIDDLE_NAME
ALIAS
OCCUPATION
COUNTRY_OF_RESIDENCY
HOME_PHONE
WORK_PHONE
CELL_PHONE
HOME_ADDRESS_LINE1
HOME_ADDRESS_LINE2
HOME_ADDRESS_LINE3
HOME_ADDRESS_CITY
HOME_ADDRESS_CODE
HOME_ADDRESS_STATE
HOME_ADDRESS_COUNTRY
WORK_ADDRESS_LINE1
WORK_ADDRESS_LINE2
WORK_ADDRESS_LINE3
WORK_ADDRESS_CITY
WORK_ADDRESS_CODE
WORK_ADDRESS_STATE
WORK_ADDRESS_COUNTRY
ALTERNATE_ADDRESS_NAME
ALTERNATE_ADDRESS_LINE1
ALTERNATE_ADDRESS_LINE2
ALTERNATE_ADDRESS_LINE3
ALTERNATE_ADDRESS_CITY
ALTERNATE_ADDRESS_CODE
ALTERNATE_ADDRESS_STATE
ALTERNATE_ADDRESS_COUNTRY
~~~~


# Generating sample data: Organizations

Run the R file `createSampleOrganizations.R` to generate a csv file containing the organization sample data. The csv file name will follow the format of: `AML_sampleOrganizations_<num row>.csv`, where `<num_rows>` is the number of records generated. For example, if the number of records generated is 100, the output file name will be `AML_sampleOrganizations_100.csv`

## Usage

### To change the number of organizations generated:

At Line 29 in`createSampleOrganizations.R`, set the `organizationIDCount` variable to the number of rows you wish to generate. 

For example, to generate 100 rows, you would change Line 29 to:
`organizationIDCount <- 100`

### To add or subtract output columns to/from the final .csv output

At Line 128 in `createSampleOrganizations.R`, a subset() function is used on the dataset to select which columns are sent to the output file. The user can add or subtract column names to the list on this line. 

For example, if the user wishes to only generate the `CUSTOMER_ID`, `PARTY_TYPE`, and `NATURE_OF_BUSINESS` columns in the output file, they would change Line 128 to the following:

`organizations <- subset(organizations,select=c("CUSTOMER_ID", "PARYT_TYPE", "NATURE_OF_BUSINESS"))`

**NOTE: The chosen column names must exist in order for the subset() function to work.** If the user desires a column that does not exist, they must create and populate the column themselves. 

## Currently available columns

**If the user desires a column that does not exist, they must create and populate the column themselves.** 

### Populated

The following columns exist and are populated with relevant values:

~~~~
CUSTOMER_ID
TAX_ID
REMOTE_SYSTEM_ID
PARTY_TYPE
NAME
ORGANIZATION_TYPE
ESTABLISHED_DATE
NATURE_OF_BUSINESS
COUNTRY_OF_RESIDENCY
COUNTRY_OF_INCORPORATION
COUNTRY_OF_RESIDENCY
PRIMARY_PHONE
LINE1
CITY
STATE
COUNTRY
COMPANY_ADDRESS_LAT
COMPANY_ADDRESS_LONG
~~~~

### Unpopulated

The following columns exist but are populated only with NA or 0 as values:

~~~~
IDENTIFICATION_TYPE
DISSOLVED_DATE
DESCRIPTION
PRIMARY_CONTACT_POINT
ALTERNATE_CONTACT_POINT
GEOGRAPHY
PARENT_COMPANY_TAXID
CREATION_TIME
LAST_REVIEW_TIME
NEXT_REVIEW_TIME
PRIOR_SAR_COUNT
LAW_ENFORCEMENT_ALERT_COUNT
PAST_CONFIRMED_FRAUD
PAST_SUSPSECTED_FRAUD
LINE2
LINE3
CODE
COMPANY_ADDRESS_COUNTY
~~~~

## Currently output columns

The following columns are currently set at Line 128 and sent to the .csv output file: 
~~~~
CUSTOMER_ID
PARTY_TYPE
CREATION_TIME
LAST_REVIEW_TIME
NEXT_REVIEW_TIME
IDENTIFICATION_TYPE
ESTABLISHED_DATE
DISSOLVED_DATE
NATURE_OF_BUSINESS
COUNTRY_OF_RESIDENCY
COUNTRY_OF_INCORPORATION
NAME
PRIMARY_PHONE
LINE1
LINE2
LINE3
CITY
CODE
STATE
COUNTRY
~~~~


# APPENDIX

## convertUtils.R

The file `convertUtils.R` contains some useful functions for random generation of data.

#### replaceCountry()

The `replaceCountry()` function is used to facilitate the transformation of a normal country name to ISO3 format. 

#### randomTimestamps()

The `randomTimestamps()` function takes a start date and end date, and generates random time stamps between the two. 
