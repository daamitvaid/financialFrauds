replaceCountry <- function(addDf,targetColumn,originalCountryDataColumn,newCountryDataColumn) {
  countries <- tbl_df(read.csv("../../sample_data/CountryData.csv",na.strings=c(""),stringsAsFactor=FALSE)) 
  columnNames <- colnames(addDf)
  addDf[[targetColumn]][addDf[[targetColumn]] == "EIRE"] <- "Ireland"
  addDf[[targetColumn]][addDf[[targetColumn]] == "Channel Islands"] <- "Jersey"
  byV <- c(originalCountryDataColumn)
  names(byV) <- c(targetColumn)
  addDf <- left_join(addDf,countries,by=byV)
  
  addDf[addDf[[targetColumn]] == "Palestine", newCountryDataColumn] <- "PSE"
  addDf[addDf[[targetColumn]] == "Ivory Coast", newCountryDataColumn] <- "CIV"
  addDf[addDf[[targetColumn]] == "UK", newCountryDataColumn] <- "GBR"
  addDf[addDf[[targetColumn]] == "USA", newCountryDataColumn] <- "USA"
  addDf[addDf[[targetColumn]] == "Gambia", newCountryDataColumn] <- "GMB"
  addDf[addDf[[targetColumn]] == "Honduras", newCountryDataColumn] <- "HND"
  addDf[addDf[[targetColumn]] == "Equatorial Guinea", newCountryDataColumn] <- "GNQ"
  addDf[addDf[[targetColumn]] == "Serbia and Montenegro", newCountryDataColumn] <- "SRB"
  addDf[addDf[[targetColumn]] == "Pitcairn", newCountryDataColumn] <- "PCN"
  addDf[addDf[[targetColumn]] == "Korea North", newCountryDataColumn] <- "PRK"
  addDf[addDf[[targetColumn]] == "Korea South", newCountryDataColumn] <- "KOR"
  addDf[addDf[[targetColumn]] == "Canary Islands", newCountryDataColumn] <- "SCN"
  addDf[addDf[[targetColumn]] == "East Timor", newCountryDataColumn] <- "TLS"
  addDf[addDf[[targetColumn]] == "Myanmar", newCountryDataColumn] <- "MMR"
  addDf[addDf[[targetColumn]] == "Congo Democratic Republic", newCountryDataColumn] <- "COD"
  addDf[addDf[[targetColumn]] == "Bahamas", newCountryDataColumn] <- "BHS"
  addDf[addDf[[targetColumn]] == "Argentina", newCountryDataColumn] <- "ARG"
  addDf[addDf[[targetColumn]] == "Saint Vincent and The Grenadines", newCountryDataColumn] <- "VCT"
  addDf[addDf[[targetColumn]] == "US Virgin Islands", newCountryDataColumn] <- "VIR"
  addDf[addDf[[targetColumn]] == "Netherlands Antilles", newCountryDataColumn] <- "ANT"
  addDf[addDf[[targetColumn]] == "Madeira", newCountryDataColumn] <- "PRT"
  addDf[addDf[[targetColumn]] == "Madiera", newCountryDataColumn] <- "PRT"
  addDf[addDf[[targetColumn]] == "Azores", newCountryDataColumn] <- "PRT"
  addDf[addDf[[targetColumn]] == "Congo", newCountryDataColumn] <- "COG"
  addDf[addDf[[targetColumn]] == "Cape Verde", newCountryDataColumn] <- "CPV"
  addDf[addDf[[targetColumn]] == "Falkland Islands", newCountryDataColumn] <- "FLK"
  addDf[addDf[[targetColumn]] == "Svalbard and Jan Mayen", newCountryDataColumn] <- "SJM"
  addDf[addDf[[targetColumn]] == "Turks and Caicos", newCountryDataColumn] <- "TCA"
  addDf[addDf[[targetColumn]] == "Saint-Barthelemy", newCountryDataColumn] <- "BLM"
  addDf[addDf[[targetColumn]] == "Easter Island", newCountryDataColumn] <- "CHL"
  addDf[addDf[[targetColumn]] == "Saint-Martin", newCountryDataColumn] <- "MAF"
  addDf[addDf[[targetColumn]] == "Sicily", newCountryDataColumn] <- "ITA"
  addDf[addDf[[targetColumn]] == "British Virgin Islands", newCountryDataColumn] <- "VGB"
  addDf[addDf[[targetColumn]] == "Guernsey and Alderney", newCountryDataColumn] <- "GGY"
  addDf[addDf[[targetColumn]] == "Vatican City", newCountryDataColumn] <- "VAT"
  
  addDf[[targetColumn]] <- NULL
  colnames(addDf)[colnames(addDf)==newCountryDataColumn] <- targetColumn
  addDf <- addDf %>% select(columnNames)
  return(addDf)
}

randomTimestamps <- function(tsCount, startDate="2018/01/01", endDate="2018/12/31") {
  startPosix <- as.POSIXct(as.Date(startDate))
  endPosix <- as.POSIXct(as.Date(endDate))
  timeseq <- as.numeric(difftime(endPosix,startPosix,unit="sec"))
  offsets <- runif(tsCount, 0, timeseq)
  randomTimes <- startPosix + offsets
  return(randomTimes)
}

generateIndividualDisplayName <- function(indsDf) {
  indsDf %>% mutate(display_nm=paste(first_name,last_name))
}
