# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list=ls())

library(randomNames)
library(data.table)
library(magrittr)
library(jsonlite)
library(dplyr)
library(maps)

source("convertUtils.R")

#Generate X number of customers
customerIDCount <- 5000

#Distribute country instances by weight
customerCountries <- data_frame(countryName=c("United Kingdom","France","Germany","Australia","Netherlands","Norway","Ireland","Switzerland","Spain","Poland","Portugal","Italy","Belgium","Lithuania","Iceland","Japan","Jersey","Cyprus","Sweden","Finland","Greece","Singapore","Lebanon","United Arab Emirates","Israel","Denmark","Czech Republic","Brazil","United States","Canada","Bahrain"),
w=c(25,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,75,20,1))

#Convert country names to ISO3 format
customerCountries <- replaceCountry(customerCountries,"countryName","Country","ISO3") 

#Acquire US cities from maps (splitting the city names at the last space). Creates two columns containing city and state
usCities <- do.call(rbind, strsplit(us.cities$name, ' (?=[^ ]+$)', perl=TRUE))

#Rename columns appropriatley
colnames(usCities) <- c("city","state")

#Bind them back to the original unsplit dataset
usCities <- cbind(us.cities, usCities)

#turn into dataframe
usCities <- tbl_df(usCities)

#Load a local csv file that contains street names (generated from internet data)
streetNames <- fread("StreetNames.csv",header=TRUE,sep=",", stringsAsFactors=FALSE)

#turn into dataframe
streetNames <- tbl_df(streetNames)

#Load a local csv file that contains two columns, occupation and number of people in that occupation (generated from census data)
occupations <- fread("Occupations.csv",header=TRUE,sep=",", stringsAsFactors=FALSE)

#turn into a dataframe
occupations <- tbl_df(occupations)

#Function that randomly assigns, based on age, whether this person is married
createMarriedStatus <- function(age) {
  p = -52.06304 + 4.219048*age - 0.0384307*age*age
  if (p < 0) {
    p = 0
  }
  sample(c("Married","Single"),1,prob=c(p,100-p))
}

#Function that randomly assigns a working status to a person based on age
getWorkingStatus <- function(age) {
  if (age < 17 | age > 70) {
    return(FALSE)
  } else if (age < 24 | age > 62) {
    return(sample(c(TRUE,FALSE),1,prob=c(0.5,0.5)))
  } else {
    return(sample(c(TRUE,FALSE),1,prob=c(0.8,0.2)))
  }
}

#Set the seed for the randomizer to ensure the same thing is produced each time
set.seed(8)

#Make a data frame full of customer IDs, remote system ID, party_type. Customer IDs will be generated based on the "x" number of customers set in line 30. 
#From X to ((X*2)-1). Set party type (is individual for this file)
customers <- data_frame(CUSTOMER_ID=seq(customerIDCount, (customerIDCount * 2)-1),REMOTE_SYSTEM_ID=1L,PARTY_TYPE="Individual")

#Print a message to say how many customers there are
print(paste("Total customers:",nrow(customers)))

#Create customerNames
# Ethnicity can be specified in a vector with following codes:
# 1 American Indian or Native Alaskan
# 2 Asian or Pacific Islander
# 3 Black (not Hispanic)
# 4 Hispanic
# 5 White (not Hispanic)
# 6 Middle-Eastern, Arabic

#Creates a bunch of names, returns firstname, lastname, ethnicity, and gender
customerNames <- randomNames(nrow(customers),ethnicity=c(2,3,4,5),return.complete.data=TRUE)

#print the customer names results
customerNames

#Bind the customer names to the customer ID dataframe
customers <- cbind(customers, customerNames)

# create middle names and potential maiden names
additionalNames <- customers[,c("CUSTOMER_ID","gender","ethnicity")]
additionalNames$MIDDLE_NAME <- NA
additionalNames$MAIDEN_NAME <- NA
uniquePairs <- unique(additionalNames[,c("gender","ethnicity")])

#Matches the middle name to the ethnicity and gender of the person, by using those to generate a "first name" from random names
#Matches the maiden name to the ethnicity and gender of the person, by using those to generate a "last name" from random names
for (i in 1:nrow(uniquePairs)) {
  sampleCount <- nrow(additionalNames[additionalNames$gender == uniquePairs[i]$gender & additionalNames$ethnicity == uniquePairs[i]$ethnicity,])
  print(paste0(uniquePairs[i]$gender,",",uniquePairs[i]$ethnicity,": ",sampleCount))
  additionalNames$MIDDLE_NAME[additionalNames$gender == uniquePairs[i]$gender & additionalNames$ethnicity == uniquePairs[i]$ethnicity] <- randomNames(sampleCount,gender=uniquePairs[i]$gender,ethnicity=uniquePairs[i]$ethnicity,which.names="first")
  additionalNames$MAIDEN_NAME[additionalNames$gender == uniquePairs[i]$gender & additionalNames$ethnicity == uniquePairs[i]$ethnicity] <- randomNames(sampleCount,ethnicity=uniquePairs[i]$ethnicity,which.names="last")
}

#Remove gender and ethnicity from the additionalNames dataframe
additionalNames$gender <- NULL
additionalNames$ethnicity <- NULL

#Merging additionalNames back into the customer ID data frame
customers <- merge(customers, additionalNames, by="CUSTOMER_ID", all.x=TRUE)
rm(additionalNames)
head(customers)

#Create Dates of Birth
#Create a list of dates between date1 and date2, then from that, randomly choose dates to assign to each customer row, so you'll end up with the same number 
#of dates as customers
dobs <- sample(seq(as.Date('1935/01/01'),as.Date('2005/12/31'), by="day"), nrow(customerNames), replace=TRUE)
birthTimes <- NULL
for (n in 1:length(dobs))
{
  birthTimes <- rbind(birthTimes, randomTimestamps(1,dobs[n], as.Date(dobs[n]) + 1))
}

#For the creation times column, generate time stamps randomly starting from the most recent birthdate generated
#creationTimes <- sample(randomTimestamps(nrow(customerNames),max(dobs),as.Date('2018/1/1')), nrow(customerNames), replace=TRUE)

#Merge the creation and birth timestamp dates back into the customer ID data frame
#customers <- cbind(customers, dobs) #Use this if you prefer a normal year/month/day format for birthdates instead of a timestamp
customers <- cbind(customers, as.POSIXct(birthTimes, origin = "1970-01-01"))
#customers <- cbind(customers, as.POSIXct(creationTimes, origin = "1970-01-01"))

#Acquire the current year from the system
cy <- year(Sys.Date())

#Calculate the age of a customer by subtracting the customer's date of birth from the current year, then save it to the customer ID dataframe
customers %<>% mutate(Age = cy - year(dobs))

#Call the married status function for each customer, then save it to the MARITAL_STATUS column in the customer ID dataframe
customers %<>% rowwise() %>% mutate(MARITAL_STATUS = createMarriedStatus(Age))

#Call the maiden name function on customers who are married and female, then save it to the MAIDEN_NAME column in the customer ID dataframe
customers %<>% mutate(MAIDEN_NAME = ifelse(MARITAL_STATUS == "Married" && gender == 1, MAIDEN_NAME, NA))

#Print the columns of the customer ID dataframe
print(head(customers),width=Inf)

#Assign countries
#For each customer ID randomly choose a country from the country list defined in line 33 and according to the weights in variable "w". 
countries <- sample(customerCountries$countryName, nrow(customerNames), prob=customerCountries$w, replace=TRUE)

#Save countries to customer ID dataframe
customers <- cbind(customers, countries)

#Create SSN for US citizens
#Save the number of customers that have their country equal to United States
usRows <- nrow(customers[customers$countries == "USA",])

#Stop if the number of customers from the US is greater than 999999
if (usRows > 999999) stop("# of US individuals > 999,999, unable to create unique SSN")

#Generate a sequence of social security numbers from 999999-(the number of us people) to 999999, incrementing by 1
raw_ssn <- seq(999999-usRows+1,999999)

#Change the formatting of each number to the normal social security format
formatted_ssn <- sprintf("000-%02d-%04d",as.integer(raw_ssn/10000), raw_ssn %% 10000)

#Create an SSN column and fill it with NA values
customers$SSN <- NA

#For every customer with country US, fill the SSN column with the formatted social security numbers
customers$SSN[customers$countries == "USA"] <- formatted_ssn

#Delete the social security variable holders
rm(raw_ssn,formatted_ssn)

# add home phone number
customers$HOME_PHONE <- sprintf("555-%03d-%04d", sample(seq(1:999),nrow(customers),replace=TRUE), sample(seq(1:9999),nrow(customers),replace=TRUE))
print(head(customers),width=Inf)

#Add streets
#Make a list of numbers from 1 to 9999, incrementing by 1
addressNumbers <- seq(1:9999)

#For each customer, grab a number from addressNumbers and a street name from the streetNames$Street and place them into the HOME_ADDRESS_LINE_1 column
customers %<>% mutate(HOME_ADDRESS_LINE1 = paste(sample(addressNumbers,nrow(customers),replace=TRUE),sample(streetNames$Street, nrow(customerNames), replace=TRUE)))

#For each customer, grab a number from addressNumbers and a street name from the streetNames$Street and place them into the WORK_ADDRESS_LINE_1 column
customers %<>% mutate(WORK_ADDRESS_LINE1 = paste(sample(addressNumbers,nrow(customers),replace=TRUE),sample(streetNames$Street, nrow(customerNames), replace=TRUE)))

customers %<>% rowwise() %>% mutate(WORK_ADDRESS_LINE1 = ifelse(getWorkingStatus(Age),WORK_ADDRESS_LINE1,NA))

colnames(customers) <- c("CUSTOMER_ID","REMOTE_SYSTEM_ID","PARTY_TYPE","GENDER","Ethnicity","FIRST_NAME","LAST_NAME","MIDDLE_NAME","MAIDEN_NAME","BIRTH_TIME","Age","MARITAL_STATUS","NATIONALITY","SSN","HOME_PHONE","HOME_ADDRESS_LINE1","WORK_ADDRESS_LINE1")
customers <- tbl_df(customers)
print(head(customers),width=Inf)

customers %<>% mutate(GENDER=ifelse(GENDER==0,"Male","Female"))
customers %<>% mutate(CITIZENSHIP=NATIONALITY)

customers <- subset(customers,select=c("CUSTOMER_ID","REMOTE_SYSTEM_ID","PARTY_TYPE","LAST_NAME","FIRST_NAME","MIDDLE_NAME","MAIDEN_NAME","GENDER","BIRTH_TIME","MARITAL_STATUS","NATIONALITY","CITIZENSHIP","SSN","HOME_PHONE","HOME_ADDRESS_LINE1","WORK_ADDRESS_LINE1"))
print(head(customers),width=Inf)

wc <- tbl_df(world.cities)
wc <- replaceCountry(wc,"country.etc","Country","ISO3")

customers$HOME_ADDRESS_LINE2 <- NA
customers$HOME_ADDRESS_LINE3 <- NA
customers$HOME_ADDRESS_CODE <- NA
customers$HOME_ADDRESS_COUNTY <-NA
customers$HOME_ADDRESS_COUNTRY <- customers$NATIONALITY

# create US addresses
usCustomers <- customers[customers$NATIONALITY == "USA",c("CUSTOMER_ID")]
usCustomerCities <- sample_n(usCities,nrow(usCustomers),weight=pop,replace=TRUE)
usCustomers$HOME_ADDRESS_CITY = as.character(usCustomerCities$city)
usCustomers$HOME_ADDRESS_LAT = usCustomerCities$lat
usCustomers$HOME_ADDRESS_LONG = usCustomerCities$long
usCustomers$HOME_ADDRESS_STATE = as.character(usCustomerCities$state)

# create nonUS addresses
nonUsCustomers <- customers[customers$NATIONALITY != "USA",c("CUSTOMER_ID","NATIONALITY")]
nonUsCustomers$NATIONALITY <- as.character(nonUsCustomers$NATIONALITY)
nonUsCustomers$NATIONALITY[nonUsCustomers$NATIONALITY == "United Kingdom"] <- "UK"
nonUsCustomers$HOME_ADDRESS_CITY <- NA
nonUsCustomers$HOME_ADDRESS_LAT <- NA
nonUsCustomers$HOME_ADDRESS_LONG <- NA
uniqueCountries <- unique(nonUsCustomers$NATIONALITY)
for (i in 1:length(uniqueCountries)) {
  sampleCount <- nrow(nonUsCustomers[nonUsCustomers$NATIONALITY == uniqueCountries[i],])
  print(paste0(uniqueCountries[i],": ",sampleCount))
  nonUsCustomerCities <- sample_n(wc[wc$country.etc==uniqueCountries[i],],sampleCount,weight=pop,replace=TRUE)
  nonUsCustomers$HOME_ADDRESS_CITY[nonUsCustomers$NATIONALITY == uniqueCountries[i]] = nonUsCustomerCities$name
  nonUsCustomers$HOME_ADDRESS_LAT[nonUsCustomers$NATIONALITY == uniqueCountries[i]] = nonUsCustomerCities$lat
  nonUsCustomers$HOME_ADDRESS_LONG[nonUsCustomers$NATIONALITY == uniqueCountries[i]] = nonUsCustomerCities$long
}
nonUsCustomers$HOME_ADDRESS_STATE <- NA
nonUsCustomers$NATIONALITY <- NULL

# add the addresses to the customers
homeAddressCustomers <- rbind(usCustomers,nonUsCustomers)
customers <- merge(customers, homeAddressCustomers, by="CUSTOMER_ID", all.x=TRUE)
head(customers)
rm(usCustomers,nonUsCustomers,homeAddressCustomers)

customers$WORK_ADDRESS_LINE2 <- NA
customers$WORK_ADDRESS_LINE3 <- NA
customers$WORK_ADDRESS_CITY <- NA
customers$WORK_ADDRESS_CODE <- NA
customers$WORK_ADDRESS_COUNTY <-NA
customers$WORK_ADDRESS_STATE <- NA
customers$WORK_ADDRESS_COUNTRY <- customers$NATIONALITY
customers$WORK_ADDRESS_LAT <- NA
customers$WORK_ADDRESS_LONG <- NA
customers$WORK_PHONE <- NA
customers$OCCUPATION <- NA

customers$WORK_ADDRESS_CITY[!is.na(customers$WORK_ADDRESS_LINE1)] <- customers$HOME_ADDRESS_CITY[!is.na(customers$WORK_ADDRESS_LINE1)]
customers$WORK_ADDRESS_STATE[!is.na(customers$WORK_ADDRESS_LINE1)] <- customers$HOME_ADDRESS_STATE[!is.na(customers$WORK_ADDRESS_LINE1)]
customers$WORK_ADDRESS_COUNTRY[!is.na(customers$WORK_ADDRESS_LINE1)] <- as.character(customers$HOME_ADDRESS_COUNTRY[!is.na(customers$WORK_ADDRESS_LINE1)])
customers$WORK_ADDRESS_LAT[!is.na(customers$WORK_ADDRESS_LINE1)] <- customers$HOME_ADDRESS_LAT[!is.na(customers$WORK_ADDRESS_LINE1)]
customers$WORK_ADDRESS_LONG[!is.na(customers$WORK_ADDRESS_LINE1)] <- customers$HOME_ADDRESS_LONG[!is.na(customers$WORK_ADDRESS_LINE1)]
customers$WORK_PHONE[!is.na(customers$WORK_ADDRESS_LINE1)] <- sprintf("555-%03d-%04d",
  sample(seq(1:999),nrow(customers[!is.na(customers$WORK_ADDRESS_LINE1),]),replace=TRUE),
  sample(seq(1:9999),nrow(customers[!is.na(customers$WORK_ADDRESS_LINE1),]),replace=TRUE))
customers$OCCUPATION[!is.na(customers$WORK_ADDRESS_LINE1)] <-
  sample(occupations$Occupation, nrow(customers[!is.na(customers$WORK_ADDRESS_LINE1),]), prob=occupations$Count ,replace=TRUE)

#CUSTOMER_ID,REMOTE_SYSTEM_ID,PARTY_TYPE,LAST_NAME,FIRST_NAME,LEGAL_NAME,MIDDLE_NAME,MAIDEN_NAME,ALIAS,GENDER,BIRTH_TIME,DEATH_TIME,MARITAL_STATUS,CREATION_TIME,LAST_REVIEW_TIME,NEXT_REVIEW_TIME,PRIOR_SAR_COUNT,LAW_ENFORCEMENT_ALERT_COUNT,PAST_CONFIRMED_FRAUD,PAST_SUSPECTED_FRAUD,NATIONALITY,CITIZENSHIP,OCCUPATION,POSITION,DIVISION,LINE_OF_BUSINESS,WORKS_FOR,REPORTS_TO,LOCATION,PRIMARY_CONTACT_POINT,ALTERNATE_CONTACT_POINT,SSN,COUNTRY_OF_RESIDENCY,HOME_PHONE,WORK_PHONE,CELL_PHONE,HOME_ADDRESS_LINE1,HOME_ADDRESS_LINE2,HOME_ADDRESS_LINE3,HOME_ADDRESS_CITY,HOME_ADDRESS_CODE,HOME_ADDRESS_COUNTY,HOME_ADDRESS_STATE,HOME_ADDRESS_COUNTRY,HOME_ADDRESS_LAT,HOME_ADDRESS_LONG,WORK_ADDRESS_LINE1,WORK_ADDRESS_LINE2,WORK_ADDRESS_LINE3,WORK_ADDRESS_CITY,WORK_ADDRESS_CODE,WORK_ADDRESS_COUNTY,WORK_ADDRESS_STATE,WORK_ADDRESS_COUNTRY,WORK_ADDRESS_LAT,WORK_ADDRESS_LONG,ALTERNATE_ADDRESS_NAME,ALTERNATE_ADDRESS_LINE1,ALTERNATE_ADDRESS_LINE2,ALTERNATE_ADDRESS_LINE3,ALTERNATE_ADDRESS_CITY,ALTERNATE_ADDRESS_CODE,ALTERNATE_ADDRESS_COUNTY,ALTERNATE_ADDRESS_STATE,ALTERNATE_ADDRESS_COUNTRY,ALTERNATE_ADDRESS_LAT,ALTERNATE_ADDRESS_LONG
# add additional columns with no data
customers$LEGAL_NAME <- NA
customers$ALIAS <- NA
customers$DEATH_TIME <- NA
customers$CREATION_TIME <- NA#randomTimestamps(nrow(customers), "2006/1/1", "2017/12/31")
customers$NEXT_REVIEW_TIME <- NA#populate with future dates. do a calculation off of review timestamp + a year
customers$LAST_REVIEW_TIME <- NA
customers$PRIOR_SAR_COUNT <- 0
customers$LAW_ENFORCEMENT_ALERT_COUNT <- 0
customers$PAST_CONFIRMED_FRAUD <- 0
customers$PAST_SUSPECTED_FRAUD <- 0
customers$POSITION <- NA
customers$DIVISION <- NA
customers$LINE_OF_BUSINESS <- NA
customers$WORKS_FOR <- NA
customers$REPORTS_TO <- NA
customers$LOCATION <- NA
customers$PRIMARY_CONTACT_POINT <- NA
customers$ALTERNATE_CONTACT_POINT <- NA
customers$COUNTRY_OF_RESIDENCY <- customers$NATIONALITY
customers$CELL_PHONE <- NA
customers$ALTERNATE_ADDRESS_NAME <- NA
customers$ALTERNATE_ADDRESS_LINE1 <- NA
customers$ALTERNATE_ADDRESS_LINE2 <- NA
customers$ALTERNATE_ADDRESS_LINE3 <- NA
customers$ALTERNATE_ADDRESS_CITY <- NA
customers$ALTERNATE_ADDRESS_CODE <- NA
customers$ALTERNATE_ADDRESS_COUNTY <-NA
customers$ALTERNATE_ADDRESS_STATE <- NA
customers$ALTERNATE_ADDRESS_COUNTRY <- NA
customers$ALTERNATE_ADDRESS_LAT <- NA
customers$ALTERNATE_ADDRESS_LONG <- NA

#customers <- subset(customers,select=c("CUSTOMER_ID","REMOTE_SYSTEM_ID","PARTY_TYPE","LAST_NAME","FIRST_NAME","LEGAL_NAME","MIDDLE_NAME","MAIDEN_NAME","ALIAS","GENDER","BIRTH_TIME","DEATH_TIME","MARITAL_STATUS","CREATION_TIME","LAST_REVIEW_TIME","NEXT_REVIEW_TIME","PRIOR_SAR_COUNT","LAW_ENFORCEMENT_ALERT_COUNT","PAST_CONFIRMED_FRAUD","PAST_SUSPECTED_FRAUD","NATIONALITY","CITIZENSHIP","OCCUPATION","POSITION","DIVISION","LINE_OF_BUSINESS","WORKS_FOR","REPORTS_TO","LOCATION","PRIMARY_CONTACT_POINT","ALTERNATE_CONTACT_POINT","SSN","COUNTRY_OF_RESIDENCY","HOME_PHONE","WORK_PHONE","CELL_PHONE","HOME_ADDRESS_LINE1","HOME_ADDRESS_LINE2","HOME_ADDRESS_LINE3","HOME_ADDRESS_CITY","HOME_ADDRESS_CODE","HOME_ADDRESS_COUNTY","HOME_ADDRESS_STATE","HOME_ADDRESS_COUNTRY","HOME_ADDRESS_LAT","HOME_ADDRESS_LONG","WORK_ADDRESS_LINE1","WORK_ADDRESS_LINE2","WORK_ADDRESS_LINE3","WORK_ADDRESS_CITY","WORK_ADDRESS_CODE","WORK_ADDRESS_COUNTY","WORK_ADDRESS_STATE","WORK_ADDRESS_COUNTRY","WORK_ADDRESS_LAT","WORK_ADDRESS_LONG","ALTERNATE_ADDRESS_NAME","ALTERNATE_ADDRESS_LINE1","ALTERNATE_ADDRESS_LINE2","ALTERNATE_ADDRESS_LINE3","ALTERNATE_ADDRESS_CITY","ALTERNATE_ADDRESS_CODE","ALTERNATE_ADDRESS_COUNTY","ALTERNATE_ADDRESS_STATE","ALTERNATE_ADDRESS_COUNTRY","ALTERNATE_ADDRESS_LAT","ALTERNATE_ADDRESS_LONG"))
print("Printing customers")
print(customers)
customers <- subset(customers,select=c("CUSTOMER_ID","PARTY_TYPE","CREATION_TIME","LAST_REVIEW_TIME","NEXT_REVIEW_TIME","GENDER","BIRTH_TIME","DEATH_TIME","MARITAL_STATUS","NATIONALITY","LAST_NAME","FIRST_NAME","MIDDLE_NAME","ALIAS","OCCUPATION","COUNTRY_OF_RESIDENCY","HOME_PHONE","WORK_PHONE","CELL_PHONE","HOME_ADDRESS_LINE1","HOME_ADDRESS_LINE2","HOME_ADDRESS_LINE3","HOME_ADDRESS_CITY","HOME_ADDRESS_CODE","HOME_ADDRESS_STATE","HOME_ADDRESS_COUNTRY","WORK_ADDRESS_LINE1","WORK_ADDRESS_LINE2","WORK_ADDRESS_LINE3","WORK_ADDRESS_CITY","WORK_ADDRESS_CODE","WORK_ADDRESS_STATE","WORK_ADDRESS_COUNTRY","ALTERNATE_ADDRESS_NAME","ALTERNATE_ADDRESS_LINE1","ALTERNATE_ADDRESS_LINE2","ALTERNATE_ADDRESS_LINE3","ALTERNATE_ADDRESS_CITY","ALTERNATE_ADDRESS_CODE","ALTERNATE_ADDRESS_STATE","ALTERNATE_ADDRESS_COUNTRY"))
# customers %<>% mutate(HOME_ADDRESS_LINE1 = paste(sample(addressNumbers,nrow(customers),replace=TRUE),HOME_ADDRESS_LINE1))
print(head(customers),width=Inf)

outputFileName <- paste("AML_sampleIndividuals_",format(customerIDCount, scientific=FALSE),".csv",sep="")
print(paste("Writing generated individuals to ", outputFileName))
write.csv(customers, file=outputFileName,na="",row.names=FALSE)
