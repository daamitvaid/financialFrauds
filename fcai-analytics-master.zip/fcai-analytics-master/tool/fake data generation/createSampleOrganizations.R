# IBM Confidential
#
# OCO Source Material
#
# 5900-A0H
# 5737-E41
#
# (C) Copyright IBM Corp. 2017
#
# The source code for this program is not published or otherwise divested
# of its trade secrets, irrespective of what has been deposited with the
# U. S. Copyright Office.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm(list=ls())

library(randomNames)
library(data.table)
library(magrittr)
library(jsonlite)
library(dplyr)
library(maps)

organizationIDCount <- 1000

organizationCountries <- data_frame(countryName=c("United Kingdom","France","Germany","Australia","Netherlands","Norway","Ireland","Switzerland","Spain","Poland","Portugal","Italy","Belgium","Lithuania","Iceland","Japan","Jersey","Cyprus","Sweden","Finland","Greece","Singapore","Lebanon","United Arab Emirates","Israel","Denmark","Czech Republic","Brazil","United States","Canada","Bahrain"),
w=c(25,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,75,20,1))

organizationExtensions <- c("Corp.","Inc.","Ltd.","LLC",NA)

usCities <- do.call(rbind, strsplit(us.cities$name, ' (?=[^ ]+$)', perl=TRUE))
colnames(usCities) <- c("city","state")
usCities <- cbind(us.cities, usCities)
usCities <- tbl_df(usCities)

streetNames <- fread("StreetNames.csv",header=TRUE,sep=",", stringsAsFactors=FALSE)
streetNames <- tbl_df(streetNames)

industries <- fread("2017_NAICS_Structure_Summary_Table.csv",header=TRUE,sep=",", stringsAsFactors=FALSE)
industries <- tbl_df(industries)

set.seed(organizationIDCount)

organizations <- data_frame(EXTERNAL_PARTY_ID=seq(organizationIDCount, (organizationIDCount * 2)-1),
  REMOTE_SYSTEM_ID=1L,PARTY_TYPE="O",ORGANIZATION_TYPE=sample(organizationExtensions,organizationIDCount,replace=TRUE))
print(paste("Total organizations:",nrow(organizations)))

# Create organizationNames
organizations$COMPANY_NAME <- trimws(paste(randomNames(organizationIDCount,which.names="last",sample.with.replacement=TRUE),ifelse(!is.na(organizations$ORGANIZATION_TYPE),organizations$ORGANIZATION_TYPE,"")))

# Create phone number
organizations$COMPANY_PHONE <- sprintf("555-%03d-%04d", sample(seq(1:999),nrow(organizations),replace=TRUE),  sample(seq(1:9999),nrow(organizations),replace=TRUE))

#Create Date of Births
organizations$ESTABLISHED_DATE <- sample(seq(as.Date('1935/01/01'),as.Date('2016/12/31'), by="day"), nrow(organizations), replace=TRUE)
organizations$DISSOLVED_DATE <- NA
organizations$DESCRIPTION <- NA
organizations$PRIMARY_CONTACT_POINT <- NA
organizations$ALTERNATE_CONTACT_POINT <- NA
organizations$LINE_OF_BUSINESS <- sample(industries$Name, nrow(organizations), replace=TRUE)
organizations$GEOGRAPHY <- NA
organizations$PARENT_COMPANY_TAXID <- NA
organizations$ENTRY_TIMESTAMP <- NA
organizations$REVIEW_TIMESTAMP <- NA
organizations$END_TIMESTAMP <- NA
organizations$PRIOR_SAR_COUNT <- 0
organizations$LAW_ENFORCEMENT_ALERT_COUNT <- 0
organizations$PAST_CONFIRMED_FRAUD <- 0
organizations$PAST_SUSPECTED_FRAUD <- 0
organizations$TAX_ID <- sprintf("00-%07d", sample(seq(1:9999999),nrow(organizations),replace=TRUE))
organizations$COMPANY_ADDRESS_COUNTRY <- sample(organizationCountries$countryName, nrow(organizations), prob=organizationCountries$w, replace=TRUE)
addressNumbers <- seq(1:9999)
organizations$COMPANY_ADDRESS_LINE1 <- paste(sample(addressNumbers,nrow(organizations),replace=TRUE),sample(streetNames$Street, nrow(organizations), replace=TRUE))
organizations$COMPANY_ADDRESS_LINE2 <- NA
organizations$COMPANY_ADDRESS_LINE3 <- NA
organizations$COMPANY_ADDRESS_CODE <- NA
organizations$COMPANY_ADDRESS_COUNTY <-NA

# create US addresses
usOrganizations <- organizations[organizations$COMPANY_ADDRESS_COUNTRY == "United States",c("EXTERNAL_PARTY_ID")]
usOrganizationCities <- sample_n(usCities,nrow(usOrganizations),weight=pop,replace=TRUE)
usOrganizations$COMPANY_ADDRESS_CITY = as.character(usOrganizationCities$city)
usOrganizations$COMPANY_ADDRESS_LAT = usOrganizationCities$lat
usOrganizations$COMPANY_ADDRESS_LONG = usOrganizationCities$long
usOrganizations$COMPANY_ADDRESS_STATE = as.character(usOrganizationCities$state)

# create nonUS addresses
wc <- tbl_df(world.cities)
nonUsOrganizations <- organizations[organizations$COMPANY_ADDRESS_COUNTRY != "United States",c("EXTERNAL_PARTY_ID","COMPANY_ADDRESS_COUNTRY")]
nonUsOrganizations$COMPANY_ADDRESS_COUNTRY <- as.character(nonUsOrganizations$COMPANY_ADDRESS_COUNTRY)
nonUsOrganizations$COMPANY_ADDRESS_COUNTRY[nonUsOrganizations$COMPANY_ADDRESS_COUNTRY == "United Kingdom"] <- "UK"
nonUsOrganizations$COMPANY_ADDRESS_CITY <- NA
nonUsOrganizations$COMPANY_ADDRESS_LAT <- NA
nonUsOrganizations$COMPANY_ADDRESS_LONG <- NA
uniqueCountries <- unique(nonUsOrganizations$COMPANY_ADDRESS_COUNTRY)
for (i in 1:length(uniqueCountries)) {
  sampleCount <- nrow(nonUsOrganizations[nonUsOrganizations$COMPANY_ADDRESS_COUNTRY == uniqueCountries[i],])
  print(paste0(uniqueCountries[i],": ",sampleCount))
  nonUsOrganizationCities <- sample_n(wc[wc$country.etc==uniqueCountries[i],],sampleCount,weight=pop,replace=TRUE)
  nonUsOrganizations$COMPANY_ADDRESS_CITY[nonUsOrganizations$COMPANY_ADDRESS_COUNTRY == uniqueCountries[i]] = nonUsOrganizationCities$name
  nonUsOrganizations$COMPANY_ADDRESS_LAT[nonUsOrganizations$COMPANY_ADDRESS_COUNTRY == uniqueCountries[i]] = nonUsOrganizationCities$lat
  nonUsOrganizations$COMPANY_ADDRESS_LONG[nonUsOrganizations$COMPANY_ADDRESS_COUNTRY == uniqueCountries[i]] = nonUsOrganizationCities$long
}
nonUsOrganizations$COMPANY_ADDRESS_STATE <- NA
nonUsOrganizations$COMPANY_ADDRESS_COUNTRY <- NULL

# add the addresses to the organizations
companyAddressOrganizations <- rbind(usOrganizations,nonUsOrganizations)
organizations <- merge(organizations, companyAddressOrganizations, by="EXTERNAL_PARTY_ID", all.x=TRUE)
head(organizations)
rm(usOrganizations,nonUsOrganizations,companyAddressOrganizations)

organizations <- subset(organizations,select=c("EXTERNAL_PARTY_ID","REMOTE_SYSTEM_ID","COMPANY_NAME","COMPANY_PHONE","PARTY_TYPE","ESTABLISHED_DATE","ORGANIZATION_TYPE","DISSOLVED_DATE","DESCRIPTION","PRIMARY_CONTACT_POINT","ALTERNATE_CONTACT_POINT","LINE_OF_BUSINESS","GEOGRAPHY","PARENT_COMPANY_TAXID","ENTRY_TIMESTAMP","REVIEW_TIMESTAMP","END_TIMESTAMP","PRIOR_SAR_COUNT","LAW_ENFORCEMENT_ALERT_COUNT","PAST_CONFIRMED_FRAUD","PAST_SUSPECTED_FRAUD","TAX_ID","COMPANY_ADDRESS_LINE1","COMPANY_ADDRESS_LINE2","COMPANY_ADDRESS_LINE3","COMPANY_ADDRESS_CITY","COMPANY_ADDRESS_CODE","COMPANY_ADDRESS_COUNTY","COMPANY_ADDRESS_STATE","COMPANY_ADDRESS_COUNTRY","COMPANY_ADDRESS_LAT","COMPANY_ADDRESS_LONG"))
print(head(organizations),width=Inf)

outputFileName <- paste("AML_sampleOrganizations_",format(organizationIDCount, scientific=FALSE),".csv",sep="")
print(paste("Writing generated organizations to ", outputFileName))
write.csv(organizations, file=outputFileName,na="",row.names=FALSE)
