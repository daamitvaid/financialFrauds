## General Guildlines

Search on pedigree checker to see the package's review level. If it's approved already, check out the **Offline Install Section**. If not, check out both the **OSS approval section** and the **Offline Install Section**.

## Offline Install

#### Python Packages
Please refer to [this tutorial](https://packaging.python.org/tutorials/installing-packages/#source-distributions-vs-wheels) for a detailed description on how to install python packages offline.

A quick summary would be (here we use matplotlib as an example):
* [Download the matploitdb wheel](http://www.lfd.uci.edu/~gohlke/pythonlibs/#matplotlib)
* Get help from sys admin to pass the wheel into customer environment
* Run ```pip install matploitdb_wheel.whl```


## OSS Information

#### OSS Approval
As you find new open source software (or new R/Python packages) you want to use, 
* List the package you need along with its version
* List its review level from pedigree checker
* Create a new issue ticket in assessment with title explaining what's missing (e.g. Missing R package: Corrgram) and below is an example of issue description.

  We have discovered there is one r package "corrgram" missing in zions environment.
  - [ ] Add missing package to development environment
  - [ ] Get OSS approval for missing package
  - [ ] Add R package to current version of installer
* Raise the issue at scrum meeting and it'll be assigned and taken care of

#### Open Source Education For New Hire
We have an open source approval process in IBM to follow. It is some [mandatory Open Source education](https://w3-connections.ibm.com/wikis/home?lang=en-us#!/wiki/W783ba5fa6c1a_40b3_945a_07d0eb0115bd/page/OSPG) that you need to take, required annually for all IBMers working with Open Source to certify against. Most people take the online education and self-certify.

#### Pedigree Checker
There is an [open source pedigree checker](https://wicked-pedigree-service.w3ibm.mybluemix.net/) that you'll want to check to see if the tool is already approved.
* If it is AUA (All Usage Approved) or Review Level 1, that is really good.
* If it is Review Level 2, that is generally OK but we have to request approval.
* If it is Review Level 3 or 3.1 or higher, that's usually not good and we have more levels of approval to request.  Most of the R packages are Level 3 or Level 3.1 so our attorneys have become accustomed to us asking approval.

If the package has not been previously approved for use in FCI, we may have to request new approvals for us to ship it.
