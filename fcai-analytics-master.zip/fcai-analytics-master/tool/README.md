# Tool box


Used to host tools or documentations built under fcai-analytis. 
* It can be tools we built OOB before we decide if they should be integrated into product or offered to customer as a service.
* It can be documentations to start a new hire or Lab Service to learn, understand and configure the product.


### Note for dev team 
No scripts should be kept only locally. It's fragile and adds difficulty to communication and integration.
